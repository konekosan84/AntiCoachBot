import React from "react";

export default function PlatformDashboard() {
  return (
    <div className="flex items-center justify-center h-screen bg-slate-900 text-white">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-indigo-400 mb-4">Панель владельца платформы</h1>
        <p className="text-gray-400">Здесь появится управление школами, филиалами и пользователями.</p>
      </div>
    </div>
  );
}
