import { useState } from "react";
import { createBooking } from "../../api/bookings";

export default function BookingForm({
  selectedService,
  selectedEmployee,
  selectedBranch,
  selectedDate,
  selectedTime,
  onSuccess,
}) {
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("+7");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handlePhoneChange = (value) => {
    if (!value.startsWith("+7")) return;
    setPhone(value);
  };

  const validate = () => {
    if (!fullName.trim()) return "Введите ФИО";
    if (phone.length < 12) return "Введите корректный телефон";
    if (!selectedService) return "Не выбрана услуга";
    if (!selectedDate || !selectedTime) return "Не выбрано время";
    return null;
  };

  const handleSubmit = async () => {
    const validationError = validate();
    if (validationError) {
      setError(validationError);
      return;
    }

    setLoading(true);
    setError("");

    try {
      const payload = {
        full_name: fullName,
        phone,
        service_id: selectedService.id,
        employee_id: selectedEmployee?.id || null,
        branch_id: selectedBranch.id,
        date: selectedDate,      // YYYY-MM-DD
        start_time: selectedTime, // HH:mm
      };

      await createBooking(payload);

      onSuccess({
        fullName,
        phone,
        service: selectedService,
        employee: selectedEmployee,
        branch: selectedBranch,
        date: selectedDate,
        time: selectedTime,
      });
    } catch (e) {
      console.error(e);
      setError("Ошибка при записи. Попробуйте ещё раз");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="booking-form">
      <h3>Введите данные</h3>

      <input
        type="text"
        placeholder="ФИО"
        value={fullName}
        onChange={(e) => setFullName(e.target.value)}
      />

      <input
        type="tel"
        value={phone}
        onChange={(e) => handlePhoneChange(e.target.value)}
      />

      {error && <div className="error">{error}</div>}

      <button onClick={handleSubmit} disabled={loading}>
        {loading ? "Сохраняем..." : "Подтвердить запись"}
      </button>
    </div>
  );
}