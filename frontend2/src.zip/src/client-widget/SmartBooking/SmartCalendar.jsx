import React from 'react';
import CalendarGrid from './CalendarGrid';

export default function SmartCalendar({
  selectedDate,
  onSelectDate,
  availableDates = [],
}) {
  return (
    <div className="space-y-4">
      <div className="text-sm text-white/60">
        Доступны только дни, где в расписании есть смены
      </div>

      <CalendarGrid
        selectedDate={selectedDate}
        onSelectDate={onSelectDate}
        availableDates={availableDates}
      />
    </div>
  );
}