import React, { useEffect, useMemo, useState } from 'react';
import FilterPanel from './FilterPanel';
import SmartCalendar from './SmartCalendar';
import SlotsList from './SlotsList';
import { getShifts } from '../../api/schedule';
import { createBooking, getBookings } from '../../api/bookings';

const STEP_KEYS = {
  FILTERS: 'filters',
  DATE: 'date',
  SLOT: 'slot',
  FORM: 'form',
};

const DEFAULT_FORM = {
  full_name: '',
  phone: '+7 ',
  email: '',
  comment: '',
};


const SAME_DAY_SLOT_BUFFER_MINUTES = 30;

function normalizeId(value) {
  if (value === null || value === undefined || value === '') return null;
  const num = Number(value);
  return Number.isNaN(num) ? value : num;
}

function sortByName(items, key = 'name') {
  return [...items].sort((a, b) =>
    String(a?.[key] || '').localeCompare(String(b?.[key] || ''), 'ru')
  );
}

function pickArray(payload) {
  if (Array.isArray(payload)) return payload;
  if (Array.isArray(payload?.items)) return payload.items;
  if (Array.isArray(payload?.data)) return payload.data;
  if (Array.isArray(payload?.rows)) return payload.rows;
  return [];
}

function toYmdLocal(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function addDaysLocal(ymd, days) {
  const [year, month, day] = String(ymd).split('-').map(Number);
  const date = new Date(year, month - 1, day);
  date.setDate(date.getDate() + days);
  return toYmdLocal(date);
}

function formatDateRu(ymd) {
  if (!ymd) return 'не выбрана';
  const [year, month, day] = String(ymd).split('-').map(Number);
  if (!year || !month || !day) return ymd;

  const date = new Date(year, month - 1, day);
  return date.toLocaleDateString('ru-RU', {
    day: 'numeric',
    month: 'long',
    weekday: 'long',
  });
}

function formatDateTimeRu(ymd, time) {
  if (!ymd || !time) return null;
  const [year, month, day] = String(ymd).split('-').map(Number);
  const date = new Date(year, month - 1, day);
  const dateText = date.toLocaleDateString('ru-RU', {
    day: 'numeric',
    month: 'long',
  });
  return `${dateText}, ${time}`;
}

function formatNearestText(ymd, time) {
  if (!ymd || !time) return null;

  const today = toYmdLocal(new Date());
  const tomorrow = addDaysLocal(today, 1);

  if (ymd === today) return `Сегодня, ${time}`;
  if (ymd === tomorrow) return `Завтра, ${time}`;

  return formatDateTimeRu(ymd, time);
}

function timeToMinutes(time) {
  const [h, m] = String(time).split(':').map(Number);
  return h * 60 + m;
}

function minutesToTime(totalMinutes) {
  const h = Math.floor(totalMinutes / 60);
  const m = totalMinutes % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

function getNowMinutesWithBuffer(bufferMinutes = 0) {
  const now = new Date();
  return now.getHours() * 60 + now.getMinutes() + bufferMinutes;
}

function isFutureSlotForDate(dateYmd, slotStartTime, bufferMinutes = 0) {
  const todayYmd = toYmdLocal(new Date());

  if (dateYmd !== todayYmd) return true;

  return timeToMinutes(slotStartTime) >= getNowMinutesWithBuffer(bufferMinutes);
}

function normalizeDuration(service) {
  const raw =
    service?.duration_min ??
    service?.duration_minutes ??
    service?.duration ??
    service?.length_min ??
    60;

  const num = Number(raw);
  return Number.isFinite(num) && num > 0 ? num : 60;
}

function flattenToString(value) {
  if (value === null || value === undefined || value === '') return '';

  if (typeof value === 'string' || typeof value === 'number') {
    return String(value);
  }

  if (Array.isArray(value)) {
    return value
      .map((item) => flattenToString(item))
      .filter(Boolean)
      .join(', ');
  }

  if (typeof value === 'object') {
    if ('from' in value || 'to' in value || 'start' in value || 'end' in value) {
      const from = value.from || value.start || '';
      const to = value.to || value.end || '';
      if (from && to) return `${from}–${to}`;
      return String(from || to || '');
    }

    return Object.values(value)
      .map((item) => flattenToString(item))
      .filter(Boolean)
      .join(', ');
  }

  return String(value);
}

function extractBranchAddress(branch) {
  const raw =
    branch?.address ||
    branch?.full_address ||
    branch?.location ||
    branch?.branch_address ||
    branch?.address_line ||
    '';

  return flattenToString(raw);
}

function extractBranchWorktime(branch) {
  const raw =
    branch?.work_time ||
    branch?.working_hours ||
    branch?.hours ||
    branch?.schedule ||
    '';

  if (!raw) return '';

  if (typeof raw === 'string' || typeof raw === 'number') {
    return String(raw);
  }

  if (Array.isArray(raw)) {
    return raw.map((item) => flattenToString(item)).filter(Boolean).join(' · ');
  }

  if (typeof raw === 'object') {
    const order = [
      'monday',
      'tuesday',
      'wednesday',
      'thursday',
      'friday',
      'saturday',
      'sunday',
      'понедельник',
      'вторник',
      'среда',
      'четверг',
      'пятница',
      'суббота',
      'воскресенье',
    ];

    const labels = {
      monday: 'Пн',
      tuesday: 'Вт',
      wednesday: 'Ср',
      thursday: 'Чт',
      friday: 'Пт',
      saturday: 'Сб',
      sunday: 'Вс',
      понедельник: 'Пн',
      вторник: 'Вт',
      среда: 'Ср',
      четверг: 'Чт',
      пятница: 'Пт',
      суббота: 'Сб',
      воскресенье: 'Вс',
    };

    const entries = [];

    order.forEach((key) => {
      if (raw[key]) {
        const val = flattenToString(raw[key]);
        if (val) entries.push(`${labels[key] || key}: ${val}`);
      }
    });

    if (entries.length) return entries.join(' · ');

    return Object.entries(raw)
      .map(([key, value]) => {
        const val = flattenToString(value);
        return val ? `${key}: ${val}` : '';
      })
      .filter(Boolean)
      .join(' · ');
  }

  return String(raw);
}

function normalizeShifts(payload) {
  return pickArray(payload)
    .map((item) => ({
      ...item,
      id: item.id,
      date: item.date,
      start_time: item.start_time,
      end_time: item.end_time,
      employee_id: item.employee_id ?? item.employeeId ?? null,
      branch_id: item.branch_id ?? item.branchId ?? null,
      status: item.status ?? 'active',
    }))
    .filter(
      (item) =>
        item.date &&
        item.start_time &&
        item.end_time &&
        String(item.status || 'active') !== 'deleted'
    );
}

function normalizeBookings(payload) {
  return pickArray(payload)
    .map((item) => ({
      ...item,
      id: item.id,
      branch_id: item.branch_id ?? item.branchId ?? null,
      employee_id: item.employee_id ?? item.employeeId ?? null,
      service_id: item.service_id ?? item.serviceId ?? null,
      date: item.date,
      start_time: item.start_time ?? item.startTime ?? null,
      end_time: item.end_time ?? item.endTime ?? null,
      status: String(item.status || '').toLowerCase(),
    }))
    .filter((item) => item.date && item.start_time);
}

function isBlockedBookingStatus(status) {
  const s = String(status || '').toLowerCase();

  if (!s) return true;

  const freeStatuses = new Set([
    'cancelled',
    'canceled',
    'отменен',
    'отмена',
    'cancel',
  ]);

  return !freeStatuses.has(s);
}

function generateSlotsFromShifts({
  date,
  shifts,
  duration,
  employeesMap,
  sameDayBufferMinutes = 0,
}) {
  const dayShifts = shifts.filter((shift) => shift.date === date);
  const slots = [];

  dayShifts.forEach((shift) => {
    const shiftStart = timeToMinutes(shift.start_time);
    const shiftEnd = timeToMinutes(shift.end_time);

    if (!Number.isFinite(shiftStart) || !Number.isFinite(shiftEnd)) return;
    if (shiftEnd <= shiftStart) return;

    for (let start = shiftStart; start + duration <= shiftEnd; start += duration) {
      const startTime = minutesToTime(start);

      if (!isFutureSlotForDate(date, startTime, sameDayBufferMinutes)) {
        continue;
      }

      const employee = employeesMap.get(String(shift.employee_id));

      slots.push({
        id: `${shift.id}_${date}_${startTime}`,
        label: startTime,
        time: startTime,
        start_time: startTime,
        end_time: minutesToTime(start + duration),
        duration,
        employee_id: shift.employee_id,
        employee_name:
          employee?.full_name ||
          employee?.name ||
          `Сотрудник #${shift.employee_id}`,
        shift_id: shift.id,
        available: true,
        date,
        branch_id: shift.branch_id,
      });
    }
  });

  return slots.sort((a, b) => {
    const timeDiff = timeToMinutes(a.start_time) - timeToMinutes(b.start_time);
    if (timeDiff !== 0) return timeDiff;
    return String(a.employee_name).localeCompare(String(b.employee_name), 'ru');
  });
}

function filterSlotsByBookings(slots, bookings, fallbackDuration) {
  if (!Array.isArray(slots) || !slots.length) return [];
  if (!Array.isArray(bookings) || !bookings.length) return slots;

  return slots.filter((slot) => {
    const slotStart = timeToMinutes(slot.start_time);
    const slotEnd = timeToMinutes(slot.end_time || minutesToTime(slotStart + fallbackDuration));

    const overlap = bookings.some((booking) => {
      if (!isBlockedBookingStatus(booking.status)) return false;

      if (normalizeId(booking.employee_id) !== normalizeId(slot.employee_id)) return false;

      const bookingStart = timeToMinutes(booking.start_time);
      const bookingEnd = booking.end_time
        ? timeToMinutes(booking.end_time)
        : bookingStart + fallbackDuration;

      return slotStart < bookingEnd && slotEnd > bookingStart;
    });

    return !overlap;
  });
}

function buildNearestSlotForBranch({
  branch,
  service,
  shifts,
  employees,
  bookings,
  sameDayBufferMinutes = 0,
}) {
  if (!branch || !service) return null;

  const duration = normalizeDuration(service);
  const branchId = normalizeId(branch.id);

  const branchEmployees = employees.filter((employee) => {
    const employeeBranches = Array.isArray(employee.branch_ids)
      ? employee.branch_ids.map(normalizeId)
      : employee.branch_id !== undefined && employee.branch_id !== null
      ? [normalizeId(employee.branch_id)]
      : [];

    const branchMatch =
      employeeBranches.length === 0 || employeeBranches.includes(branchId);

    if (!branchMatch) return false;

    const employeeServices = Array.isArray(employee.service_ids)
      ? employee.service_ids.map(normalizeId)
      : employee.service_id !== undefined && employee.service_id !== null
      ? [normalizeId(employee.service_id)]
      : [];

    return (
      employeeServices.length === 0 ||
      employeeServices.includes(normalizeId(service.id))
    );
  });

  const allowedEmployeeIds = new Set(
    branchEmployees.map((employee) => normalizeId(employee.id))
  );

  const branchShifts = shifts.filter((shift) => {
    const branchMatch = normalizeId(shift.branch_id) === branchId;
    const employeeMatch =
      allowedEmployeeIds.size === 0 ||
      allowedEmployeeIds.has(normalizeId(shift.employee_id));

    return branchMatch && employeeMatch;
  });

  if (!branchShifts.length) return null;

  const byDate = [...new Set(branchShifts.map((item) => item.date))].sort();

  for (const date of byDate) {
    const rawSlots = generateSlotsFromShifts({
      date,
      shifts: branchShifts,
      duration,
      employeesMap: new Map(branchEmployees.map((item) => [String(item.id), item])),
      sameDayBufferMinutes,
    });

    const dateBookings = bookings.filter(
      (booking) =>
        booking.date === date &&
        normalizeId(booking.branch_id) === branchId
    );

    const freeSlots = filterSlotsByBookings(rawSlots, dateBookings, duration);

    if (freeSlots.length > 0) {
      const first = freeSlots[0];
      return {
        ...first,
        text: formatNearestText(first.date, first.start_time),
      };
    }
  }

  return null;
}

function normalizePhoneDigits(value) {
  const digits = String(value || '').replace(/\D/g, '');
  let local = digits;

  if (local.startsWith('7')) local = local.slice(1);
  if (local.startsWith('8')) local = local.slice(1);

  return local.slice(0, 10);
}

function formatPhoneFromDigits(localDigits) {
  const d = String(localDigits || '').slice(0, 10);
  const a = d.slice(0, 3);
  const b = d.slice(3, 6);
  const c = d.slice(6, 8);
  const e = d.slice(8, 10);

  let result = '+7';
  if (a) result += ` (${a}`;
  if (a.length === 3) result += ')';
  if (b) result += ` ${b}`;
  if (c) result += `-${c}`;
  if (e) result += `-${e}`;
  if (!d) result += ' ';

  return result;
}

function normalizePhoneInput(value) {
  const localDigits = normalizePhoneDigits(value);
  return formatPhoneFromDigits(localDigits);
}

function normalizePhoneForApi(value) {
  const localDigits = normalizePhoneDigits(value);
  return localDigits ? `+7${localDigits}` : '';
}

function maskPhone(value) {
  const localDigits = normalizePhoneDigits(value);
  if (!localDigits) return '+7 ••• •••-••-••';

  const a = localDigits.slice(0, 3);
  const b = localDigits.slice(3, 6);
  const c = localDigits.slice(6, 8);
  const d = localDigits.slice(8, 10);

  return `+7 (${a || '•••'}) ${b || '•••'}-${c || '••'}-${d || '••'}`;
}

function extractCreatedBooking(payload) {
  if (!payload) return null;
  if (Array.isArray(payload)) return payload[0] || null;

  const directCandidates = [
    payload,
    payload.data,
    payload.item,
    payload.booking,
    payload.result,
    payload.row,
  ];

  for (const candidate of directCandidates) {
    if (candidate && typeof candidate === 'object' && !Array.isArray(candidate)) {
      if (
        candidate.id !== undefined ||
        candidate.booking_id !== undefined ||
        (candidate.date && (candidate.start_time || candidate.startTime))
      ) {
        return {
          ...candidate,
          id: candidate.id ?? candidate.booking_id ?? candidate.bookingId ?? null,
        };
      }
    }
  }

  const listCandidates = [payload.items, payload.rows, payload.list];
  for (const list of listCandidates) {
    if (Array.isArray(list) && list.length) return list[0];
  }

  return null;
}

function isValidPhone(value) {
  return normalizePhoneDigits(value).length === 10;
}

function isValidEmail(value) {
  if (!value) return true;
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value).trim());
}

function StepBadge({ number, title, active, done }) {
  return (
    <div
      className={[
        'flex items-center gap-3 rounded-2xl border px-4 py-3 transition-all',
        active
          ? 'border-cyan-400/60 bg-cyan-500/10 shadow-[0_0_0_1px_rgba(34,211,238,0.15)]'
          : done
          ? 'border-emerald-400/40 bg-emerald-500/10'
          : 'border-white/10 bg-white/5',
      ].join(' ')}
    >
      <div
        className={[
          'flex h-8 w-8 items-center justify-center rounded-full text-sm font-semibold',
          active
            ? 'bg-cyan-400 text-slate-950'
            : done
            ? 'bg-emerald-400 text-slate-950'
            : 'bg-white/10 text-white/70',
        ].join(' ')}
      >
        {done ? '✓' : number}
      </div>

      <div className="min-w-0">
        <div className="text-sm font-semibold text-white">{title}</div>
        <div className="text-xs text-white/50">
          {active ? 'текущий шаг' : done ? 'заполнено' : 'ожидает'}
        </div>
      </div>
    </div>
  );
}

function SectionCard({ title, subtitle, children }) {
  return (
    <section className="rounded-3xl border border-white/10 bg-slate-900/70 p-5 shadow-[0_12px_40px_rgba(0,0,0,0.18)] backdrop-blur">
      <div className="mb-4">
        <h3 className="text-lg font-semibold text-white">{title}</h3>
        {subtitle ? <p className="mt-1 text-sm text-white/55">{subtitle}</p> : null}
      </div>
      {children}
    </section>
  );
}

function InfoEmpty({ title, text }) {
  return (
    <div className="flex min-h-[150px] items-center justify-center rounded-2xl border border-dashed border-white/10 bg-white/[0.03] p-6 text-center">
      <div>
        <div className="text-base font-semibold text-white/80">{title}</div>
        <div className="mt-2 max-w-md text-sm leading-6 text-white/45">{text}</div>
      </div>
    </div>
  );
}

function Field({ label, error, children }) {
  return (
    <label className="block">
      <div className="mb-2 text-sm font-medium text-white/75">{label}</div>
      {children}
      {error ? <div className="mt-2 text-sm text-rose-300">{error}</div> : null}
    </label>
  );
}

function SuccessCard({
  branch,
  service,
  employee,
  date,
  slot,
  selectedTime,
  confirmation,
  onReset,
}) {
  return (
    <div className="rounded-3xl border border-emerald-400/20 bg-emerald-400/10 p-6">
      <div className="text-2xl font-semibold text-white">Запись подтверждена</div>
      <div className="mt-3 space-y-2 text-sm leading-6 text-white/80">
        <p>
          Запись успешно оформлена. SMS с подтверждением отправлено на номер{' '}
          <strong className="font-semibold text-white">{confirmation?.phone_masked || 'указанный номер'}</strong>.
        </p>

        <p>
          Информация о визите также сохранена в личном кабинете — там можно
          посмотреть дату, время и детали записи.
        </p>
      </div>

      <div className="mt-5 grid gap-3 md:grid-cols-2">
        <div className="rounded-2xl border border-white/10 bg-slate-950/20 px-4 py-3">
          <div className="text-xs uppercase tracking-[0.14em] text-white/35">Филиал</div>
          <div className="mt-1 text-sm font-medium text-white/95">
            {branch?.name || '—'}
          </div>
        </div>

        <div className="rounded-2xl border border-white/10 bg-slate-950/20 px-4 py-3">
          <div className="text-xs uppercase tracking-[0.14em] text-white/35">Услуга</div>
          <div className="mt-1 text-sm font-medium text-white/95">
            {service?.name || '—'}
          </div>
        </div>

        <div className="rounded-2xl border border-white/10 bg-slate-950/20 px-4 py-3">
          <div className="text-xs uppercase tracking-[0.14em] text-white/35">Специалист</div>
          <div className="mt-1 text-sm font-medium text-white/95">
            {employee?.full_name || employee?.name || slot?.employee_name || 'любой доступный'}
          </div>
        </div>

        <div className="rounded-2xl border border-white/10 bg-slate-950/20 px-4 py-3">
          <div className="text-xs uppercase tracking-[0.14em] text-white/35">Дата и время</div>
          <div className="mt-1 text-sm font-medium text-white/95">
            {(() => {
              const slotTime = selectedTime || slot?.start_time || slot?.time || slot?.label || '';
              return slotTime ? `${formatDateRu(date)} • ${slotTime}` : formatDateRu(date);
            })()}
          </div>
        </div>
      </div>

      <button
        type="button"
        onClick={onReset}
        className="mt-6 inline-flex h-12 items-center justify-center rounded-2xl bg-white px-5 text-sm font-semibold text-slate-950 transition hover:brightness-110"
      >
        Оформить ещё одну запись
      </button>
    </div>
  );
}

export default function SmartBooking({
  branches = [],
  services = [],
  employees = [],
  widgetTitle = 'Онлайн-запись',
  widgetSubtitle = 'Выберите филиал, услугу, дату и удобное время',
  onStateChange,
}) {
  const [bookingState, setBookingState] = useState({
    entry_mode: 'service_first',
    branch_id: null,
    service_id: null,
    employee_id: null,
    date: null,
    slot: null,
    selected_time: null,
    form: DEFAULT_FORM,
  });

  const [shifts, setShifts] = useState([]);
  const [confirmedBooking, setConfirmedBooking] = useState(null);
  const [bookings, setBookings] = useState([]);
  const [availableDates, setAvailableDates] = useState([]);
  const [loadingShifts, setLoadingShifts] = useState(false);
  const [loadingBookings, setLoadingBookings] = useState(false);
  const [shiftsError, setShiftsError] = useState('');
  const [formErrors, setFormErrors] = useState({});
  const [submitState, setSubmitState] = useState({
    status: 'idle',
    message: '',
  });

  const sortedBranches = useMemo(() => sortByName(branches, 'name'), [branches]);
  const sortedServices = useMemo(() => sortByName(services, 'name'), [services]);

  const employeesMap = useMemo(
    () => new Map(employees.map((item) => [String(item.id), item])),
    [employees]
  );

  const selectedBranch = useMemo(
    () =>
      sortedBranches.find(
        (item) => normalizeId(item.id) === normalizeId(bookingState.branch_id)
      ) || null,
    [sortedBranches, bookingState.branch_id]
  );

  const selectedService = useMemo(
    () =>
      sortedServices.find(
        (item) => normalizeId(item.id) === normalizeId(bookingState.service_id)
      ) || null,
    [sortedServices, bookingState.service_id]
  );

  const servicesForBranch = useMemo(() => {
    if (!bookingState.branch_id) return [];

    return sortByName(
      services.filter((service) => {
        if (!service) return false;

        if (!service.branch_id && !service.branch_ids) return true;

        if (Array.isArray(service.branch_ids)) {
          return service.branch_ids
            .map(normalizeId)
            .includes(normalizeId(bookingState.branch_id));
        }

        return normalizeId(service.branch_id) === normalizeId(bookingState.branch_id);
      }),
      'name'
    );
  }, [services, bookingState.branch_id]);

  const branchesForService = useMemo(() => {
    if (!bookingState.service_id) return [];

    return sortedBranches.filter((branch) => {
      const service = sortedServices.find(
        (item) => normalizeId(item.id) === normalizeId(bookingState.service_id)
      );
      if (!service) return false;

      if (!service.branch_id && !service.branch_ids) return true;

      if (Array.isArray(service.branch_ids)) {
        return service.branch_ids.map(normalizeId).includes(normalizeId(branch.id));
      }

      return normalizeId(service.branch_id) === normalizeId(branch.id);
    });
  }, [sortedBranches, sortedServices, bookingState.service_id]);

  const employeesForBranchAndService = useMemo(() => {
    if (!bookingState.branch_id) return [];

    return sortByName(
      employees.filter((employee) => {
        if (!employee) return false;

        const employeeBranches = Array.isArray(employee.branch_ids)
          ? employee.branch_ids.map(normalizeId)
          : employee.branch_id !== undefined && employee.branch_id !== null
          ? [normalizeId(employee.branch_id)]
          : [];

        const branchMatch =
          employeeBranches.length === 0 ||
          employeeBranches.includes(normalizeId(bookingState.branch_id));

        if (!branchMatch) return false;

        if (!bookingState.service_id) return true;

        const employeeServices = Array.isArray(employee.service_ids)
          ? employee.service_ids.map(normalizeId)
          : employee.service_id !== undefined && employee.service_id !== null
          ? [normalizeId(employee.service_id)]
          : [];

        return (
          employeeServices.length === 0 ||
          employeeServices.includes(normalizeId(bookingState.service_id))
        );
      }),
      'full_name'
    );
  }, [employees, bookingState.branch_id, bookingState.service_id]);

  const selectedEmployee = useMemo(
    () =>
      employeesForBranchAndService.find(
        (item) => normalizeId(item.id) === normalizeId(bookingState.employee_id)
      ) || null,
    [employeesForBranchAndService, bookingState.employee_id]
  );

  const currentStep = useMemo(() => {
    const filtersReady =
      bookingState.entry_mode === 'service_first'
        ? Boolean(bookingState.service_id && bookingState.branch_id)
        : Boolean(bookingState.branch_id && bookingState.service_id);

    if (!filtersReady) return STEP_KEYS.FILTERS;
    if (!bookingState.date) return STEP_KEYS.DATE;
    if (!bookingState.slot) return STEP_KEYS.SLOT;
    return STEP_KEYS.FORM;
  }, [bookingState]);

  useEffect(() => {
    const enoughDataToLoad =
      bookingState.entry_mode === 'service_first'
        ? Boolean(bookingState.service_id)
        : Boolean(bookingState.branch_id && bookingState.service_id);

    if (!enoughDataToLoad) {
      setShifts([]);
      setAvailableDates([]);
      setLoadingShifts(false);
      setShiftsError('');
      return;
    }

    let cancelled = false;

    async function loadShifts() {
      setLoadingShifts(true);
      setShiftsError('');

      try {
        const today = toYmdLocal(new Date());
        const dateTo = addDaysLocal(today, 45);

        const response = await getShifts({
          date_from: today,
          date_to: dateTo,
          branch_id:
            bookingState.entry_mode === 'service_first'
              ? bookingState.branch_id || 'all'
              : bookingState.branch_id,
          employee_id: bookingState.employee_id || 'all',
        });

        if (cancelled) return;

        const normalized = normalizeShifts(response);
        const onlyActive = normalized.filter(
          (item) => String(item.status || 'active') === 'active'
        );

        setShifts(onlyActive);
      } catch (error) {
        if (cancelled) return;
        console.error('SmartBooking loadShifts error:', error);
        setShifts([]);
        setAvailableDates([]);
        setShiftsError(
          error?.payload?.message ||
            error?.payload?.error ||
            error?.message ||
            'Не удалось загрузить смены'
        );
      } finally {
        if (!cancelled) setLoadingShifts(false);
      }
    }

    loadShifts();

    return () => {
      cancelled = true;
    };
  }, [
    bookingState.entry_mode,
    bookingState.branch_id,
    bookingState.service_id,
    bookingState.employee_id,
  ]);

  useEffect(() => {
    if (!selectedService) {
      setBookings([]);
      return;
    }

    let cancelled = false;

    async function loadBookings() {
      try {
        setLoadingBookings(true);

        const today = toYmdLocal(new Date());
        const dateTo = addDaysLocal(today, 45);

        const data = await getBookings({
          branch_id: bookingState.branch_id || 'all',
          employee_id: bookingState.employee_id || 'all',
          service_id: 'all',
          status: 'all',
          date_from: today,
          date_to: dateTo,
        });

        if (cancelled) return;

        setBookings(normalizeBookings(data));
      } catch (error) {
        if (cancelled) return;
        console.error('SmartBooking loadBookings error:', error);
        setBookings([]);
      } finally {
        if (!cancelled) setLoadingBookings(false);
      }
    }

    loadBookings();

    return () => {
      cancelled = true;
    };
  }, [selectedService, bookingState.branch_id, bookingState.employee_id]);

  useEffect(() => {
    if (!bookingState.branch_id || !selectedService) {
      setAvailableDates([]);
      return;
    }

    const duration = normalizeDuration(selectedService);

    const uniqueDates = [
      ...new Set(
        shifts
          .filter(
            (item) =>
              normalizeId(item.branch_id) === normalizeId(bookingState.branch_id)
          )
          .map((item) => item.date)
      ),
    ]
      .filter((date) => {
        const rawSlots = generateSlotsFromShifts({
          date,
          shifts: shifts.filter(
            (item) =>
              normalizeId(item.branch_id) === normalizeId(bookingState.branch_id)
          ),
          duration,
          employeesMap,
          sameDayBufferMinutes: SAME_DAY_SLOT_BUFFER_MINUTES,
        });

        const dateBookings = bookings.filter(
          (booking) =>
            booking.date === date &&
            normalizeId(booking.branch_id) === normalizeId(bookingState.branch_id)
        );

        const freeSlots = filterSlotsByBookings(rawSlots, dateBookings, duration);
        return freeSlots.length > 0;
      })
      .sort();

    setAvailableDates(uniqueDates);
  }, [bookingState.branch_id, selectedService, shifts, bookings, employeesMap]);

  useEffect(() => {
    if (bookingState.date && !availableDates.includes(bookingState.date)) {
      setBookingState((prev) => ({
        ...prev,
        date: null,
        slot: null,
        form: { ...DEFAULT_FORM },
      }));
    }
  }, [availableDates, bookingState.date]);

  const branchCards = useMemo(() => {
    if (!selectedService) return [];

    const sourceBranches =
      bookingState.entry_mode === 'service_first'
        ? branchesForService
        : selectedBranch
        ? [selectedBranch]
        : [];

    const cards = sourceBranches.map((branch) => {
      const nearestSlot = buildNearestSlotForBranch({
        branch,
        service: selectedService,
        shifts,
        employees,
        bookings,
        sameDayBufferMinutes: SAME_DAY_SLOT_BUFFER_MINUTES,
      });

      return {
        id: branch.id,
        name: branch.name,
        address: extractBranchAddress(branch),
        worktime: extractBranchWorktime(branch),
        nearestSlot,
        isSelected: normalizeId(branch.id) === normalizeId(bookingState.branch_id),
      };
    });

    return cards.sort((a, b) => {
      if (a.isSelected && !b.isSelected) return -1;
      if (!a.isSelected && b.isSelected) return 1;

      if (a.nearestSlot && !b.nearestSlot) return -1;
      if (!a.nearestSlot && b.nearestSlot) return 1;

      const aKey = a.nearestSlot ? `${a.nearestSlot.date}_${a.nearestSlot.time}` : '';
      const bKey = b.nearestSlot ? `${b.nearestSlot.date}_${b.nearestSlot.time}` : '';

      if (aKey && bKey && aKey !== bKey) return aKey.localeCompare(bKey, 'ru');

      return String(a.name || '').localeCompare(String(b.name || ''), 'ru');
    });
  }, [
    selectedService,
    branchesForService,
    selectedBranch,
    shifts,
    employees,
    bookings,
    bookingState.branch_id,
    bookingState.entry_mode,
  ]);

  const realSlots = useMemo(() => {
    if (!bookingState.date || !selectedService || !bookingState.branch_id) return [];

    const duration = normalizeDuration(selectedService);

    const relevantShifts = shifts.filter((shift) => {
      const branchMatch =
        normalizeId(shift.branch_id) === normalizeId(bookingState.branch_id);

      const employeeMatch = bookingState.employee_id
        ? normalizeId(shift.employee_id) === normalizeId(bookingState.employee_id)
        : true;

      return branchMatch && employeeMatch;
    });

    const rawSlots = generateSlotsFromShifts({
      date: bookingState.date,
      shifts: relevantShifts,
      duration,
      employeesMap,
      sameDayBufferMinutes: SAME_DAY_SLOT_BUFFER_MINUTES,
    });

    const dateBookings = bookings.filter(
      (booking) =>
        booking.date === bookingState.date &&
        normalizeId(booking.branch_id) === normalizeId(bookingState.branch_id)
    );

    return filterSlotsByBookings(rawSlots, dateBookings, duration);
  }, [
    bookingState.date,
    bookingState.branch_id,
    bookingState.employee_id,
    selectedService,
    shifts,
    bookings,
    employeesMap,
  ]);

  useEffect(() => {
    if (
      bookingState.slot &&
      !realSlots.some((slot) => String(slot.id) === String(bookingState.slot.id))
    ) {
      setBookingState((prev) => ({
        ...prev,
        slot: null,
        form: { ...DEFAULT_FORM },
      }));
    }
  }, [realSlots, bookingState.slot]);

  useEffect(() => {
    if (typeof onStateChange === 'function') {
      onStateChange({
        ...bookingState,
        currentStep,
        derived: {
          selectedBranch,
          selectedService,
          selectedEmployee,
          servicesForBranch,
          employeesForBranchAndService,
          shifts,
          bookings,
          availableDates,
          slots: realSlots,
          branchCards,
        },
      });
    }
  }, [
    bookingState,
    currentStep,
    selectedBranch,
    selectedService,
    selectedEmployee,
    servicesForBranch,
    employeesForBranchAndService,
    shifts,
    bookings,
    availableDates,
    realSlots,
    branchCards,
    onStateChange,
  ]);

  const handleModeChange = (mode) => {
    setBookingState({
      entry_mode: mode,
      branch_id: null,
      service_id: null,
      employee_id: null,
      date: null,
      slot: null,
      selected_time: null,
      form: { ...DEFAULT_FORM },
    });
    setAvailableDates([]);
    setFormErrors({});
    setSubmitState({ status: 'idle', message: '' });
  };

  const handleBranchChange = (branchId) => {
    const nextBranchId = normalizeId(branchId);

    setBookingState((prev) => ({
      ...prev,
      branch_id: nextBranchId,
      employee_id: null,
      date: null,
      slot: null,
      form: { ...DEFAULT_FORM },
    }));
    setFormErrors({});
    setSubmitState({ status: 'idle', message: '' });
  };

  const handleServiceChange = (serviceId) => {
    const nextServiceId = normalizeId(serviceId);

    setBookingState((prev) => ({
      ...prev,
      service_id: nextServiceId,
      branch_id: prev.entry_mode === 'service_first' ? null : prev.branch_id,
      employee_id: null,
      date: null,
      slot: null,
      form: { ...DEFAULT_FORM },
    }));
    setFormErrors({});
    setSubmitState({ status: 'idle', message: '' });
  };

  const handleEmployeeChange = (employeeId) => {
    const nextEmployeeId = normalizeId(employeeId);

    setBookingState((prev) => ({
      ...prev,
      employee_id: nextEmployeeId,
      date: null,
      slot: null,
      form: { ...DEFAULT_FORM },
    }));
    setFormErrors({});
    setSubmitState({ status: 'idle', message: '' });
  };

  const handleDateChange = (date) => {
    setBookingState((prev) => ({
      ...prev,
      date,
      slot: null,
      selected_time: null,
      form: { ...DEFAULT_FORM },
    }));
    setFormErrors({});
    setSubmitState({ status: 'idle', message: '' });
  };

  const handleSlotSelect = (slot) => {
    const selectedTime = slot?.start_time || slot?.time || slot?.label || null;

    setBookingState((prev) => ({
      ...prev,
      slot,
      selected_time: selectedTime,
      employee_id: slot?.employee_id ?? prev.employee_id,
      form: { ...prev.form, phone: prev.form.phone || '+7 ' },
    }));
    setFormErrors({});
    setSubmitState({ status: 'idle', message: '' });
  };

  const handleFullReset = () => {
    setBookingState({
      entry_mode: bookingState.entry_mode,
      branch_id: null,
      service_id: null,
      employee_id: null,
      date: null,
      slot: null,
      selected_time: null,
      form: { ...DEFAULT_FORM },
    });
    setConfirmedBooking(null);
    setShifts([]);
    setBookings([]);
    setAvailableDates([]);
    setLoadingShifts(false);
    setLoadingBookings(false);
    setShiftsError('');
    setFormErrors({});
    setSubmitState({ status: 'idle', message: '' });
  };

  const updateFormField = (field, value) => {
    setBookingState((prev) => ({
      ...prev,
      form: {
        ...prev.form,
        [field]: field === 'phone' ? normalizePhoneInput(value) : value,
      },
    }));

    setFormErrors((prev) => {
      if (!prev[field]) return prev;
      const next = { ...prev };
      delete next[field];
      return next;
    });
  };

  const validateForm = () => {
    const errors = {};

    if (!bookingState.form.full_name.trim()) {
      errors.full_name = 'Введите ФИО';
    }

    if (!isValidPhone(bookingState.form.phone)) {
      errors.phone = 'Введите телефон полностью';
    }

    if (!isValidEmail(bookingState.form.email)) {
      errors.email = 'Проверьте email';
    }

    return errors;
  };

  const handleSubmit = async () => {
    const errors = validateForm();
    setFormErrors(errors);

    if (Object.keys(errors).length > 0) {
      setSubmitState({
        status: 'error',
        message: 'Заполните обязательные поля корректно',
      });
      return;
    }

    if (!selectedBranch || !selectedService || !bookingState.date || !bookingState.slot) {
      setSubmitState({
        status: 'error',
        message: 'Не хватает данных для создания записи',
      });
      return;
    }

    try {
      setSubmitState({
        status: 'submitting',
        message: '',
      });

      const finalTime =
        bookingState.selected_time ||
        bookingState.slot?.start_time ||
        bookingState.slot?.time ||
        bookingState.slot?.label;

      const finalEndTime =
        bookingState.slot?.end_time ||
        minutesToTime(timeToMinutes(finalTime) + normalizeDuration(selectedService));

      const finalEmployeeId = bookingState.slot?.employee_id || bookingState.employee_id;
      const finalEmployee =
        employeesMap.get(String(finalEmployeeId)) ||
        selectedEmployee ||
        null;

      const apiPhone = normalizePhoneForApi(bookingState.form.phone);
      const trimmedName = bookingState.form.full_name.trim();
      const trimmedEmail = bookingState.form.email.trim();
      const trimmedComment = bookingState.form.comment.trim();

      const payload = {
        branch_id: selectedBranch.id,
        employee_id: finalEmployeeId,
        service_id: selectedService.id,
        date: bookingState.date,
        start_time: finalTime,
        end_time: finalEndTime,
        full_name: trimmedName,
        phone: apiPhone,
        email: trimmedEmail,
        price: selectedService?.price ?? bookingState.slot?.price ?? null,
        status: 'booked',
      };

      const createdResponse = await createBooking({
        ...payload,
        comment: trimmedComment,
        notes: trimmedComment,
      });

      const created = extractCreatedBooking(createdResponse) || {
        ...payload,
        id: `tmp_${Date.now()}`,
      };

      const normalizedCreated = normalizeBookings([created])[0];
      if (!normalizedCreated) {
        throw new Error('Сервер вернул некорректные данные записи');
      }

      setBookings((prev) => {
        const withoutSame = prev.filter((item) => String(item.id) !== String(normalizedCreated.id));
        return [normalizedCreated, ...withoutSame];
      });

      setConfirmedBooking({
        branch: selectedBranch,
        service: selectedService,
        employee: finalEmployee,
        date: normalizedCreated.date || bookingState.date,
        time: normalizedCreated.start_time || finalTime,
        confirmation: {
          type: 'sms_mock',
          status: 'sent',
          phone_masked: maskPhone(bookingState.form.phone),
        },
      });

      setSubmitState({
        status: 'success',
        message: 'ok',
      });
    } catch (error) {
      console.error('SmartBooking createBooking error:', error);

      let message = error?.message || 'Не удалось создать запись';

      if (String(message).includes('409')) {
        message = 'Это время уже занято. Выберите другой слот.';
      }

      setSubmitState({
        status: 'error',
        message,
      });
    }
  };

  const summaryItems = [
    {
      label: 'Филиал',
      value: selectedBranch?.name || 'не выбран',
    },
    {
      label: 'Адрес',
      value: extractBranchAddress(selectedBranch) || 'адрес уточняется',
    },
    {
      label: 'Услуга',
      value: selectedService?.name || 'не выбрана',
    },
    {
      label: 'Специалист',
      value:
        selectedEmployee
          ? `${selectedEmployee.full_name || selectedEmployee.name}${selectedEmployee.position ? ` · ${selectedEmployee.position}` : ''}`
          : 'любой доступный',
    },
    {
      label: 'Дата',
      value: formatDateRu(bookingState.date),
    },
    {
      label: 'Время',
      value:
        bookingState.selected_time ||
        bookingState.slot?.start_time ||
        bookingState.slot?.time ||
        bookingState.slot?.label ||
        'не выбрано',
    },
  ];

  const isFiltersDone =
    bookingState.entry_mode === 'service_first'
      ? Boolean(bookingState.service_id && bookingState.branch_id)
      : Boolean(bookingState.branch_id && bookingState.service_id);

  const isDateDone = Boolean(bookingState.date);
  const isSlotDone = Boolean(bookingState.slot);

  const canShowCalendar = isFiltersDone;
  const canShowSlots = Boolean(bookingState.date);
  const canShowForm = Boolean(bookingState.slot);

  return (
    <div className="min-h-full bg-[radial-gradient(circle_at_top,#172554_0%,#0f172a_35%,#020617_100%)] p-4 text-white md:p-6">
      <div className="mx-auto flex max-w-6xl flex-col gap-6">
        <div className="rounded-[28px] border border-white/10 bg-white/[0.04] p-6 shadow-[0_18px_60px_rgba(0,0,0,0.3)] backdrop-blur">
          <div className="flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <div className="inline-flex rounded-full border border-cyan-400/30 bg-cyan-400/10 px-3 py-1 text-xs font-medium uppercase tracking-[0.18em] text-cyan-300">
                SLOTIQ PRO
              </div>

              <h1 className="mt-4 text-3xl font-semibold tracking-tight text-white md:text-4xl">
                {widgetTitle}
              </h1>

              <p className="mt-3 max-w-2xl text-sm leading-6 text-white/60 md:text-base">
                {widgetSubtitle}
              </p>
            </div>

            <button
              type="button"
              onClick={handleFullReset}
              className="inline-flex h-11 items-center justify-center rounded-2xl border border-white/15 bg-white/5 px-5 text-sm font-medium text-white/80 transition hover:border-white/30 hover:bg-white/10 hover:text-white"
            >
              Сбросить всё
            </button>
          </div>

          <div className="mt-6 grid gap-3 md:grid-cols-2 xl:grid-cols-4">
            <StepBadge
              number={1}
              title="Параметры записи"
              active={currentStep === STEP_KEYS.FILTERS}
              done={isFiltersDone}
            />
            <StepBadge
              number={2}
              title="Выбор даты"
              active={currentStep === STEP_KEYS.DATE}
              done={isDateDone}
            />
            <StepBadge
              number={3}
              title="Выбор времени"
              active={currentStep === STEP_KEYS.SLOT}
              done={isSlotDone}
            />
            <StepBadge
              number={4}
              title="Контакты клиента"
              active={currentStep === STEP_KEYS.FORM}
              done={submitState.status === 'success'}
            />
          </div>
        </div>

        <div className="grid gap-6 xl:grid-cols-[1.35fr_0.85fr]">
          <div className="flex flex-col gap-6">
            <SectionCard
              title="Шаг 1. Как будем искать запись"
              subtitle="Клиент может искать либо по услуге, либо по адресу филиала."
            >
              <FilterPanel
                mode={bookingState.entry_mode}
                branches={sortedBranches}
                services={sortedServices}
                servicesForBranch={servicesForBranch}
                employees={employeesForBranchAndService}
                value={{
                  branch_id: bookingState.branch_id,
                  service_id: bookingState.service_id,
                  employee_id: bookingState.employee_id,
                }}
                branchCards={branchCards}
                selectedBranch={selectedBranch}
                selectedService={selectedService}
                selectedEmployee={selectedEmployee}
                loadingShifts={loadingShifts || loadingBookings}
                shiftsError={shiftsError}
                onModeChange={handleModeChange}
                onBranchChange={handleBranchChange}
                onServiceChange={handleServiceChange}
                onEmployeeChange={handleEmployeeChange}
              />
            </SectionCard>

            <SectionCard
              title="Шаг 2. Выбор даты"
              subtitle={
                canShowCalendar
                  ? 'Показываем только дни, где реально есть будущие свободные окна.'
                  : 'Сначала выберите услугу и филиал.'
              }
            >
              {!canShowCalendar ? (
                <InfoEmpty
                  title="Сначала закончите шаг 1"
                  text="Когда услуга и филиал будут выбраны, здесь появятся реальные доступные даты."
                />
              ) : loadingShifts || loadingBookings ? (
                <InfoEmpty
                  title="Загружаем расписание"
                  text="Проверяем смены и уже занятые окна."
                />
              ) : shiftsError ? (
                <InfoEmpty title="Не удалось загрузить смены" text={shiftsError} />
              ) : (
                <SmartCalendar
                  selectedDate={bookingState.date}
                  onSelectDate={handleDateChange}
                  availableDates={availableDates}
                />
              )}
            </SectionCard>

            <SectionCard
              title="Шаг 3. Свободное время"
              subtitle={
                canShowSlots
                  ? `Показываем только реально свободные окна. Прошедшие слоты сегодня скрыты, плюс буфер ${SAME_DAY_SLOT_BUFFER_MINUTES} минут.`
                  : 'Слоты времени покажем после выбора даты.'
              }
            >
              {canShowSlots ? (
                <SlotsList
                  date={bookingState.date}
                  selectedSlot={bookingState.slot}
                  slots={realSlots}
                  onSelectSlot={handleSlotSelect}
                />
              ) : (
                <InfoEmpty
                  title="Сначала выберите дату"
                  text="После выбора доступной даты здесь появятся реальные интервалы по смене."
                />
              )}
            </SectionCard>

            <SectionCard
              title={submitState.status === 'success' ? 'Готово' : 'Шаг 4. Контакты'}
              subtitle={
                submitState.status === 'success'
                  ? 'Запись оформлена и подтверждение отправлено.'
                  : canShowForm
                    ? 'Оставьте данные для подтверждения записи.'
                    : 'Форма откроется после выбора времени.'
              }
            >
              {submitState.status === 'success' ? (
                <SuccessCard
                  branch={selectedBranch}
                  service={selectedService}
                  employee={selectedEmployee}
                  date={bookingState.date}
                  slot={bookingState.slot}
                  selectedTime={bookingState.selected_time}
                  confirmation={confirmedBooking?.confirmation}
                  onReset={handleFullReset}
                />
              ) : canShowForm ? (
                <div className="grid gap-4 md:grid-cols-2">
                  <Field label="ФИО" error={formErrors.full_name}>
                    <input
                      type="text"
                      value={bookingState.form.full_name}
                      onChange={(e) => updateFormField('full_name', e.target.value)}
                      placeholder="Иванов Иван Иванович"
                      className="h-12 w-full rounded-2xl border border-white/10 bg-white/5 px-4 text-white outline-none transition placeholder:text-white/25 focus:border-cyan-400/50"
                    />
                  </Field>

                  <Field label="Телефон" error={formErrors.phone}>
                    <input
                      type="tel"
                      value={bookingState.form.phone}
                      onChange={(e) => updateFormField('phone', e.target.value)}
                      placeholder="+7 (___) ___-__-__"
                      className="h-12 w-full rounded-2xl border border-white/10 bg-white/5 px-4 text-white outline-none transition placeholder:text-white/25 focus:border-cyan-400/50"
                    />
                  </Field>

                  <Field label="Email" error={formErrors.email}>
                    <input
                      type="email"
                      value={bookingState.form.email}
                      onChange={(e) => updateFormField('email', e.target.value)}
                      placeholder="example@mail.com"
                      className="h-12 w-full rounded-2xl border border-white/10 bg-white/5 px-4 text-white outline-none transition placeholder:text-white/25 focus:border-cyan-400/50"
                    />
                  </Field>

                  <Field label="Комментарий">
                    <input
                      type="text"
                      value={bookingState.form.comment}
                      onChange={(e) => updateFormField('comment', e.target.value)}
                      placeholder="Если есть пожелания"
                      className="h-12 w-full rounded-2xl border border-white/10 bg-white/5 px-4 text-white outline-none transition placeholder:text-white/25 focus:border-cyan-400/50"
                    />
                  </Field>

                  {submitState.status === 'error' ? (
                    <div className="rounded-2xl border border-rose-400/20 bg-rose-400/10 px-4 py-3 text-sm text-rose-200 md:col-span-2">
                      {submitState.message}
                    </div>
                  ) : null}

                  <div className="rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-white/65 md:col-span-2">
                    Проверьте данные и подтвердите запись. Если это время уже заняли, система предложит выбрать другой слот.
                  </div>

                  <div className="md:col-span-2">
                    <button
                      type="button"
                      onClick={handleSubmit}
                      disabled={submitState.status === 'submitting'}
                      className="inline-flex h-12 w-full items-center justify-center rounded-2xl bg-cyan-400 px-5 text-sm font-semibold text-slate-950 transition hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-60"
                    >
                      {submitState.status === 'submitting'
                        ? 'Создаём запись...'
                        : 'Подтвердить запись'}
                    </button>
                  </div>
                </div>
              ) : (
                <InfoEmpty
                  title="Сначала выберите время"
                  text="После выбора свободного слота здесь откроется короткая форма записи."
                />
              )}
            </SectionCard>
          </div>

          <div className="flex flex-col gap-6">
            <SectionCard title="Ваш выбор" subtitle="Краткое резюме записи.">
              <div className="space-y-3">
                {summaryItems.map((item) => (
                  <div
                    key={item.label}
                    className="flex items-start justify-between gap-4 rounded-2xl border border-white/8 bg-white/[0.03] px-4 py-3"
                  >
                    <div className="text-sm text-white/45">{item.label}</div>
                    <div className="text-right text-sm font-medium text-white/90">
                      {item.value}
                    </div>
                  </div>
                ))}
              </div>
            </SectionCard>

          </div>
        </div>
      </div>
    </div>
  );
}