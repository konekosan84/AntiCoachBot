import React, { useMemo } from 'react';

function normalizeId(value) {
  if (value === null || value === undefined || value === '') return '';
  return String(value);
}

function formatDateRuShort(ymd) {
  if (!ymd) return '';
  const [year, month, day] = String(ymd).split('-').map(Number);
  if (!year || !month || !day) return ymd;

  const date = new Date(year, month - 1, day);
  return date.toLocaleDateString('ru-RU', {
    day: 'numeric',
    month: 'long',
    weekday: 'long',
  });
}

function groupSlotsByTime(slots = []) {
  const map = new Map();

  slots.forEach((slot) => {
    const key = slot.start_time || slot.time || slot.label || '';
    if (!key) return;

    if (!map.has(key)) {
      map.set(key, []);
    }

    map.get(key).push(slot);
  });

  return Array.from(map.entries())
    .map(([time, items]) => ({
      time,
      items: items.sort((a, b) =>
        String(a.employee_name || '').localeCompare(String(b.employee_name || ''), 'ru')
      ),
    }))
    .sort((a, b) => a.time.localeCompare(b.time, 'ru'));
}

function SlotButton({ slot, selected, onClick }) {
  const time =
    slot?.start_time ||
    slot?.time ||
    slot?.label ||
    '';

  return (
    <button
      type="button"
      onClick={() => onClick?.(slot)}
      className={[
        'group rounded-2xl border px-4 py-4 text-left transition',
        selected
          ? 'border-cyan-400/60 bg-cyan-400/12 shadow-[0_0_0_1px_rgba(34,211,238,0.15)]'
          : 'border-white/10 bg-white/[0.03] hover:border-white/20 hover:bg-white/[0.06]',
      ].join(' ')}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div
            className={[
              'text-lg font-semibold',
              selected ? 'text-cyan-200' : 'text-white',
            ].join(' ')}
          >
            {time}
          </div>

          {slot?.employee_name ? (
            <div className="mt-1 text-sm text-white/60">
              {slot.employee_name}
            </div>
          ) : null}
        </div>

        <div
          className={[
            'shrink-0 rounded-full px-3 py-1 text-xs font-medium',
            selected
              ? 'border border-cyan-400/30 bg-cyan-400/20 text-cyan-100'
              : 'border border-white/10 bg-white/[0.04] text-white/60',
          ].join(' ')}
        >
          {selected ? 'выбрано' : 'выбрать'}
        </div>
      </div>
    </button>
  );
}

function TimeGroup({ group, selectedSlotId, onSelect }) {
  const multipleEmployees = group.items.length > 1;

  return (
    <div className="space-y-3 rounded-3xl border border-white/8 bg-white/[0.02] p-4">
      <div className="flex items-center justify-between gap-3">
        <div className="text-base font-semibold text-white">{group.time}</div>

        {multipleEmployees ? (
          <div className="text-xs uppercase tracking-[0.14em] text-white/35">
            {group.items.length} варианта
          </div>
        ) : null}
      </div>

      <div className="grid gap-3">
        {group.items.map((slot) => (
          <SlotButton
            key={normalizeId(slot.id)}
            slot={slot}
            selected={normalizeId(slot.id) === normalizeId(selectedSlotId)}
            onClick={onSelect}
          />
        ))}
      </div>
    </div>
  );
}

export default function SlotsList({
  date,
  slots = [],
  selectedSlot = null,
  onSelectSlot,
}) {
  const groups = useMemo(() => groupSlotsByTime(slots), [slots]);

  if (!slots.length) {
    return (
      <div className="rounded-2xl border border-dashed border-white/10 bg-white/[0.02] p-6 text-center">
        <div className="text-base font-semibold text-white/80">
          Нет свободных слотов
        </div>
        <div className="mt-2 text-sm text-white/45">
          Попробуйте выбрать другой день.
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {date ? (
        <div className="rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-white/70">
          Свободное время на{' '}
          <span className="font-medium text-white/90">
            {formatDateRuShort(date)}
          </span>
        </div>
      ) : null}

      <div className="grid gap-4">
        {groups.map((group) => (
          <TimeGroup
            key={group.time}
            group={group}
            selectedSlotId={selectedSlot?.id}
            onSelect={onSelectSlot}
          />
        ))}
      </div>
    </div>
  );
}