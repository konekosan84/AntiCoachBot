import React, { useMemo, useState } from 'react';

function normalizeId(value) {
  if (value === null || value === undefined || value === '') return '';
  return String(value);
}

function flattenToString(value) {
  if (value === null || value === undefined || value === '') return '';

  if (typeof value === 'string' || typeof value === 'number') {
    return String(value);
  }

  if (Array.isArray(value)) {
    return value.map(flattenToString).filter(Boolean).join(', ');
  }

  if (typeof value === 'object') {
    return Object.values(value).map(flattenToString).filter(Boolean).join(', ');
  }

  return String(value);
}

function extractBranchAddress(branch) {
  return flattenToString(
    branch?.address ||
      branch?.full_address ||
      branch?.location ||
      branch?.branch_address ||
      branch?.address_line ||
      ''
  );
}

function normalizeDuration(service) {
  const raw =
    service?.duration_min ??
    service?.duration_minutes ??
    service?.duration ??
    service?.length_min ??
    null;

  const num = Number(raw);
  return Number.isFinite(num) && num > 0 ? num : null;
}

function SelectField({
  label,
  value,
  onChange,
  placeholder,
  options,
  disabled = false,
  getOptionLabel,
}) {
  return (
    <label className="block">
      <div className="mb-2 text-sm font-medium text-white/75">{label}</div>

      <div className="relative">
        <select
          value={normalizeId(value)}
          onChange={(e) => onChange?.(e.target.value)}
          disabled={disabled}
          className="h-12 w-full appearance-none rounded-2xl border border-white/10 bg-white/5 px-4 pr-11 text-sm text-white outline-none transition focus:border-cyan-400/50 disabled:cursor-not-allowed disabled:opacity-50"
        >
          <option value="" className="bg-slate-900 text-white">
            {placeholder}
          </option>

          {options.map((item) => (
            <option
              key={normalizeId(item.id)}
              value={normalizeId(item.id)}
              className="bg-slate-900 text-white"
            >
              {getOptionLabel(item)}
            </option>
          ))}
        </select>

        <div className="pointer-events-none absolute inset-y-0 right-4 flex items-center text-white/35">
          ▼
        </div>
      </div>
    </label>
  );
}

function ModeSwitcher({ mode, onChange }) {
  return (
    <div className="grid gap-3 md:grid-cols-2">
      <button
        type="button"
        onClick={() => onChange?.('service_first')}
        className={[
          'rounded-2xl border px-4 py-4 text-left transition',
          mode === 'service_first'
            ? 'border-cyan-400/50 bg-cyan-400/10'
            : 'border-white/10 bg-white/[0.03] hover:bg-white/[0.06]',
        ].join(' ')}
      >
        <div className="text-sm font-semibold text-white">По услуге</div>
        <div className="mt-1 text-sm text-white/55">
          Сначала выбираем услугу, потом показываем филиалы с ближайшими окнами.
        </div>
      </button>

      <button
        type="button"
        onClick={() => onChange?.('branch_first')}
        className={[
          'rounded-2xl border px-4 py-4 text-left transition',
          mode === 'branch_first'
            ? 'border-cyan-400/50 bg-cyan-400/10'
            : 'border-white/10 bg-white/[0.03] hover:bg-white/[0.06]',
        ].join(' ')}
      >
        <div className="text-sm font-semibold text-white">По филиалу</div>
        <div className="mt-1 text-sm text-white/55">
          Сначала выбираем адрес, потом показываем доступные услуги и специалистов.
        </div>
      </button>
    </div>
  );
}

function BranchCards({ cards = [], onSelect }) {
  const [isExpanded, setIsExpanded] = useState(false);

  const selectedCard = useMemo(
    () => cards.find((card) => card.isSelected) || null,
    [cards]
  );

  const visibleCards = useMemo(() => {
    if (!selectedCard) return cards;
    return isExpanded ? cards : [selectedCard];
  }, [cards, selectedCard, isExpanded]);

  const handleSelect = (branchId, isAlreadySelected) => {
    if (isAlreadySelected) {
      setIsExpanded((prev) => !prev);
      return;
    }

    onSelect?.(branchId);
    setIsExpanded(false);
  };

  if (!cards.length) {
    return (
      <div className="rounded-2xl border border-dashed border-white/10 bg-white/[0.02] p-6 text-sm text-white/50">
        Нет подходящих филиалов под текущий выбор.
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {selectedCard ? (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-white/8 bg-white/[0.02] px-4 py-3">
          <div className="text-sm text-white/70">
            {isExpanded ? 'Выберите другой филиал из списка ниже' : 'Выбран один филиал'}
          </div>

          <button
            type="button"
            onClick={() => setIsExpanded((prev) => !prev)}
            className="inline-flex items-center rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2 text-sm font-medium text-white/85 transition hover:bg-white/[0.06]"
          >
            {isExpanded ? 'Оставить только выбранный' : 'Выбрать другой филиал'}
          </button>
        </div>
      ) : null}

      <div className="grid gap-4 xl:grid-cols-2">
        {visibleCards.map((card) => {
          const nearestText =
            card.nearestSlot?.text ||
            (card.nearestSlot?.date && (card.nearestSlot?.start_time || card.nearestSlot?.time)
              ? `${card.nearestSlot.date} • ${card.nearestSlot.start_time || card.nearestSlot.time}`
              : '');

          return (
            <button
              key={normalizeId(card.id)}
              type="button"
              onClick={() => handleSelect(card.id, card.isSelected)}
              className={[
                'rounded-3xl border px-4 py-4 text-left transition',
                card.isSelected
                  ? 'border-cyan-400/60 bg-cyan-400/10'
                  : 'border-white/10 bg-white/[0.03] hover:border-white/20 hover:bg-white/[0.06]',
              ].join(' ')}
            >
              <div className="flex items-start justify-between gap-4">
                <div className="min-w-0">
                  <div className="text-base font-semibold text-white">
                    {card.name || 'Филиал'}
                  </div>

                  <div className="mt-2 text-sm text-white/65">
                    {card.address || 'Адрес не указан'}
                  </div>
                </div>

                {card.isSelected ? (
                  <div className="rounded-full border border-cyan-400/30 bg-cyan-400/20 px-3 py-1 text-xs font-medium text-cyan-200">
                    выбран
                  </div>
                ) : (
                  <div className="rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-xs font-medium text-white/70">
                    выбрать
                  </div>
                )}
              </div>

              <div className="mt-4 rounded-2xl border border-white/8 bg-slate-950/20 px-4 py-3">
                <div className="text-[11px] uppercase tracking-[0.16em] text-white/35">
                  Ближайшее время
                </div>

                <div className="mt-1 text-base font-semibold text-white/95">
                  {nearestText || 'Пока нет доступных окон'}
                </div>

                {card.nearestSlot?.employee_name ? (
                  <div className="mt-1 text-sm text-white/55">
                    {card.nearestSlot.employee_name}
                  </div>
                ) : null}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

export default function FilterPanel({
  mode = 'service_first',
  branches = [],
  services = [],
  servicesForBranch = [],
  employees = [],
  value = {
    branch_id: null,
    service_id: null,
    employee_id: null,
  },
  branchCards = [],
  loadingShifts = false,
  shiftsError = '',
  onModeChange,
  onBranchChange,
  onServiceChange,
  onEmployeeChange,
}) {
  const branchSelected = Boolean(value.branch_id);
  const serviceSelected = Boolean(value.service_id);

  return (
    <div className="space-y-5">
      <ModeSwitcher mode={mode} onChange={onModeChange} />

      {mode === 'service_first' ? (
        <>
          <div className="grid gap-4 lg:grid-cols-2">
            <SelectField
              label="Услуга"
              value={value.service_id}
              onChange={onServiceChange}
              placeholder="Выберите услугу"
              options={services}
              getOptionLabel={(item) => {
                const duration = normalizeDuration(item);
                const price =
                  item.price !== undefined && item.price !== null ? ` · ${item.price} ₽` : '';
                const durationText = duration ? ` · ${duration} мин` : '';
                return `${item.name || `Услуга #${item.id}`}${durationText}${price}`;
              }}
            />

            <SelectField
              label="Специалист"
              value={value.employee_id}
              onChange={onEmployeeChange}
              placeholder="Любой доступный или конкретный"
              options={employees}
              disabled={!serviceSelected}
              getOptionLabel={(item) =>
                `${item.full_name || item.name || `Сотрудник #${item.id}`}${
                  item.position ? ` · ${item.position}` : ''
                }`
              }
            />
          </div>

          {serviceSelected ? (
            <div className="space-y-3">
              <div className="text-sm font-medium text-white/75">
                Выберите филиал по адресу и ближайшему времени
              </div>

              {loadingShifts && !branchCards.length ? (
                <div className="rounded-2xl border border-dashed border-white/10 bg-white/[0.02] p-4 text-sm text-white/45">
                  Ищем филиалы с реальными доступными окнами.
                </div>
              ) : shiftsError ? (
                <div className="rounded-2xl border border-rose-400/20 bg-rose-400/10 p-4 text-sm text-rose-200">
                  {shiftsError}
                </div>
              ) : (
                <BranchCards cards={branchCards} onSelect={onBranchChange} />
              )}
            </div>
          ) : (
            <div className="rounded-2xl border border-dashed border-white/10 bg-white/[0.02] p-4 text-sm text-white/45">
              Сначала выберите услугу. После этого покажем филиалы с ближайшим временем.
            </div>
          )}
        </>
      ) : (
        <div className="grid gap-4 lg:grid-cols-3">
          <SelectField
            label="Филиал"
            value={value.branch_id}
            onChange={onBranchChange}
            placeholder="Выберите филиал"
            options={branches}
            getOptionLabel={(item) => {
              const name = item.name || `Филиал #${item.id}`;
              const address = extractBranchAddress(item);
              return address ? `${name} — ${address}` : name;
            }}
          />

          <SelectField
            label="Услуга"
            value={value.service_id}
            onChange={onServiceChange}
            placeholder={branchSelected ? 'Выберите услугу' : 'Сначала выберите филиал'}
            options={servicesForBranch}
            disabled={!branchSelected}
            getOptionLabel={(item) => {
              const duration = normalizeDuration(item);
              const price =
                item.price !== undefined && item.price !== null ? ` · ${item.price} ₽` : '';
              const durationText = duration ? ` · ${duration} мин` : '';
              return `${item.name || `Услуга #${item.id}`}${durationText}${price}`;
            }}
          />

          <SelectField
            label="Специалист"
            value={value.employee_id}
            onChange={onEmployeeChange}
            placeholder={serviceSelected ? 'Любой доступный или конкретный' : 'Сначала выберите услугу'}
            options={employees}
            disabled={!serviceSelected}
            getOptionLabel={(item) =>
              `${item.full_name || item.name || `Сотрудник #${item.id}`}${
                item.position ? ` · ${item.position}` : ''
              }`
            }
          />
        </div>
      )}
    </div>
  );
}