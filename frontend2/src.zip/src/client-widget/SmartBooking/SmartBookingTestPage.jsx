import React, { useEffect, useMemo, useState } from 'react';
import SmartBooking from './SmartBooking';
import { getBranches } from '../../api/branches';
import { getServices } from '../../api/services';
import { getEmployees } from '../../api/employees';

function pickArray(payload) {
  if (Array.isArray(payload)) return payload;
  if (Array.isArray(payload?.items)) return payload.items;
  if (Array.isArray(payload?.data)) return payload.data;
  if (Array.isArray(payload?.rows)) return payload.rows;
  return [];
}

function normalizeBranches(rawList) {
  return pickArray(rawList).map((item) => ({
    ...item,
    id: item.id,
    name:
      item.name ||
      item.title ||
      item.branch_name ||
      item.label ||
      `Филиал #${item.id}`,
  }));
}

function normalizeServices(rawList) {
  return pickArray(rawList).map((item) => ({
    ...item,
    id: item.id,
    name:
      item.name ||
      item.title ||
      item.service_name ||
      item.label ||
      `Услуга #${item.id}`,
    price: item.price ?? item.cost ?? item.amount ?? null,
    duration:
      item.duration ??
      item.duration_min ??
      item.duration_minutes ??
      item.length_min ??
      60,
    duration_min:
      item.duration_min ??
      item.duration_minutes ??
      item.duration ??
      item.length_min ??
      60,
    branch_id:
      item.branch_id ??
      item.branchId ??
      item.branch?.id ??
      null,
    branch_ids:
      Array.isArray(item.branch_ids)
        ? item.branch_ids
        : Array.isArray(item.branches)
        ? item.branches.map((b) => (typeof b === 'object' ? b.id : b))
        : undefined,
  }));
}

function normalizeEmployees(rawList) {
  return pickArray(rawList).map((item) => {
    const fullName =
      item.full_name ||
      item.fullName ||
      item.name ||
      [item.last_name, item.first_name, item.middle_name].filter(Boolean).join(' ') ||
      `Сотрудник #${item.id}`;

    const branchIds =
      Array.isArray(item.branch_ids)
        ? item.branch_ids
        : Array.isArray(item.branches)
        ? item.branches.map((b) => (typeof b === 'object' ? b.id : b))
        : item.branch_id != null
        ? [item.branch_id]
        : [];

    const serviceIds =
      Array.isArray(item.service_ids)
        ? item.service_ids
        : Array.isArray(item.services)
        ? item.services.map((s) => (typeof s === 'object' ? s.id : s))
        : item.service_id != null
        ? [item.service_id]
        : [];

    return {
      ...item,
      id: item.id,
      full_name: fullName,
      name: fullName,
      branch_id: item.branch_id ?? branchIds[0] ?? null,
      branch_ids: branchIds,
      service_ids: serviceIds,
    };
  });
}

function LoadingCard() {
  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top,#172554_0%,#0f172a_35%,#020617_100%)] p-6 text-white">
      <div className="mx-auto max-w-4xl rounded-3xl border border-white/10 bg-slate-900/70 p-8 shadow-[0_12px_40px_rgba(0,0,0,0.18)]">
        <div className="text-2xl font-semibold">Загрузка клиентского виджета…</div>
        <div className="mt-3 text-white/60">
          Подтягиваем реальные филиалы, услуги и сотрудников.
        </div>
      </div>
    </div>
  );
}

function ErrorCard({ error, onRetry }) {
  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top,#172554_0%,#0f172a_35%,#020617_100%)] p-6 text-white">
      <div className="mx-auto max-w-4xl rounded-3xl border border-red-400/20 bg-slate-900/70 p-8 shadow-[0_12px_40px_rgba(0,0,0,0.18)]">
        <div className="text-2xl font-semibold text-red-300">Не удалось загрузить данные</div>
        <div className="mt-3 whitespace-pre-wrap text-white/70">
          {error || 'Неизвестная ошибка'}
        </div>
        <button
          type="button"
          onClick={onRetry}
          className="mt-6 inline-flex h-11 items-center justify-center rounded-2xl bg-cyan-400 px-5 text-sm font-semibold text-slate-950 transition hover:brightness-110"
        >
          Повторить
        </button>
      </div>
    </div>
  );
}

export default function SmartBookingTestPage() {
  const [branches, setBranches] = useState([]);
  const [services, setServices] = useState([]);
  const [employees, setEmployees] = useState([]);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const loadData = async () => {
    setLoading(true);
    setError('');

    try {
      const [branchesRes, servicesRes, employeesRes] = await Promise.all([
        getBranches(),
        getServices(),
        getEmployees(),
      ]);

      const normalizedBranches = normalizeBranches(branchesRes);
      const normalizedServices = normalizeServices(servicesRes);
      const normalizedEmployees = normalizeEmployees(employeesRes);

      setBranches(normalizedBranches);
      setServices(normalizedServices);
      setEmployees(normalizedEmployees);

      console.log('SmartBookingTestPage → branches:', normalizedBranches);
      console.log('SmartBookingTestPage → services:', normalizedServices);
      console.log('SmartBookingTestPage → employees:', normalizedEmployees);
    } catch (err) {
      console.error('SmartBookingTestPage loadData error:', err);
      setError(
        err?.response?.data?.error ||
          err?.message ||
          'Ошибка загрузки филиалов, услуг или сотрудников'
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const debugInfo = useMemo(
    () => ({
      branches: branches.length,
      services: services.length,
      employees: employees.length,
    }),
    [branches, services, employees]
  );

  if (loading) {
    return <LoadingCard />;
  }

  if (error) {
    return <ErrorCard error={error} onRetry={loadData} />;
  }

  return (
    <div>
      <div className="fixed bottom-4 right-4 z-50 rounded-2xl border border-white/10 bg-slate-950/85 px-4 py-3 text-xs text-white/75 shadow-lg backdrop-blur">
        <div>Филиалы: {debugInfo.branches}</div>
        <div>Услуги: {debugInfo.services}</div>
        <div>Сотрудники: {debugInfo.employees}</div>
      </div>

      <SmartBooking
        branches={branches}
        services={services}
        employees={employees}
      />
    </div>
  );
}