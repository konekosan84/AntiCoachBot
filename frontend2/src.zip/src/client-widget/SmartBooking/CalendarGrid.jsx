import React, { useMemo, useState } from 'react';

const WEEKDAYS = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
const MONTH_NAMES = [
  'Январь',
  'Февраль',
  'Март',
  'Апрель',
  'Май',
  'Июнь',
  'Июль',
  'Август',
  'Сентябрь',
  'Октябрь',
  'Ноябрь',
  'Декабрь',
];

function toYmdLocal(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function fromYmd(ymd) {
  const [year, month, day] = String(ymd).split('-').map(Number);
  return new Date(year, month - 1, day);
}

function isSameYmd(a, b) {
  return String(a || '') === String(b || '');
}

function buildMonthGrid(year, month) {
  const firstDay = new Date(year, month, 1);
  const firstWeekday = (firstDay.getDay() + 6) % 7;
  const firstCell = new Date(year, month, 1 - firstWeekday);

  return Array.from({ length: 42 }, (_, index) => {
    const date = new Date(firstCell);
    date.setDate(firstCell.getDate() + index);
    return date;
  });
}

export default function CalendarGrid({
  selectedDate,
  onSelectDate,
  availableDates = [],
}) {
  const initialDate =
    availableDates.length > 0
      ? fromYmd(availableDates[0])
      : selectedDate
      ? fromYmd(selectedDate)
      : new Date();

  const [current, setCurrent] = useState({
    year: initialDate.getFullYear(),
    month: initialDate.getMonth(),
  });

  const availableDatesSet = useMemo(() => new Set(availableDates), [availableDates]);

  const days = useMemo(() => {
    return buildMonthGrid(current.year, current.month);
  }, [current.year, current.month]);

  const goPrev = () => {
    setCurrent((prev) => {
      const month = prev.month - 1;
      if (month < 0) {
        return { year: prev.year - 1, month: 11 };
      }
      return { ...prev, month };
    });
  };

  const goNext = () => {
    setCurrent((prev) => {
      const month = prev.month + 1;
      if (month > 11) {
        return { year: prev.year + 1, month: 0 };
      }
      return { ...prev, month };
    });
  };

  return (
    <div className="rounded-3xl border border-white/10 bg-white/[0.03] p-4">
      <div className="mb-4 flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={goPrev}
          className="inline-flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-white/80 transition hover:bg-white/10 hover:text-white"
        >
          ←
        </button>

        <div className="text-center">
          <div className="text-base font-semibold text-white">
            {MONTH_NAMES[current.month]} {current.year}
          </div>
          <div className="mt-1 text-xs text-white/45">Выберите день записи</div>
        </div>

        <button
          type="button"
          onClick={goNext}
          className="inline-flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-white/80 transition hover:bg-white/10 hover:text-white"
        >
          →
        </button>
      </div>

      <div className="mb-3 grid grid-cols-7 gap-2">
        {WEEKDAYS.map((day) => (
          <div
            key={day}
            className="flex h-10 items-center justify-center text-xs font-medium uppercase tracking-[0.12em] text-white/35"
          >
            {day}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-7 gap-2">
        {days.map((date) => {
          const ymd = toYmdLocal(date);
          const isCurrentMonth = date.getMonth() === current.month;
          const isSelected = isSameYmd(selectedDate, ymd);
          const isAvailable = availableDatesSet.has(ymd);

          return (
            <button
              key={ymd}
              type="button"
              disabled={!isAvailable}
              onClick={() => onSelectDate?.(ymd)}
              className={[
                'h-12 rounded-2xl border text-sm font-medium transition',
                isSelected
                  ? 'border-cyan-300 bg-cyan-400 text-slate-950'
                  : isAvailable
                  ? 'border-white/8 bg-white/[0.04] text-white hover:border-white/20 hover:bg-white/[0.08]'
                  : isCurrentMonth
                  ? 'cursor-not-allowed border-white/5 bg-white/[0.02] text-white/20'
                  : 'cursor-not-allowed border-white/5 bg-white/[0.02] text-white/10',
              ].join(' ')}
            >
              {date.getDate()}
            </button>
          );
        })}
      </div>
    </div>
  );
}