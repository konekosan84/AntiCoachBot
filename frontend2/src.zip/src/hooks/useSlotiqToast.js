import { useCallback } from "react";

export function useSlotiqToast() {
  const showToast = useCallback((message, type = "info") => {
    const toast = document.createElement("div");
    toast.textContent = message;
    toast.className = `fixed bottom-4 right-4 px-4 py-2 rounded-xl shadow-lg text-white 
      ${type === "success" ? "bg-gradient-to-r from-green-400 to-emerald-500" :
        type === "error" ? "bg-gradient-to-r from-rose-500 to-red-600" :
        "bg-gradient-to-r from-indigo-400 to-blue-500"}`;
    toast.style.transition = "all 0.4s ease";
    toast.style.opacity = "0";
    toast.style.transform = "translateY(20px)";
    document.body.appendChild(toast);

    requestAnimationFrame(() => {
      toast.style.opacity = "1";
      toast.style.transform = "translateY(0)";
    });

    setTimeout(() => {
      toast.style.opacity = "0";
      toast.style.transform = "translateY(20px)";
      setTimeout(() => toast.remove(), 400);
    }, 3000);

    if (navigator.vibrate) navigator.vibrate(150);
  }, []);

  return { showToast };
}
