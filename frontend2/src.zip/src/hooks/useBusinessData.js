import { useEffect, useState } from "react";
import api from "../api/api";

export default function useBusinessData() {
  const [branches, setBranches] = useState([]);
  const [rooms, setRooms] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [services, setServices] = useState([]);

  useEffect(() => {
    api.get("/branches").then(res => setBranches(res.data));
    api.get("/rooms").then(res => setRooms(res.data));
    api.get("/employees").then(res => setEmployees(res.data));
    api.get("/services").then(res => setServices(res.data));
  }, []);

  return { branches, rooms, employees, services };
}
