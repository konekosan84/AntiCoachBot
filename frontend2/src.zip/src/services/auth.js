import axios from "axios";

const API = "http://localhost:4000/api/auth";

export async function loginRequest(email, password) {
  try {
    const res = await axios.post(`${API}/login`, {
      email,
      password
    });
    return res.data; 
  } catch (err) {
    console.error("LOGIN ERROR:", err);
    throw err;
  }
}
