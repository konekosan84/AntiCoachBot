import { useEffect, useMemo, useState } from "react";

export default function RoomSidePanel({ room, branches, onClose, onSaved }) {
  const sortedBranches = useMemo(() => {
    return (branches || [])
      .slice()
      .sort((a, b) =>
        (a.name || "").localeCompare(b.name || "", "ru", { sensitivity: "base" })
      );
  }, [branches]);

  const [form, setForm] = useState({
    name: "",
    branch_ids: [],
    capacity: "",
    description: "",
    is_active: true,
  });

  useEffect(() => {
    if (room) {
      setForm({
        name: room.name || "",
        branch_ids: Array.isArray(room.branch_ids)
          ? room.branch_ids
          : room.branch_id
            ? [room.branch_id]
            : [],
        capacity: room.capacity ?? "",
        description: room.description || "",
        is_active: room.is_active ?? true,
      });
    } else {
      setForm({
        name: "",
        branch_ids: [],
        capacity: "",
        description: "",
        is_active: true,
      });
    }
  }, [room]);

  const update = (key, value) => setForm(prev => ({ ...prev, [key]: value }));

  const toggleBranch = (branchId, checked) => {
    const set = new Set(form.branch_ids || []);
    if (checked) set.add(branchId);
    else set.delete(branchId);
    update("branch_ids", Array.from(set));
  };

  return (
    <div
      style={{
        position: "fixed",
        top: 0,
        right: 0,
        width: 420,
        height: "100vh",
        padding: 24,
        background: "rgba(15,23,42,0.95)",
        borderLeft: "1px solid rgba(255,255,255,0.08)",
        zIndex: 100,
      }}
    >
      <div style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
        <h3 style={{ marginBottom: 20 }}>
          {room ? "Редактировать помещение" : "Новое помещение"}
        </h3>

        <button
          onClick={onClose}
          title="Закрыть"
          style={{
            width: 38,
            height: 38,
            borderRadius: 12,
            border: "1px solid rgba(255,255,255,0.12)",
            background: "rgba(255,255,255,0.06)",
            cursor: "pointer",
            color: "#fff",
          }}
        >
          ✕
        </button>
      </div>

      <input
        placeholder="Название"
        value={form.name}
        onChange={e => update("name", e.target.value)}
        style={inputStyle}
      />

      {/* MULTI BRANCH SELECT */}
      <div style={{ marginBottom: 12 }}>
        <div style={{ fontSize: 13, opacity: 0.8, marginBottom: 8 }}>
          Филиалы (можно несколько)
        </div>

        <div
          style={{
            border: "1px solid rgba(255,255,255,.15)",
            background: "rgba(255,255,255,.06)",
            borderRadius: 10,
            padding: 10,
            maxHeight: 180,
            overflow: "auto",
          }}
        >
          {sortedBranches.map(b => {
            const checked = form.branch_ids?.includes(b.id);
            return (
              <label
                key={b.id}
                style={{
                  display: "flex",
                  gap: 10,
                  alignItems: "center",
                  padding: "6px 0",
                  color: "#fff",
                }}
              >
                <input
                  type="checkbox"
                  checked={!!checked}
                  onChange={e => toggleBranch(b.id, e.target.checked)}
                />
                <span>{b.name}</span>
              </label>
            );
          })}
        </div>
      </div>

      <input
        placeholder="Вместимость"
        value={form.capacity}
        onChange={e =>
          update("capacity", e.target.value === "" ? "" : Number(e.target.value))
        }
        style={inputStyle}
      />

      <textarea
        placeholder="Описание"
        value={form.description}
        onChange={e => update("description", e.target.value)}
        style={{ ...inputStyle, height: 90 }}
      />

      <label style={{ display: "block", marginBottom: 20, opacity: 0.9 }}>
        <input
          type="checkbox"
          checked={!!form.is_active}
          onChange={e => update("is_active", e.target.checked)}
        />{" "}
        Активно
      </label>

      <div style={{ display: "flex", gap: 12 }}>
        <button
          onClick={() => {
            onSaved({
              ...form,
              branch_ids: (form.branch_ids || []).map(Number).filter(Boolean),
              capacity: form.capacity === "" ? null : form.capacity,
            });
          }}
          style={primaryBtn}
        >
          Сохранить
        </button>

        <button onClick={onClose} style={secondaryBtn}>
          Отмена
        </button>
      </div>
    </div>
  );
}

const inputStyle = {
  width: "100%",
  marginBottom: 12,
  padding: "10px 12px",
  borderRadius: 10,
  border: "1px solid rgba(255,255,255,.15)",
  background: "rgba(255,255,255,.06)",
  color: "#fff",
};

const primaryBtn = {
  padding: "10px 16px",
  borderRadius: 10,
  border: "none",
  background: "#6C5CE7",
  color: "#fff",
  cursor: "pointer",
};

const secondaryBtn = {
  padding: "10px 16px",
  borderRadius: 10,
  border: "none",
  background: "rgba(255,255,255,.12)",
  color: "#fff",
  cursor: "pointer",
};
