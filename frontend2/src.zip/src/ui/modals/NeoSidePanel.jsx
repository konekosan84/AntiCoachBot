import "../styles/neo/neo-sidepanel.css";

export default function NeoSidePanel({ isOpen, onClose, title, children }) {
    return (
        <div className={`neo-sidepanel ${isOpen ? "open" : ""}`}>
            <div className="neo-sidepanel-header">
                <h2>{title}</h2>
                <button className="neo-sidepanel-close" onClick={onClose}>×</button>
            </div>

            <div className="neo-sidepanel-body">
                {children}
            </div>
        </div>
    );
}
