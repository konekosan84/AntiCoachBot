import { useEffect, useState } from "react";

export default function ServiceSidePanel({
  service,
  onClose,
  onSaved,
}) {
  const [form, setForm] = useState({
    name: "",
    price: "",
    duration: "",
    description: "",
    is_active: true,
  });

  useEffect(() => {
    if (service) {
      setForm({
        name: service.name || "",
        price: service.price ?? "",
        duration: service.duration ?? "",
        description: service.description || "",
        is_active: service.is_active ?? true,
      });
    }
  }, [service]);

  const update = (key, value) =>
    setForm(prev => ({ ...prev, [key]: value }));

  return (
    <div
      style={{
        position: "fixed",
        top: 0,
        right: 0,
        width: 420,
        height: "100vh",
        padding: 24,
        background: "rgba(15,23,42,0.95)",
        borderLeft: "1px solid rgba(255,255,255,0.08)",
        zIndex: 100,
      }}
    >
      <h3 style={{ marginBottom: 20 }}>
        {service ? "Редактировать услугу" : "Новая услуга"}
      </h3>

      <input
        placeholder="Название"
        value={form.name}
        onChange={e => update("name", e.target.value)}
        style={inputStyle}
      />

      <input
        placeholder="Цена"
        value={form.price}
        onChange={e => update("price", e.target.value)}
        style={inputStyle}
      />

      <input
        placeholder="Длительность (мин)"
        value={form.duration}
        onChange={e => update("duration", e.target.value)}
        style={inputStyle}
      />

      <textarea
        placeholder="Описание"
        value={form.description}
        onChange={e => update("description", e.target.value)}
        style={{ ...inputStyle, height: 80 }}
      />

      <label style={{ display: "block", marginBottom: 20 }}>
        <input
          type="checkbox"
          checked={form.is_active}
          onChange={e => update("is_active", e.target.checked)}
        />{" "}
        Активна
      </label>

      <div style={{ display: "flex", gap: 12 }}>
        <button
          onClick={() => onSaved(form)}
          style={primaryBtn}
        >
          Сохранить
        </button>

        <button
          onClick={onClose}
          style={secondaryBtn}
        >
          Отмена
        </button>
      </div>
    </div>
  );
}

const inputStyle = {
  width: "100%",
  marginBottom: 12,
  padding: "10px 12px",
  borderRadius: 10,
  border: "1px solid rgba(255,255,255,.15)",
  background: "rgba(255,255,255,.06)",
  color: "#fff",
};

const primaryBtn = {
  padding: "10px 16px",
  borderRadius: 10,
  border: "none",
  background: "#6C5CE7",
  color: "#fff",
  cursor: "pointer",
};

const secondaryBtn = {
  padding: "10px 16px",
  borderRadius: 10,
  border: "none",
  background: "rgba(255,255,255,.12)",
  color: "#fff",
  cursor: "pointer",
};
