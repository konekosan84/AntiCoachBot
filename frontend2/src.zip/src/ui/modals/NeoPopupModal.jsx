// src/ui/modals/NeoPopupModal.jsx
// Универсальное всплывающее модальное окно SLOTIQ PRO
// для фото, быстрых описаний, предпросмотров контента

import React, { useEffect } from "react";
import { IoCloseOutline } from "react-icons/io5";

const NeoPopupModal = ({
  open,
  onClose,
  width = "520px",
  title = "",
  children,
}) => {
  useEffect(() => {
    if (open) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
  }, [open]);

  if (!open) return null;

  return (
    <div className="neo-popup-overlay" onClick={onClose}>
      <div
        className="neo-popup"
        style={{ width }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* HEADER */}
        <div className="neo-popup-header">
          <h3 className="neo-popup-title">{title}</h3>

          <button className="neo-popup-close-btn" onClick={onClose}>
            <IoCloseOutline size={28} />
          </button>
        </div>

        {/* CONTENT */}
        <div className="neo-popup-content">{children}</div>
      </div>
    </div>
  );
};

export default NeoPopupModal;

