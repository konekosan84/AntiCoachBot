import React from "react";
import "../styles/neo/neo-card.css";
import { FiEdit3, FiTrash2 } from "react-icons/fi";

export default function NeoCard({
  title,
  subtitle,
  stats = [],
  onEdit,
  onDelete,
}) {
  return (
    <div className="neo-card">
      <div className="neo-card-top">
        <div className="neo-card-titles">
          <div className="neo-card-title">{title}</div>
          {subtitle && <div className="neo-card-subtitle">{subtitle}</div>}
        </div>

        <div className="neo-card-actions">
          {onEdit && (
            <button className="neo-icon-btn" onClick={onEdit}>
              <FiEdit3 />
            </button>
          )}
          {onDelete && (
            <button className="neo-icon-btn danger" onClick={onDelete}>
              <FiTrash2 />
            </button>
          )}
        </div>
      </div>

      <div className="neo-card-body">
        {stats.map((s, i) => (
          <div key={i} className="neo-card-stat">
            {s.icon && <span className="stat-icon">{s.icon}</span>}
            {s.label}: <strong>{s.value}</strong>
          </div>
        ))}
      </div>
    </div>
  );
}
