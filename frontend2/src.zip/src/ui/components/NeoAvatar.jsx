import React from "react";
import "../styles/neo/neo-avatar.css";

export default function NeoAvatar({ src }) {
  return (
    <div className="neo-avatar">
      {src ? (
        <img src={src} alt="avatar" />
      ) : (
        <div className="neo-avatar-placeholder">📷</div>
      )}
    </div>
  );
}
