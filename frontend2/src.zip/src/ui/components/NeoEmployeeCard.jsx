import { Pencil, Trash2 } from "lucide-react";

export default function NeoEmployeeCard({
  employee,
  onClick,
  onEdit,
  onDelete,
}) {
  if (!employee) return null;

  const name = employee.full_name || employee.name || "Без имени";
  const position = employee.position || "—";
  const role = employee.role || "employee";
  const status = employee.status || "active";
  const branches = employee.branches || [];
  const services = employee.services || [];

  const initials =
    name
      .split(" ")
      .filter(Boolean)
      .map(w => w[0])
      .slice(0, 2)
      .join("")
      .toUpperCase() || "?";

  const statusColor = {
    active: "#22c55e",
    vacation: "#eab308",
    sick: "#ef4444",
    inactive: "#9ca3af",
    fired: "#6b7280",
  }[status] || "#9ca3af";

  return (
    <div
      onClick={() => onClick?.(employee)}
      style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        gap: 16,
        padding: "14px 16px",
        borderRadius: 18,
        background:
          "linear-gradient(145deg, rgba(15,27,46,0.85), rgba(11,18,32,0.85))",
        border: "1px solid rgba(255,255,255,0.12)",
        boxShadow: "0 0 24px rgba(0,255,255,0.08)",
        cursor: "pointer",
      }}
    >
      {/* LEFT */}
      <div style={{ display: "flex", gap: 14, alignItems: "center", minWidth: 0 }}>
        {/* AVATAR */}
        <div
          style={{
            width: 46,
            height: 46,
            borderRadius: 14,
            background:
              "linear-gradient(135deg, rgba(58,207,213,1), rgba(101,88,245,1))",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontWeight: 900,
            color: "white",
            flexShrink: 0,
          }}
        >
          {initials}
        </div>

        {/* INFO */}
        <div style={{ minWidth: 0 }}>
          <div
            style={{
              fontSize: 16,
              fontWeight: 900,
              color: "white",
              whiteSpace: "nowrap",
              overflow: "hidden",
              textOverflow: "ellipsis",
              maxWidth: 420,
            }}
          >
            {name}
          </div>

          <div style={{ fontSize: 13, color: "rgba(255,255,255,0.65)", marginTop: 2 }}>
            {position}
          </div>

          {/* BADGES */}
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 6 }}>
            <span
              style={{
                fontSize: 12,
                padding: "4px 10px",
                borderRadius: 999,
                background: "rgba(255,255,255,0.08)",
                border: "1px solid rgba(255,255,255,0.12)",
                color: "rgba(255,255,255,0.85)",
                fontWeight: 700,
              }}
            >
              {role}
            </span>

            <span
              style={{
                fontSize: 12,
                padding: "4px 10px",
                borderRadius: 999,
                background: `${statusColor}22`,
                color: statusColor,
                fontWeight: 700,
              }}
            >
              {status}
            </span>
          </div>

          {/* BRANCHES */}
          {branches.length > 0 && (
            <div
              style={{
                marginTop: 6,
                fontSize: 12,
                color: "rgba(255,255,255,0.55)",
              }}
            >
              {branches.map(b => b.name).join(", ")}
            </div>
          )}

          {/* SERVICES */}
          {services.length > 0 && (
            <div
              style={{
                marginTop: 4,
                fontSize: 12,
                color: "rgba(255,255,255,0.45)",
              }}
            >
              {services.map(s => s.name).join(", ")}
            </div>
          )}
        </div>
      </div>

      {/* ACTIONS */}
      <div
        style={{ display: "flex", gap: 8 }}
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={() => onEdit?.(employee)}
          style={iconBtn}
          title="Редактировать"
        >
          <Pencil size={16} color="#3acfd5" />
        </button>

        <button
          onClick={() => onDelete?.(employee)}
          style={iconBtn}
          title="Удалить"
        >
          <Trash2 size={16} color="#f87171" />
        </button>
      </div>
    </div>
  );
}

const iconBtn = {
  width: 38,
  height: 38,
  borderRadius: 12,
  border: "1px solid rgba(255,255,255,0.12)",
  background: "rgba(255,255,255,0.06)",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  cursor: "pointer",
};

