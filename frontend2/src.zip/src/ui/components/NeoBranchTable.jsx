import { Pencil, Trash2 } from "lucide-react";

export default function NeoBranchTable({
  branches = [],
  onEdit,
  onDelete,
}) {
  return (
    <table className="neo-table">
      <thead>
        <tr>
          <th>Название</th>
          <th>Адрес</th>
          <th>Телефон</th>
          <th>Статус</th>
          <th style={{ width: 96 }}></th>
        </tr>
      </thead>

      <tbody>
        {branches.map(branch => (
          <tr
            key={branch.id}
            onClick={() => onEdit(branch)}
            style={{ cursor: "pointer" }}
          >
            <td>{branch.name || "—"}</td>
            <td style={{ opacity: 0.8 }}>
              {branch.address || "—"}
            </td>
            <td style={{ opacity: 0.7 }}>
              {branch.phone || "—"}
            </td>
            <td>{branch.status || "—"}</td>

            <td
              onClick={e => e.stopPropagation()}
              style={{ display: "flex", gap: 8 }}
            >
              <button
                className="neo-icon-btn"
                onClick={() => onEdit(branch)}
                title="Редактировать"
              >
                <Pencil size={16} />
              </button>

              <button
                className="neo-icon-btn danger"
                onClick={() => onDelete(branch)}
                title="Удалить"
              >
                <Trash2 size={16} />
              </button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
