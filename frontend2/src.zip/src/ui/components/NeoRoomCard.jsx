export default function NeoRoomCard({ room, branches, onClick, onEdit, onDelete }) {
  const isActive = !!room.is_active;
  const branchName =
    branches?.find(b => b.id === room.branch_id)?.name || "—";

  return (
    <div
      onClick={onClick}
      style={{
        padding: 16,
        borderRadius: 16,
        background: "rgba(255,255,255,0.04)",
        border: "1px solid rgba(255,255,255,0.08)",
        cursor: "pointer",
        display: "flex",
        justifyContent: "space-between",
        gap: 12,
      }}
    >
      <div style={{ minWidth: 0 }}>
        <div style={{ fontSize: 16, fontWeight: 700, marginBottom: 8 }}>
          {room.name}
        </div>

        <div style={{ fontSize: 14, opacity: 0.85, lineHeight: 1.45 }}>
          <div>Филиал: {branchName}</div>
          <div>Вместимость: {room.capacity ?? "—"}</div>
          <div style={{ opacity: 0.8 }}>
            {room.description ? room.description : "—"}
          </div>
        </div>

        <div style={{ marginTop: 10 }}>
          <span
            style={{
              display: "inline-block",
              padding: "4px 10px",
              borderRadius: 999,
              fontSize: 12,
              fontWeight: 700,
              background: isActive ? "rgba(16,185,129,0.20)" : "rgba(148,163,184,0.18)",
              color: isActive ? "#34D399" : "#9CA3AF",
              border: "1px solid rgba(255,255,255,0.08)",
            }}
          >
            {isActive ? "active" : "inactive"}
          </span>
        </div>
      </div>

      <div
        style={{ display: "flex", gap: 10, alignItems: "center" }}
        onClick={e => e.stopPropagation()}
      >
        <IconBtn title="Редактировать" onClick={onEdit}>
          <PencilIcon />
        </IconBtn>
        <IconBtn title="Удалить" onClick={onDelete}>
          <TrashIcon />
        </IconBtn>
      </div>
    </div>
  );
}

function IconBtn({ children, onClick, title }) {
  return (
    <button
      title={title}
      onClick={onClick}
      style={{
        width: 38,
        height: 38,
        borderRadius: 12,
        border: "1px solid rgba(255,255,255,0.12)",
        background: "rgba(255,255,255,0.06)",
        cursor: "pointer",
        display: "grid",
        placeItems: "center",
      }}
    >
      {children}
    </button>
  );
}

function PencilIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
      <path d="M12 20h9" stroke="#35D7FF" strokeWidth="2" strokeLinecap="round" />
      <path
        d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5Z"
        stroke="#35D7FF"
        strokeWidth="2"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function TrashIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
      <path d="M3 6h18" stroke="#FF4D5A" strokeWidth="2" strokeLinecap="round" />
      <path d="M8 6V4h8v2" stroke="#FF4D5A" strokeWidth="2" strokeLinejoin="round" />
      <path
        d="M19 6l-1 14H6L5 6"
        stroke="#FF4D5A"
        strokeWidth="2"
        strokeLinejoin="round"
      />
      <path d="M10 11v6M14 11v6" stroke="#FF4D5A" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

