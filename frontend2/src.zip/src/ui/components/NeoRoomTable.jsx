export default function NeoRoomTable({ rooms, branches, onEdit, onDelete }) {
  return (
    <table style={{ width: "100%", borderCollapse: "collapse" }}>
      <thead>
        <tr style={{ textAlign: "left", opacity: 0.7 }}>
          <th style={th}>Название</th>
          <th style={th}>Вместимость</th>
          <th style={th}>Филиал</th>
          <th style={th}>Статус</th>
          <th style={{ ...th, width: 120 }} />
        </tr>
      </thead>

      <tbody>
        {rooms.map(room => {
          const branchName =
            branches?.find(b => b.id === room.branch_id)?.name || "—";

          return (
            <tr
              key={room.id}
              onClick={() => onEdit(room)}
              style={{
                borderTop: "1px solid rgba(255,255,255,0.06)",
                cursor: "pointer",
              }}
            >
              <td style={td}>{room.name}</td>
              <td style={td}>{room.capacity ?? "—"}</td>
              <td style={td}>{branchName}</td>
              <td style={td}>{room.is_active ? "Активно" : "Неактивно"}</td>
              <td style={td}>
                <div
                  style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}
                  onClick={e => e.stopPropagation()}
                >
                  <IconBtn title="Редактировать" onClick={() => onEdit(room)}>
                    <PencilIcon />
                  </IconBtn>
                  <IconBtn title="Удалить" onClick={() => onDelete(room)}>
                    <TrashIcon />
                  </IconBtn>
                </div>
              </td>
            </tr>
          );
        })}
      </tbody>
    </table>
  );
}

const th = { padding: 12 };
const td = { padding: 12 };

function IconBtn({ children, onClick, title }) {
  return (
    <button
      title={title}
      onClick={onClick}
      style={{
        width: 38,
        height: 38,
        borderRadius: 12,
        border: "1px solid rgba(255,255,255,0.12)",
        background: "rgba(255,255,255,0.06)",
        cursor: "pointer",
        display: "grid",
        placeItems: "center",
      }}
    >
      {children}
    </button>
  );
}

function PencilIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
      <path d="M12 20h9" stroke="#35D7FF" strokeWidth="2" strokeLinecap="round" />
      <path
        d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5Z"
        stroke="#35D7FF"
        strokeWidth="2"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function TrashIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
      <path d="M3 6h18" stroke="#FF4D5A" strokeWidth="2" strokeLinecap="round" />
      <path d="M8 6V4h8v2" stroke="#FF4D5A" strokeWidth="2" strokeLinejoin="round" />
      <path
        d="M19 6l-1 14H6L5 6"
        stroke="#FF4D5A"
        strokeWidth="2"
        strokeLinejoin="round"
      />
      <path d="M10 11v6M14 11v6" stroke="#FF4D5A" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}
