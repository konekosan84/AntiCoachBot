import { Pencil, Trash2 } from "lucide-react";

export default function NeoBranchCard({
  branch,
  onClick,
  onEdit,
  onDelete,
}) {
  if (!branch) return null;

  const name = branch.name || "Без названия";
  const address = branch.address || "—";
  const phone = branch.phone || "—";
  const status = branch.status || "active";

  const statusColor = {
    active: "#22c55e",
    inactive: "#9ca3af",
  }[status] || "#9ca3af";

  return (
    <div
      onClick={() => onClick?.(branch)}
      style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        gap: 16,
        padding: "14px 16px",
        borderRadius: 18,
        background:
          "linear-gradient(145deg, rgba(15,27,46,0.85), rgba(11,18,32,0.85))",
        border: "1px solid rgba(255,255,255,0.12)",
        boxShadow: "0 0 24px rgba(0,255,255,0.08)",
        cursor: "pointer",
      }}
    >
      {/* LEFT */}
      <div style={{ minWidth: 0 }}>
        <div
          style={{
            fontSize: 16,
            fontWeight: 900,
            color: "white",
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis",
            maxWidth: 420,
          }}
        >
          {name}
        </div>

        <div
          style={{
            fontSize: 13,
            color: "rgba(255,255,255,0.65)",
            marginTop: 2,
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis",
          }}
        >
          {address}
        </div>

        <div
          style={{
            fontSize: 12,
            color: "rgba(255,255,255,0.45)",
            marginTop: 2,
          }}
        >
          {phone}
        </div>

        <div style={{ marginTop: 6 }}>
          <span
            style={{
              fontSize: 12,
              padding: "4px 10px",
              borderRadius: 999,
              background: `${statusColor}22`,
              color: statusColor,
              fontWeight: 700,
            }}
          >
            {status}
          </span>
        </div>
      </div>

      {/* ACTIONS */}
      <div
        style={{ display: "flex", gap: 8 }}
        onClick={e => e.stopPropagation()}
      >
        <button
          onClick={() => onEdit?.(branch)}
          style={iconBtn}
          title="Редактировать"
        >
          <Pencil size={16} color="#3acfd5" />
        </button>

        <button
          onClick={() => onDelete?.(branch)}
          style={iconBtn}
          title="Удалить"
        >
          <Trash2 size={16} color="#f87171" />
        </button>
      </div>
    </div>
  );
}

const iconBtn = {
  width: 38,
  height: 38,
  borderRadius: 12,
  border: "1px solid rgba(255,255,255,0.12)",
  background: "rgba(255,255,255,0.06)",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  cursor: "pointer",
};
