import React from "react";
import "../styles/neo/neo-input.css";

const DAYS = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"];

export default function ScheduleTab({ value, onChange }) {
  const update = (index, field, val) => {
    const newHours = [...value];
    newHours[index] = { ...newHours[index], [field]: val };
    onChange(newHours);
  };

  return (
    <div className="schedule-grid">

      {value.map((day, i) => (
        <div key={i} className="schedule-row">
          
          <div className="day-label">{DAYS[i]}</div>

          <input
            type="time"
            className="neo-input time-input"
            value={day.open_time || ""}
            disabled={day.is_closed}
            onChange={(e) => update(i, "open_time", e.target.value)}
          />

          <span className="dash">–</span>

          <input
            type="time"
            className="neo-input time-input"
            value={day.close_time || ""}
            disabled={day.is_closed}
            onChange={(e) => update(i, "close_time", e.target.value)}
          />

          <label className="closed-label">
            <input
              type="checkbox"
              checked={day.is_closed}
              onChange={(e) => update(i, "is_closed", e.target.checked)}
            />
            Выходной
          </label>
        </div>
      ))}

    </div>
  );
}
