import React from "react";
import "../styles/neo/neo-table-base.css";

export default function NeoTableBase({ columns = [], data = [], onRowClick }) {
  // если data не массив — превращаем в пустой
  if (!Array.isArray(data)) data = [];

  return (
    <div className="neo-table-wrapper">
      <table className="neo-table">
        <thead>
          <tr>
            {columns.map((col) => (
              <th key={col.key}>{col.title}</th>
            ))}
          </tr>
        </thead>

        <tbody>
          {data.length === 0 ? (
            <tr>
              <td colSpan={columns.length} className="neo-empty">
                Нет данных
              </td>
            </tr>
          ) : (
            data.map((row) => (
              <tr key={row.id} onClick={() => onRowClick?.(row)}>
                {columns.map((col) => (
                  <td key={col.key}>{row[col.key]}</td>
                ))}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}
