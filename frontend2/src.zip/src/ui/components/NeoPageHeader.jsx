import React from "react";
import "../styles/neo/neo-page-header.css";

export default function NeoPageHeader({
  title = "",
  query = "",
  onQueryChange = () => {},
  mode = "table",
  onModeChange = () => {},
  onAdd = () => {},
  addLabel = "Добавить",
}) {
  return (
    <div className="neo-header">
      <h1 className="neo-header-title">{title}</h1>

      <div className="neo-header-controls">

        {/* Поиск */}
        <input
          className="neo-header-search"
          placeholder="Поиск..."
          value={query}
          onChange={(e) => onQueryChange(e.target.value)}
        />

        {/* Переключатель вида */}
        <div className="neo-header-toggle">
          <button
            className={mode === "table" ? "toggle-btn active" : "toggle-btn"}
            onClick={() => onModeChange("table")}
          >
            Таблица
          </button>

          <button
            className={mode === "cards" ? "toggle-btn active" : "toggle-btn"}
            onClick={() => onModeChange("cards")}
          >
            Карточки
          </button>
        </div>

        {/* Кнопка добавить */}
        <button className="neo-add-btn" onClick={onAdd}>
          + {addLabel}
        </button>
      </div>
    </div>
  );
}
