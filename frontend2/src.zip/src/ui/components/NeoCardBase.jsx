import React from "react";
import NeoActionButtons from "./NeoActionButtons";
import "../styles/neo/neo-card.css";

export default function NeoCardBase({ children, onEdit, onDelete }) {
  return (
    <div className="neo-card">
      <div className="neo-card-actions">
        <NeoActionButtons onEdit={onEdit} onDelete={onDelete} />
      </div>

      <div className="neo-card-content">
        {children}
      </div>
    </div>
  );
}
