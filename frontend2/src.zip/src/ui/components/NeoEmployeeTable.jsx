import { Pencil, Trash2 } from "lucide-react";

function renderBranches(branches = []) {
  if (!branches.length) return "—";

  const names = branches.map(b => b.name);
  if (names.length <= 3) return names.join(", ");

  return `${names.slice(0, 2).join(", ")} +${names.length - 2}`;
}

export default function NeoEmployeeTable({ employees, onEdit, onDelete }) {
  return (
    <table className="neo-table">
      <thead>
        <tr>
          <th>ФИО</th>
          <th>Должность</th>
          <th>Филиалы</th>
          <th>Статус</th>
          <th style={{ width: 96 }}></th>
        </tr>
      </thead>

      <tbody>
        {employees.map(emp => (
          <tr
            key={emp.id}
            onClick={() => onEdit(emp)}
            style={{ cursor: "pointer" }}
          >
            <td>{emp.name || "—"}</td>
            <td>{emp.position || "—"}</td>
            <td style={{ opacity: 0.8 }}>
              {renderBranches(emp.branches)}
            </td>
            <td>{emp.status || "—"}</td>

            <td
              onClick={e => e.stopPropagation()}
              style={{ display: "flex", gap: 8 }}
            >
              <button
                className="neo-icon-btn"
                onClick={() => onEdit(emp)}
                title="Редактировать"
              >
                <Pencil size={16} />
              </button>
              <button
                className="neo-icon-btn danger"
                onClick={() => onDelete(emp)}
                title="Удалить"
              >
                <Trash2 size={16} />
              </button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
