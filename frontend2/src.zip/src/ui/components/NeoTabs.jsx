import React from "react";
import "../styles/neo/neo-tabs.css";

export default function NeoTabs({ tabs = [], active, onChange }) {
  return (
    <div className="neo-tabs">
      {tabs.map((tab) => (
        <div
          key={tab.id}
          className={
            "neo-tab-item " + (active === tab.id ? "active" : "")
          }
          onClick={() => onChange(tab.id)}
        >
          {tab.label}
        </div>
      ))}
    </div>
  );
}
