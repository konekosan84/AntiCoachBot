export default function NeoSegmented({ value, onChange, options }) {
  return (
    <div
      style={{
        display: "inline-flex",
        padding: 4,
        borderRadius: 14,
        background: "rgba(255,255,255,0.04)",
        border: "1px solid rgba(255,255,255,0.08)",
        backdropFilter: "blur(8px)",
      }}
    >
      {options.map(opt => {
        const active = value === opt.value;

        return (
          <button
            key={opt.value}
            onClick={() => onChange(opt.value)}
            style={{
              padding: "8px 16px",
              borderRadius: 12,
              border: "none",
              cursor: "pointer",
              fontSize: 14,
              fontWeight: 500,
              color: active ? "#0b1020" : "rgba(255,255,255,0.65)",
              background: active
                ? "linear-gradient(135deg, #3ACFD5, #6558F5)"
                : "transparent",
              boxShadow: active
                ? "0 0 0 1px rgba(58,207,213,.35), 0 6px 18px rgba(101,88,245,.35)"
                : "none",
              transition: "all .2s ease",
            }}
            onMouseEnter={e => {
              if (!active) {
                e.currentTarget.style.background =
                  "rgba(255,255,255,0.06)";
                e.currentTarget.style.color = "#fff";
              }
            }}
            onMouseLeave={e => {
              if (!active) {
                e.currentTarget.style.background = "transparent";
                e.currentTarget.style.color = "rgba(255,255,255,0.65)";
              }
            }}
          >
            {opt.label}
          </button>
        );
      })}
    </div>
  );
}
