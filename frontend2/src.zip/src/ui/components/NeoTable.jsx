import React from "react";
import "../styles/neo/neo-table.css";
import { FiEdit3, FiTrash2 } from "react-icons/fi";

export default function NeoTable({ columns, rows, onEdit, onDelete }) {
  return (
    <div className="neo-table-wrapper">
      <table className="neo-table">
        <thead>
          <tr>
            {columns.map((col) => (
              <th key={col.key}>{col.label}</th>
            ))}
            {(onEdit || onDelete) && <th></th>}
          </tr>
        </thead>

        <tbody>
          {rows.map((row, i) => (
            <tr key={i}>
              {columns.map((col) => (
                <td key={col.key}>{row[col.key] ?? "—"}</td>
              ))}

              {(onEdit || onDelete) && (
                <td className="actions">
                  {onEdit && (
                    <button
                      className="edit-btn"
                      onClick={() => onEdit(row)}
                    >
                      <FiEdit3 />
                    </button>
                  )}
                  {onDelete && (
                    <button
                      className="delete-btn"
                      onClick={() => onDelete(row)}
                    >
                      <FiTrash2 />
                    </button>
                  )}
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
