import NeoButton from "./NeoButton";

export default function UnifiedHeader({ title, onAdd }) {
  return (
    <div className="page-header">
      <h1>{title}</h1>
      {onAdd && (
        <NeoButton glow onClick={onAdd}>
          + Добавить
        </NeoButton>
      )}
    </div>
  );
}
