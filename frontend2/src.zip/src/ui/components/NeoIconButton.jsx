import React from "react";
import "../styles/neo/neo-button.css";

export default function NeoIconButton({ icon, onClick, danger }) {
  return (
    <button
      className={`neo-icon-btn ${danger ? "danger" : ""}`}
      onClick={onClick}
    >
      {icon}
    </button>
  );
}
