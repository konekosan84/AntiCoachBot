// src/ui/components/Avatar.jsx

import React from "react";
import "../styles/neo/avatar.css"; 

export default function Avatar({ name = "", size = 48, src = null }) {
  const initials = name
    .split(" ")
    .filter((w) => w.length > 0)
    .map((w) => w[0]?.toUpperCase())
    .slice(0, 2)
    .join("");

  return (
    <div
      className="neo-avatar"
      style={{ width: size, height: size, fontSize: size * 0.38 }}
    >
      {src ? (
        <img
          src={src}
          alt={name}
          style={{ width: size, height: size, borderRadius: "50%" }}
        />
      ) : (
        initials
      )}
    </div>
  );
}
