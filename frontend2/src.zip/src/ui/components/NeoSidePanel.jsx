import React from "react";
import "../styles/neo/neo-sidepanel.css";

export default function NeoSidePanel({ isOpen, onClose, children, width = 420 }) {
  return (
    <div className={`neo-panel-overlay ${isOpen ? "open" : ""}`}>
      <div className="neo-panel" style={{ width }}>
        <button className="neo-close" onClick={onClose}>×</button>
        {children}
      </div>
    </div>
  );
}

