import React from "react";

/**
 * value: "table" | "cards"
 * onChange: (mode) => void
 */
const ViewToggle = ({ value = "table", onChange }) => {
  const setMode = (mode) => () => {
    if (mode !== value) onChange && onChange(mode);
  };

  return (
    <div className="neo-tabs neo-tabs--compact">
      <button
        type="button"
        className={
          value === "table"
            ? "neo-tab neo-tab--active"
            : "neo-tab"
        }
        onClick={setMode("table")}
      >
        Таблица
      </button>
      <button
        type="button"
        className={
          value === "cards"
            ? "neo-tab neo-tab--active"
            : "neo-tab"
        }
        onClick={setMode("cards")}
      >
        Карточки
      </button>
    </div>
  );
};

export default ViewToggle;
