import React, { useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { CheckCircle, XCircle, AlertTriangle, Info } from "lucide-react";

// ✅ Словарь иконок
const icons = {
  success: <CheckCircle className="text-emerald-400" size={22} />,
  error: <XCircle className="text-rose-400" size={22} />,
  warning: <AlertTriangle className="text-amber-400" size={22} />,
  info: <Info className="text-sky-400" size={22} />,
};

export const SlotiqToast = ({ toast }) => {
  useEffect(() => {
    // авто-закрытие через 2.5 сек
    const timer = setTimeout(() => toast.close(), 2500);
    return () => clearTimeout(timer);
  }, [toast]);

  // 💥 вибрация при ошибке
  useEffect(() => {
    if (toast.type === "error" && navigator.vibrate) {
      navigator.vibrate(150);
    }
  }, [toast.type]);

  return (
    <AnimatePresence>
      <motion.div
        key={toast.message}
        initial={{ opacity: 0, y: 50, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 40, scale: 0.9 }}
        transition={{ type: "spring", damping: 15, stiffness: 200 }}
        className="fixed bottom-6 right-6 z-[9999]"
      >
        <motion.div
          initial={{ boxShadow: "0 0 0 rgba(0,0,0,0)" }}
          animate={{
            boxShadow:
              "0 0 25px rgba(101,88,245,0.25), 0 0 50px rgba(58,207,213,0.15)",
          }}
          transition={{ repeat: Infinity, repeatType: "reverse", duration: 2 }}
          className={`flex items-center gap-3 px-5 py-3.5 rounded-2xl shadow-lg backdrop-blur-xl border border-white/10 text-white/90
            bg-gradient-to-br from-[#3ACFD5]/80 to-[#6558F5]/80`}
        >
          {icons[toast.type]}
          <span className="text-sm font-medium tracking-wide">
            {toast.message}
          </span>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};
