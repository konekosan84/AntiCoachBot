const ProtectedRoute = ({ children }) => {
  const { auth } = useAuth();
  return auth?.user ? children : <Navigate to="/login" />;
};



