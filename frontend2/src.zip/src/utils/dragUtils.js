// Базовая логика Drag & Drop для будущего использования
// Сейчас просто заглушка, чтобы проект работал без ошибок

export function startDrag(shift) {
  return {
    type: "drag-start",
    payload: shift,
  };
}

export function endDrag() {
  return {
    type: "drag-end",
  };
}

export function canDrop(shift, targetDay) {
  // Здесь позже сделаем проверку, можно ли переносить смену
  return true;
}

