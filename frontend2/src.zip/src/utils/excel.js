import * as XLSX from "xlsx";

/* ============================================================
   BASE HELPERS
============================================================ */

function downloadWorkbook(json, filename) {
  const ws = XLSX.utils.json_to_sheet(json);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Sheet1");
  XLSX.writeFile(wb, filename);
}

function readWorkbook(file, callback) {
  const reader = new FileReader();
  reader.onload = (e) => {
    const data = new Uint8Array(e.target.result);
    const workbook = XLSX.read(data, { type: "array" });
    const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json(firstSheet, { defval: "" });
    callback(rows);
  };
  reader.readAsArrayBuffer(file);
}

/* ============================================================
   BRANCHES
============================================================ */
export function exportBranchesToExcel(branches) {
  downloadWorkbook(branches, "branches.xlsx");
}

export function importBranchesFromExcel(file, onFinish) {
  readWorkbook(file, (rows) => {
    console.log("IMPORT BRANCHES:", rows);
    onFinish();
  });
}

/* ============================================================
   EMPLOYEES
============================================================ */
export function exportEmployeesToExcel(employees) {
  downloadWorkbook(employees, "employees.xlsx");
}

export function importEmployeesFromExcel(file, onFinish) {
  readWorkbook(file, (rows) => {
    console.log("IMPORT EMPLOYEES:", rows);
    onFinish();
  });
}

/* ============================================================
   ROOMS
============================================================ */
export function exportRoomsToExcel(rooms) {
  downloadWorkbook(rooms, "rooms.xlsx");
}

export function importRoomsFromExcel(file, onFinish) {
  readWorkbook(file, (rows) => {
    console.log("IMPORT ROOMS:", rows);
    onFinish();
  });
}

/* ============================================================
   SERVICES
============================================================ */
export function exportServicesToExcel(services) {
  downloadWorkbook(services, "services.xlsx");
}

export function importServicesFromExcel(file, onFinish) {
  readWorkbook(file, (rows) => {
    console.log("IMPORT SERVICES:", rows);
    onFinish();
  });
}

/* ============================================================
   CLIENTS  ❤️ ДОБАВИЛ!!!!
============================================================ */
export function exportClientsToExcel(clients) {
  downloadWorkbook(clients, "clients.xlsx");
}

export function importClientsFromExcel(file, onFinish) {
  readWorkbook(file, (rows) => {
    console.log("IMPORT CLIENTS:", rows);
    onFinish();
  });
}
