// 🟣 Группировка смен по времени (для DAY view)
export function groupShiftsByTime(shifts) {
  const map = {};

  shifts.forEach((shift) => {
    const key = `${shift.start_time}`;
    if (!map[key]) map[key] = [];
    map[key].push(shift);
  });

  // Сортировка блоков по времени
  return Object.keys(map)
    .sort()
    .reduce((obj, key) => {
      obj[key] = map[key];
      return obj;
    }, {});
}

// 🟢 Группировка смен по дням (для WEEK и MONTH views)
export function groupShiftsByDay(shifts) {
  const map = {};

  shifts.forEach((shift) => {
    const date = shift.date;
    if (!map[date]) map[date] = [];
    map[date].push(shift);
  });

  return map;
}

// 🔵 Проверка пересечений смен (логика будущего расширения)
export function hasOverlap(shiftA, shiftB) {
  if (shiftA.date !== shiftB.date) return false;

  return (
    (shiftA.start_time >= shiftB.start_time &&
      shiftA.start_time < shiftB.end_time) ||
    (shiftA.end_time > shiftB.start_time &&
      shiftA.end_time <= shiftB.end_time)
  );
}

// ⚪ Утилита сортировки по времени
export function sortByStartTime(shifts) {
  return shifts.sort((a, b) =>
    a.start_time.localeCompare(b.start_time)
  );
}
