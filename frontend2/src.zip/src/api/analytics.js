const API_BASE = '/api/analytics';

function buildQuery(params = {}) {
  const search = new URLSearchParams();

  Object.entries(params).forEach(([key, value]) => {
    if (value === undefined || value === null || value === '') return;
    search.set(key, String(value));
  });

  return search.toString();
}

async function fetchJson(path, params = {}) {
  const query = buildQuery(params);
  const url = query ? `${API_BASE}${path}?${query}` : `${API_BASE}${path}`;

  const res = await fetch(url);

  if (!res.ok) {
    const text = await res.text().catch(() => '');
    const err = new Error(text || `HTTP ${res.status}`);
    err.status = res.status;
    throw err;
  }

  return res.json();
}

export function getTodayStats(params) {
  return fetchJson('/today-stats', params);
}

export function getRevenueDynamics(params) {
  return fetchJson('/revenue-dynamics', params);
}

export function getCompareToPrevious(params) {
  return fetchJson('/compare-to-previous', params);
}

export function getBranchesTable(params) {
  return fetchJson('/branches-table', params);
}

export function getEmployeesRating(params) {
  return fetchJson('/employees-rating', params);
}

export function getServicesRating(params) {
  return fetchJson('/services-rating', params);
}

export function getWeekdayStats(params) {
  return fetchJson('/weekday-stats', params);
}

export function getHourStats(params) {
  return fetchJson('/hour-stats', params);
}

export function getSummary(params) {
  return fetchJson('/summary', params);
}

export function getBookingsDetails(params) {
  return fetchJson('/bookings-details', params);
}