import api from "./api";

export const getClientComments = async (clientId) =>
  (await api.get(`/clientComments/${clientId}`)).data;

export const addClientComment = async (data) =>
  (await api.post(`/clientComments`, data)).data;
