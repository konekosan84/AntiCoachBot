async function fetchJson(url, opts = {}) {
  const res = await fetch(url, {
    headers: { "Content-Type": "application/json", ...(opts.headers || {}) },
    ...opts,
  });

  const text = await res.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = text;
  }

  if (!res.ok) {
    // Делаем ошибку "богатой": status + payload, чтобы UI мог красиво обработать 409/400 и т.п.
    const msg =
      (data && typeof data === "object" && (data.message || data.error))
        ? (data.message || data.error)
        : `HTTP ${res.status}`;

    const err = new Error(msg);
    err.status = res.status;
    err.payload = data;
    throw err;
  }

  return data;
}

const API_BASE = "/api/v1";

export function getShifts({ date_from, date_to, branch_id = "all", employee_id = "all" }) {
  const p = new URLSearchParams();
  p.set("date_from", date_from);
  p.set("date_to", date_to);
  if (branch_id && branch_id !== "all") p.set("branch_id", String(branch_id));
  if (employee_id && employee_id !== "all") p.set("employee_id", String(employee_id));

  return fetchJson(`${API_BASE}/schedule/shifts?${p.toString()}`);
}

export function createShift(payload) {
  // payload.date строго 'YYYY-MM-DD'
  return fetchJson(`${API_BASE}/schedule/shifts`, {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

export function updateShift(id, payload) {
  return fetchJson(`${API_BASE}/schedule/shifts/${id}`, {
    method: "PUT",
    body: JSON.stringify(payload),
  });
}

export function deleteShift(id) {
  return fetchJson(`${API_BASE}/schedule/shifts/${id}`, { method: "DELETE" });
}