import axios from "axios";

const API = "/api/positions";

// Все должности
export async function getPositions() {
  const res = await axios.get(API);
  return res.data;
}

// Создать новую должность
export async function createPosition(name) {
  const res = await axios.post(API, { name });
  return res.data;
}
