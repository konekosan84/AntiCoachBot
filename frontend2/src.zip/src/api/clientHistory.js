import api from "./api";

export const getClientHistory = async (clientId) =>
  (await api.get(`/clientHistory/${clientId}`)).data;
