import api from "./api";

export const getClientProfile = async (clientId) =>
  (await api.get(`/clientProfile/${clientId}`)).data;

export const updateClientProfile = async (clientId, data) =>
  (await api.put(`/clientProfile/${clientId}`, data)).data;
