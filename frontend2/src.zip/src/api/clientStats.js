import api from "./api";

export const getClientStats = async (clientId) =>
  (await api.get(`/clientStats/${clientId}`)).data;
