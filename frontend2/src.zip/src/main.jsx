// src/main.jsx

import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";

// Основные UI-стили — ВСЕ находятся в папке neo
import "./ui/styles/neo/ui.css";
import "./ui/styles/neo/ui-kit.css";
import "./ui/styles/neo/NeoUI.css";
import "./index.css";


ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);






