import { createContext, useContext, useState, useEffect } from "react";

const AuthContext = createContext();

export function AuthProvider({ children }) {
  // Загружаем пользователя из localStorage
  const [user, setUser] = useState(() => {
    try {
      const saved = localStorage.getItem("slotiq-user");
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  // Сохраняем пользователя при изменении
  useEffect(() => {
    if (user) {
      localStorage.setItem("slotiq-user", JSON.stringify(user));
    } else {
      localStorage.removeItem("slotiq-user");
    }
  }, [user]);

  // Логин
  const login = (payload) => {
    setUser(payload);
  };

  // Логаут
  const logout = () => {
    setUser(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: Boolean(user),
        login,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    console.error("useAuth() used outside <AuthProvider>");
  }
  return ctx;
}
