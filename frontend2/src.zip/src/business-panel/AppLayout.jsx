import React from "react";
import { Outlet, NavLink } from "react-router-dom";

import "../ui/styles/neo/neo-layout.css";
import "../ui/styles/neo/neo-sidebar.css";

export default function AppLayout() {
  return (
    <div className="neo-layout">
      <aside className="neo-sidebar">
        <h2 className="neo-sidebar-title">SLOTIQ PRO</h2>

        <nav className="neo-sidebar-nav">
          <NavLink to="/dashboard" className="neo-nav-item">Дашборд</NavLink>
          <NavLink to="/branches" className="neo-nav-item">Филиалы</NavLink>
          <NavLink to="/employees" className="neo-nav-item">Сотрудники</NavLink>
          <NavLink to="/services" className="neo-nav-item">Услуги</NavLink>
          <NavLink to="/rooms" className="neo-nav-item">Помещения</NavLink>
          <NavLink to="/schedule" className="neo-nav-item">Расписание</NavLink>
          <NavLink to="/bookings" className="neo-nav-item">Записи</NavLink>
          <NavLink to="/clients" className="neo-nav-item">Клиенты</NavLink>
          <NavLink to="/analytics" className="neo-nav-item">Аналитика</NavLink>
        </nav>
      </aside>

      <main className="neo-content">
        <Outlet />
      </main>

      <div id="portal-root"></div>
    </div>
  );
}