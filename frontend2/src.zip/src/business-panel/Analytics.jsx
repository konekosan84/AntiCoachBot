import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  getBranchesTable,
  getCompareToPrevious,
  getEmployeesRating,
  getHourStats,
  getRevenueDynamics,
  getServicesRating,
  getSummary,
  getTodayStats,
  getWeekdayStats,
} from '../api/analytics';
import AnalyticsDetailPanel from './AnalyticsDetailPanel';

function formatMoney(value) {
  return `${Number(value || 0).toLocaleString('ru-RU')} ₽`;
}

function formatPercent(value) {
  return `${Number(value || 0).toFixed(1)}%`;
}

function getTodayYmd() {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function addDays(ymd, days) {
  const d = new Date(`${ymd}T00:00:00`);
  d.setDate(d.getDate() + days);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function getMonthStartYmd(ymd) {
  const d = new Date(`${ymd}T00:00:00`);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  return `${y}-${m}-01`;
}

function formatDateLong(value) {
  if (!value) return '—';
  const d = new Date(`${value}T00:00:00`);
  return d.toLocaleDateString('ru-RU', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });
}

function formatDateMedium(value) {
  if (!value) return '—';
  const d = new Date(`${value}T00:00:00`);
  return d.toLocaleDateString('ru-RU', {
    day: 'numeric',
    month: 'short',
  });
}

function getPeriodLabel(dateFrom, dateTo) {
  if (!dateFrom || !dateTo) return 'За выбранный период';
  if (dateFrom === dateTo) return formatDateMedium(dateFrom);
  return `${formatDateMedium(dateFrom)} — ${formatDateMedium(dateTo)}`;
}

function KpiCard({
  title,
  value,
  subtitle,
  tone = 'default',
  onClick,
  tooltip,
}) {
  const toneClass =
    tone === 'danger'
      ? 'border-red-400/20'
      : tone === 'success'
      ? 'border-emerald-400/20'
      : tone === 'warning'
      ? 'border-amber-400/20'
      : 'border-white/10';

  return (
    <button
      type="button"
      onClick={onClick}
      title={tooltip}
      className={`rounded-[20px] border ${toneClass} bg-white/[0.05] p-4 text-left shadow-[0_8px_24px_rgba(0,0,0,0.16)] backdrop-blur-md transition hover:bg-white/[0.07]`}
    >
      <div className="text-[14px] font-semibold leading-5 text-white/78">
        {title}
      </div>

      <div className="mt-3 text-[38px] font-extrabold leading-none tracking-tight text-white">
        {value}
      </div>

      <div className="mt-3 min-h-[38px] text-[13px] leading-5 text-white/58">
        {subtitle}
      </div>

      <div className="mt-3 text-[11px] font-semibold uppercase tracking-wide text-cyan-300/85">
        Открыть детализацию
      </div>
    </button>
  );
}

function Block({ title, subtitle, children, error }) {
  return (
    <div className="overflow-hidden rounded-[24px] border border-white/10 bg-white/[0.05] shadow-[0_8px_24px_rgba(0,0,0,0.16)] backdrop-blur-md">
      <div className="border-b border-white/10 px-5 py-4">
        <div className="text-[18px] font-bold text-white">{title}</div>
        {subtitle ? <div className="mt-1 text-sm text-white/45">{subtitle}</div> : null}
        {error ? (
          <div className="mt-3 rounded-2xl border border-red-400/30 bg-red-500/10 px-4 py-3 text-sm text-red-200">
            {error}
          </div>
        ) : null}
      </div>
      <div className="p-5">{children}</div>
    </div>
  );
}

function MiniTable({ columns, rows, emptyText = 'Нет данных за период' }) {
  if (!rows || rows.length === 0) {
    return <div className="text-sm text-white/40">{emptyText}</div>;
  }

  return (
    <div className="overflow-auto">
      <table className="w-full min-w-[520px] border-separate border-spacing-y-2">
        <thead>
          <tr>
            {columns.map((col) => (
              <th
                key={col.key}
                className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-white/40"
              >
                {col.title}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, idx) => (
            <tr key={row.id ?? idx} className="rounded-2xl bg-white/[0.04]">
              {columns.map((col) => (
                <td key={col.key} className="px-3 py-3 text-sm text-white">
                  {col.render ? col.render(row[col.key], row) : row[col.key]}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function BarsList({ rows, labelKey, valueKey, emptyText = 'Нет данных за период' }) {
  const max = Math.max(...(rows || []).map((r) => Number(r[valueKey] || 0)), 0);

  if (!rows || rows.length === 0) {
    return <div className="text-sm text-white/40">{emptyText}</div>;
  }

  return (
    <div className="space-y-3">
      {rows.map((row, idx) => {
        const value = Number(row[valueKey] || 0);
        const width = max > 0 ? Math.max((value / max) * 100, 6) : 0;

        return (
          <div key={row.id ?? row[labelKey] ?? idx}>
            <div className="mb-1 flex items-center justify-between gap-4">
              <div className="truncate text-sm text-white/75">{row[labelKey]}</div>
              <div className="text-sm font-semibold text-white">{formatMoney(value)}</div>
            </div>
            <div className="h-2.5 rounded-full bg-white/[0.06]">
              <div
                className="h-2.5 rounded-full bg-gradient-to-r from-cyan-400 to-violet-500"
                style={{ width: `${width}%` }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
}

function RevenueList({ rows }) {
  if (!rows || rows.length === 0) {
    return <div className="text-sm text-white/40">Нет данных за период</div>;
  }

  return (
    <div className="space-y-2.5">
      {rows.map((row, idx) => {
        const zero = Number(row.revenue || 0) === 0;

        return (
          <div
            key={row.id ?? row.date ?? idx}
            className={`flex items-center justify-between rounded-2xl px-4 py-3 ${
              zero ? 'bg-white/[0.03] text-white/45' : 'bg-white/[0.05]'
            }`}
          >
            <div className="text-sm font-medium">{formatDateLong(row.date)}</div>
            <div className={`text-sm font-bold ${zero ? 'text-white/45' : 'text-white'}`}>
              {formatMoney(row.revenue)}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function QuickRangeButton({ children, onClick }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="rounded-xl border border-white/10 bg-white/[0.04] px-3.5 py-2 text-xs font-semibold text-white/70 transition hover:bg-white/[0.08]"
    >
      {children}
    </button>
  );
}

function InsightCard({ title, value, subvalue }) {
  return (
    <div className="rounded-[18px] border border-white/10 bg-white/[0.04] p-4">
      <div className="min-h-[38px] text-[13px] font-semibold leading-5 text-white/78">
        {title}
      </div>

      <div className="mt-2 line-clamp-2 break-words text-[24px] font-bold leading-[1.05] text-white">
        {value}
      </div>

      <div className="mt-2 text-[13px] leading-5 text-white/60">
        {subvalue}
      </div>
    </div>
  );
}

export default function Analytics() {
  const navigate = useNavigate();
  const today = getTodayYmd();

  const [dateFrom, setDateFrom] = useState(today);
  const [dateTo, setDateTo] = useState(today);
  const [branchId, setBranchId] = useState('');
  const [employeeId, setEmployeeId] = useState('');

  const [branches, setBranches] = useState([]);
  const [employees, setEmployees] = useState([]);

  const [loading, setLoading] = useState(false);
  const [pageError, setPageError] = useState('');

  const [todayStats, setTodayStats] = useState(null);
  const [summary, setSummary] = useState(null);
  const [revenueDynamics, setRevenueDynamics] = useState([]);
  const [compareData, setCompareData] = useState(null);
  const [branchesTable, setBranchesTable] = useState([]);
  const [employeesRating, setEmployeesRating] = useState([]);
  const [servicesRating, setServicesRating] = useState([]);
  const [weekdayStats, setWeekdayStats] = useState([]);
  const [hourStats, setHourStats] = useState([]);
  const [blockErrors, setBlockErrors] = useState({});

  const [detailOpen, setDetailOpen] = useState(false);
  const [detailMetric, setDetailMetric] = useState('total');

  const queryParams = useMemo(
    () => ({
      date_from: dateFrom,
      date_to: dateTo,
      branch_id: branchId,
      employee_id: employeeId,
    }),
    [dateFrom, dateTo, branchId, employeeId]
  );

  const selectedBranchLabel = useMemo(() => {
    if (!branchId) return 'Все филиалы';
    const branch = branches.find((b) => String(b.id) === String(branchId));
    return branch?.name || branch?.title || `Филиал #${branchId}`;
  }, [branches, branchId]);

  const selectedEmployeeLabel = useMemo(() => {
    if (!employeeId) return 'Все сотрудники';
    const employee = employees.find((e) => String(e.id) === String(employeeId));
    return employee?.name || employee?.full_name || employee?.fio || `Сотрудник #${employeeId}`;
  }, [employees, employeeId]);

  const filteredEmployees = useMemo(() => {
    if (!branchId) return employees;
    return employees.filter((employee) => {
      if (employee.branch_id && String(employee.branch_id) === String(branchId)) return true;
      if (Array.isArray(employee.branch_ids)) {
        return employee.branch_ids.map(String).includes(String(branchId));
      }
      return true;
    });
  }, [employees, branchId]);

  useEffect(() => {
    loadDictionaries();
  }, []);

  useEffect(() => {
    loadAnalytics();
  }, []);

  async function loadDictionaries() {
    try {
      const [branchesRes, employeesRes] = await Promise.all([
        fetch('/api/v1/branches'),
        fetch('/api/v1/employees'),
      ]);

      const branchesData = branchesRes.ok ? await branchesRes.json() : [];
      const employeesData = employeesRes.ok ? await employeesRes.json() : [];

      setBranches(Array.isArray(branchesData) ? branchesData : []);
      setEmployees(Array.isArray(employeesData) ? employeesData : []);
    } catch (err) {
      console.error('load dictionaries error', err);
    }
  }

  async function loadAnalytics() {
    setLoading(true);
    setPageError('');
    setBlockErrors({});

    const nextErrors = {};

    const tasks = [
      { key: 'todayStats', run: () => getTodayStats(queryParams), apply: setTodayStats },
      { key: 'summary', run: () => getSummary(queryParams), apply: setSummary },
      { key: 'revenueDynamics', run: () => getRevenueDynamics(queryParams), apply: setRevenueDynamics },
      { key: 'compareData', run: () => getCompareToPrevious(queryParams), apply: setCompareData },
      { key: 'branchesTable', run: () => getBranchesTable(queryParams), apply: setBranchesTable },
      { key: 'employeesRating', run: () => getEmployeesRating(queryParams), apply: setEmployeesRating },
      { key: 'servicesRating', run: () => getServicesRating(queryParams), apply: setServicesRating },
      { key: 'weekdayStats', run: () => getWeekdayStats(queryParams), apply: setWeekdayStats },
      { key: 'hourStats', run: () => getHourStats(queryParams), apply: setHourStats },
    ];

    await Promise.all(
      tasks.map(async (task) => {
        try {
          const data = await task.run();
          task.apply(data);
        } catch (err) {
          console.error(`${task.key} error`, err);
          nextErrors[task.key] = err?.message || 'Ошибка загрузки';

          if (task.key === 'todayStats') setTodayStats(null);
          if (task.key === 'summary') setSummary(null);
          if (task.key === 'revenueDynamics') setRevenueDynamics([]);
          if (task.key === 'compareData') setCompareData(null);
          if (task.key === 'branchesTable') setBranchesTable([]);
          if (task.key === 'employeesRating') setEmployeesRating([]);
          if (task.key === 'servicesRating') setServicesRating([]);
          if (task.key === 'weekdayStats') setWeekdayStats([]);
          if (task.key === 'hourStats') setHourStats([]);
        }
      })
    );

    if (Object.keys(nextErrors).length === tasks.length) {
      setPageError('Не удалось загрузить аналитику');
    }

    setBlockErrors(nextErrors);
    setLoading(false);
  }

  function applyQuickRange(type) {
    if (type === 'today') {
      setDateFrom(today);
      setDateTo(today);
      return;
    }
    if (type === 'yesterday') {
      const y = addDays(today, -1);
      setDateFrom(y);
      setDateTo(y);
      return;
    }
    if (type === '7d') {
      setDateFrom(addDays(today, -6));
      setDateTo(today);
      return;
    }
    if (type === '30d') {
      setDateFrom(addDays(today, -29));
      setDateTo(today);
      return;
    }
    if (type === 'month') {
      setDateFrom(getMonthStartYmd(today));
      setDateTo(today);
    }
  }

  function resetFilters() {
    setDateFrom(today);
    setDateTo(today);
    setBranchId('');
    setEmployeeId('');
  }

  function openDetail(metric) {
    setDetailMetric(metric);
    setDetailOpen(true);
  }

  function handleOpenBooking(row) {
    if (!row?.booking_id) return;

    setDetailOpen(false);

    navigate(`/bookings?booking_id=${row.booking_id}`, {
      state: {
        openBookingId: row.booking_id,
        source: 'analytics',
        analyticsFilters: queryParams,
      },
    });
  }

  const stats = todayStats || summary || {};
  const revenue = stats.revenue || 0;
  const lostRevenue = stats.lost_revenue || 0;
  const totalBookings = stats.total_bookings || 0;
  const completedBookings = stats.completed_bookings || 0;
  const cancelledBookings = stats.cancelled_bookings || 0;
  const avgCheck = stats.avg_check || 0;
  const cancelRate = stats.cancel_rate || 0;

  let compareText = 'Нет данных для сравнения';
  if (compareData) {
    const diff = Number(compareData.diff || 0);
    const prev = Number(compareData.previous_revenue || 0);
    const current = Number(compareData.current_revenue || 0);

    if (diff === 0 && current === 0 && prev === 0) {
      compareText = 'Без изменений';
    } else if (prev === 0 && current > 0) {
      compareText = `Рост на ${formatMoney(diff)}`;
    } else if (diff > 0) {
      compareText = `Рост на ${formatMoney(diff)} (${formatPercent(compareData.percent)})`;
    } else if (diff < 0) {
      compareText = `Падение на ${formatMoney(Math.abs(diff))} (${formatPercent(Math.abs(compareData.percent))})`;
    } else {
      compareText = 'Без изменений';
    }
  }

  const topEmployee = employeesRating?.[0];
  const topService = servicesRating?.[0];
  const topDay = [...revenueDynamics].sort((a, b) => Number(b.revenue || 0) - Number(a.revenue || 0))[0];
  const topHour = [...hourStats].sort((a, b) => Number(b.revenue || 0) - Number(a.revenue || 0))[0];

  const problematicEmployee = [...employeesRating]
    .sort((a, b) => {
      if ((b.cancelled_bookings || 0) !== (a.cancelled_bookings || 0)) {
        return (b.cancelled_bookings || 0) - (a.cancelled_bookings || 0);
      }
      const aRate = (a.total_bookings || 0) > 0 ? (a.cancelled_bookings || 0) / a.total_bookings : 0;
      const bRate = (b.total_bookings || 0) > 0 ? (b.cancelled_bookings || 0) / b.total_bookings : 0;
      return bRate - aRate;
    })[0];

  const branchWithMaxLostRevenue = [...branchesTable]
    .sort((a, b) => (b.lost_revenue || 0) - (a.lost_revenue || 0))[0];

  return (
    <div className="min-h-screen bg-[#081224] text-white">
      <div className="mx-auto max-w-[1500px] px-5 py-5">
        <div className="rounded-[24px] border border-white/10 bg-gradient-to-r from-[#0c1d57] via-[#2140c9] to-[#5a52ff] px-6 py-4 shadow-[0_14px_36px_rgba(0,0,0,0.22)]">
          <div className="flex flex-col gap-2 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <h1 className="text-[34px] font-extrabold leading-none tracking-tight">Аналитика</h1>
              <p className="mt-2 text-sm text-white/80">
                Выручка, записи, филиалы, сотрудники, услуги и время.
              </p>
            </div>

            <div className="rounded-2xl bg-white/10 px-4 py-2 text-sm text-white/85">
              Период: {getPeriodLabel(dateFrom, dateTo)}
            </div>
          </div>
        </div>

        <div className="sticky top-3 z-30 mt-4 rounded-[24px] border border-white/10 bg-[#0d1730]/90 p-4 shadow-[0_8px_24px_rgba(0,0,0,0.24)] backdrop-blur-xl">
          <div className="mb-3 flex flex-wrap gap-2">
            <QuickRangeButton onClick={() => applyQuickRange('today')}>Сегодня</QuickRangeButton>
            <QuickRangeButton onClick={() => applyQuickRange('yesterday')}>Вчера</QuickRangeButton>
            <QuickRangeButton onClick={() => applyQuickRange('7d')}>7 дней</QuickRangeButton>
            <QuickRangeButton onClick={() => applyQuickRange('30d')}>30 дней</QuickRangeButton>
            <QuickRangeButton onClick={() => applyQuickRange('month')}>Этот месяц</QuickRangeButton>
          </div>

          <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-[170px_170px_210px_210px_150px_110px]">
            <div>
              <div className="mb-1.5 text-xs font-medium text-white/55">Дата от</div>
              <input
                type="date"
                className="h-11 w-full rounded-2xl border border-white/10 bg-white/[0.05] px-3.5 text-sm text-white outline-none"
                value={dateFrom}
                onChange={(e) => setDateFrom(e.target.value)}
              />
            </div>

            <div>
              <div className="mb-1.5 text-xs font-medium text-white/55">Дата до</div>
              <input
                type="date"
                className="h-11 w-full rounded-2xl border border-white/10 bg-white/[0.05] px-3.5 text-sm text-white outline-none"
                value={dateTo}
                onChange={(e) => setDateTo(e.target.value)}
              />
            </div>

            <div>
              <div className="mb-1.5 text-xs font-medium text-white/55">Филиал</div>
              <select
                className="h-11 w-full rounded-2xl border border-white/10 bg-white/[0.05] px-3.5 text-sm text-white outline-none"
                value={branchId}
                onChange={(e) => {
                  setBranchId(e.target.value);
                  setEmployeeId('');
                }}
              >
                <option value="">Все филиалы</option>
                {branches.map((branch) => (
                  <option key={branch.id} value={branch.id}>
                    {branch.name || branch.title || `Филиал #${branch.id}`}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <div className="mb-1.5 text-xs font-medium text-white/55">Сотрудник</div>
              <select
                className="h-11 w-full rounded-2xl border border-white/10 bg-white/[0.05] px-3.5 text-sm text-white outline-none"
                value={employeeId}
                onChange={(e) => setEmployeeId(e.target.value)}
              >
                <option value="">Все сотрудники</option>
                {filteredEmployees.map((employee) => (
                  <option key={employee.id} value={employee.id}>
                    {employee.name || employee.full_name || employee.fio || `Сотрудник #${employee.id}`}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-end">
              <button
                className="h-11 w-full rounded-2xl bg-gradient-to-r from-cyan-400 to-violet-500 px-4 text-sm font-bold text-white shadow-[0_10px_24px_rgba(79,70,229,0.25)] transition hover:opacity-95"
                onClick={loadAnalytics}
                disabled={loading}
              >
                {loading ? 'Загрузка...' : 'Применить'}
              </button>
            </div>

            <div className="flex items-end">
              <button
                className="h-11 w-full rounded-2xl border border-white/10 bg-white/[0.04] px-4 text-sm font-semibold text-white/80 transition hover:bg-white/[0.08]"
                onClick={resetFilters}
                type="button"
              >
                Сбросить
              </button>
            </div>
          </div>

          {pageError ? (
            <div className="mt-3 rounded-2xl border border-red-400/30 bg-red-500/10 px-4 py-3 text-sm text-red-200">
              {pageError}
            </div>
          ) : null}
        </div>

        <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-7">
          <KpiCard
            title="Выручка за период"
            value={formatMoney(revenue)}
            subtitle={getPeriodLabel(dateFrom, dateTo)}
            onClick={() => openDetail('revenue')}
            tooltip="Сумма завершенных записей за выбранный период."
          />
          <KpiCard
            title="Потеряно из-за отмен"
            value={formatMoney(lostRevenue)}
            subtitle="Сумма отмененных записей"
            tone="warning"
            onClick={() => openDetail('lostRevenue')}
            tooltip="Сумма записей со статусами отмены. Показывает, сколько денег потеряно."
          />
          <KpiCard
            title="Всего записей"
            value={totalBookings}
            subtitle="Все статусы"
            onClick={() => openDetail('total')}
            tooltip="Количество всех записей за выбранный период, независимо от статуса."
          />
          <KpiCard
            title="Завершенные записи"
            value={completedBookings}
            subtitle="Успешные записи"
            tone="success"
            onClick={() => openDetail('completed')}
            tooltip="Количество записей со статусами completed / done / finished / confirmed."
          />
          <KpiCard
            title="Отмененные записи"
            value={cancelledBookings}
            subtitle="Потери периода"
            tone="danger"
            onClick={() => openDetail('cancelled')}
            tooltip="Количество записей со статусами cancelled / canceled / no_show."
          />
          <KpiCard
            title="Средний чек"
            value={formatMoney(avgCheck)}
            subtitle="Средняя выручка на запись"
            onClick={() => openDetail('revenue')}
            tooltip="Выручка / количество завершенных записей."
          />
          <KpiCard
            title="Доля отмен"
            value={formatPercent(cancelRate)}
            subtitle="Доля отмен"
            tone="danger"
            onClick={() => openDetail('cancelled')}
            tooltip="Отмененные записи / все записи * 100%."
          />
        </div>

        <div className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-6">
          <InsightCard
            title="Лучший сотрудник по выручке"
            value={topEmployee?.employee_name || '—'}
            subvalue={topEmployee ? formatMoney(topEmployee.revenue) : 'Нет данных'}
          />
          <InsightCard
            title="Лучшая услуга по выручке"
            value={topService?.service_name || '—'}
            subvalue={topService ? formatMoney(topService.revenue) : 'Нет данных'}
          />
<InsightCard
  title="Лучший день по выручке"
  value={topDay?.date ? formatDateMedium(topDay.date) : '—'}
  subvalue={topDay ? formatMoney(topDay.revenue) : 'Нет данных'}
/>
          <InsightCard
            title="Пиковый час"
            value={topHour?.hour_label || '—'}
            subvalue={topHour ? formatMoney(topHour.revenue) : 'Нет данных'}
          />
          <InsightCard
            title="Проблемный сотрудник по отменам"
            value={problematicEmployee?.employee_name || '—'}
            subvalue={
              problematicEmployee
                ? `${problematicEmployee.cancelled_bookings || 0} отмен`
                : 'Нет данных'
            }
          />
          <InsightCard
            title="Филиал с наибольшими потерями"
            value={branchWithMaxLostRevenue?.branch_name || '—'}
            subvalue={
              branchWithMaxLostRevenue
                ? formatMoney(branchWithMaxLostRevenue.lost_revenue || 0)
                : 'Нет данных'
            }
          />
        </div>

        <div className="mt-4 grid grid-cols-1 gap-4 xl:grid-cols-2">
          <Block title="Динамика выручки по дням" subtitle="Где период реально зарабатывал" error={blockErrors.revenueDynamics}>
            <RevenueList rows={revenueDynamics} />
          </Block>

          <Block title="Сравнение с прошлым периодом" subtitle="Текущий диапазон против предыдущего такого же по длине" error={blockErrors.compareData}>
            <div className="rounded-[20px] bg-white/[0.04] p-4">
              <div className="text-sm text-white/45">Итог</div>
              <div className="mt-2 text-xl font-bold text-white">{compareText}</div>

              {compareData ? (
                <div className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-2">
                  <div className="rounded-2xl bg-white/[0.04] p-4">
                    <div className="text-sm text-white/45">Текущий период</div>
                    <div className="mt-2 text-lg font-bold text-white">
                      {formatMoney(compareData.current_revenue)}
                    </div>
                  </div>
                  <div className="rounded-2xl bg-white/[0.04] p-4">
                    <div className="text-sm text-white/45">Прошлый период</div>
                    <div className="mt-2 text-lg font-bold text-white">
                      {formatMoney(compareData.previous_revenue)}
                    </div>
                  </div>
                </div>
              ) : null}
            </div>
          </Block>
        </div>

        <div className="mt-4 grid grid-cols-1 gap-4 xl:grid-cols-2">
          <Block title="Филиалы" subtitle="Сравнение филиалов по записям, выручке и потерям" error={blockErrors.branchesTable}>
            <MiniTable
              rows={branchesTable}
              columns={[
                { key: 'branch_name', title: 'Филиал' },
                { key: 'total_bookings', title: 'Записей' },
                { key: 'completed_bookings', title: 'Завершено' },
                { key: 'cancelled_bookings', title: 'Отменено' },
                { key: 'revenue', title: 'Выручка', render: (v) => formatMoney(v) },
                { key: 'lost_revenue', title: 'Потери', render: (v) => formatMoney(v) },
              ]}
            />
          </Block>

          <Block title="Рейтинг сотрудников" subtitle="Кто реально тащит выручку и завершенные записи" error={blockErrors.employeesRating}>
            <MiniTable
              rows={employeesRating}
              columns={[
                { key: 'employee_name', title: 'Сотрудник' },
                { key: 'total_bookings', title: 'Записей' },
                { key: 'completed_bookings', title: 'Завершено' },
                { key: 'cancelled_bookings', title: 'Отменено' },
                { key: 'revenue', title: 'Выручка', render: (v) => formatMoney(v) },
              ]}
            />
          </Block>
        </div>

        <div className="mt-4 grid grid-cols-1 gap-4 xl:grid-cols-2">
          <Block title="Рейтинг услуг" subtitle="Что приносит деньги, а что просто болтается" error={blockErrors.servicesRating}>
            <MiniTable
              rows={servicesRating}
              columns={[
                { key: 'service_name', title: 'Услуга' },
                { key: 'total_bookings', title: 'Записей' },
                { key: 'completed_bookings', title: 'Завершено' },
                { key: 'cancelled_bookings', title: 'Отменено' },
                { key: 'revenue', title: 'Выручка', render: (v) => formatMoney(v) },
              ]}
            />
          </Block>

          <Block title="Выручка по дням недели" subtitle="В какие дни бизнес сильнее" error={blockErrors.weekdayStats}>
            <BarsList rows={weekdayStats} labelKey="day_label" valueKey="revenue" />
          </Block>
        </div>

        <div className="mt-4 grid grid-cols-1 gap-4 xl:grid-cols-2">
          <Block title="Выручка по часам" subtitle="Пиковые часы записи" error={blockErrors.hourStats}>
            <BarsList rows={hourStats} labelKey="hour_label" valueKey="revenue" />
          </Block>

          <Block title="Сводка диапазона" subtitle="Общий срез по выбранным фильтрам" error={blockErrors.summary}>
            <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
              <div className="rounded-2xl bg-white/[0.04] p-4">
                <div className="text-sm text-white/45">Клиенты</div>
                <div className="mt-2 text-2xl font-bold text-white">{summary?.unique_clients || 0}</div>
              </div>
              <div className="rounded-2xl bg-white/[0.04] p-4">
                <div className="text-sm text-white/45">Сотрудники</div>
                <div className="mt-2 text-2xl font-bold text-white">{summary?.unique_employees || 0}</div>
              </div>
              <div className="rounded-2xl bg-white/[0.04] p-4">
                <div className="text-sm text-white/45">Услуги</div>
                <div className="mt-2 text-2xl font-bold text-white">{summary?.unique_services || 0}</div>
              </div>
              <div className="rounded-2xl bg-white/[0.04] p-4">
                <div className="text-sm text-white/45">Филиалы</div>
                <div className="mt-2 text-2xl font-bold text-white">{summary?.unique_branches || 0}</div>
              </div>
            </div>
          </Block>
        </div>
      </div>

      <AnalyticsDetailPanel
        open={detailOpen}
        onClose={() => setDetailOpen(false)}
        queryParams={queryParams}
        metricKey={detailMetric}
        onOpenBooking={handleOpenBooking}
        branchLabel={selectedBranchLabel}
        employeeLabel={selectedEmployeeLabel}
      />
    </div>
  );
}