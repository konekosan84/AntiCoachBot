import React, { useMemo } from "react";
import { ruWeekdayShortMon } from "./scheduleDate.js";

function parseMinutes(hhmm) {
  const [h, m] = String(hhmm || "0:0").split(":").map(Number);
  return (h || 0) * 60 + (m || 0);
}
function durHours(start, end) {
  const a = parseMinutes(start);
  const b = parseMinutes(end);
  const diff = Math.max(0, b - a);
  return diff / 60;
}

export default function ScheduleWeekGrid({
  dates,           // 7 x YYYY-MM-DD
  employees,
  shifts,
  branchNameById,  // Map
  onAddShift,      // ({date, employee_id, branch_id})
  onShiftClick,
}) {
  const index = useMemo(() => {
    const cell = new Map(); // `${date}|${emp}` -> shifts[]
    const totals = new Map(); // emp -> {count, hours}

    for (const s of shifts || []) {
      const d = String(s.date).slice(0, 10);
      const k = `${d}|${s.employee_id}`;
      if (!cell.has(k)) cell.set(k, []);
      cell.get(k).push(s);

      const emp = Number(s.employee_id);
      if (!totals.has(emp)) totals.set(emp, { count: 0, hours: 0 });
      const t = totals.get(emp);
      t.count += 1;
      t.hours += durHours(s.start_time, s.end_time);
      totals.set(emp, t);
    }

    for (const [k, arr] of cell.entries()) {
      arr.sort((a, b) => String(a.start_time).localeCompare(String(b.start_time)));
      cell.set(k, arr);
    }

    return { cell, totals };
  }, [shifts]);

  return (
    <div className="p-4 overflow-auto">
      <div className="text-lg font-semibold mb-3">Неделя</div>

      <div
        className="min-w-[1100px] grid"
        style={{ gridTemplateColumns: `260px repeat(${dates.length}, minmax(170px, 1fr))` }}
      >
        <div className="p-2 font-medium opacity-70">Сотрудник</div>
        {dates.map((d, i) => (
          <div key={d} className="p-2 font-medium">
            {ruWeekdayShortMon[i]} <span className="opacity-70">{d}</span>
          </div>
        ))}

        {employees.map((e) => {
          const t = index.totals.get(Number(e.id)) || { count: 0, hours: 0 };
          return (
            <React.Fragment key={e.id}>
              <div className="p-2 border-t border-white/10">
                <div className="font-semibold">{e.name}</div>
                <div className="text-xs opacity-70 mt-1">
                  Смен: {t.count} • Часов: {t.hours.toFixed(1)}
                </div>
              </div>

              {dates.map((d) => {
                const key = `${d}|${e.id}`;
                const list = index.cell.get(key) || [];
                return (
                  <div
                    key={key}
                    className="p-2 border-t border-l border-white/10 rounded-xl hover:bg-white/5 cursor-pointer"
                    onClick={() => onAddShift?.({ date: d, employee_id: e.id, branch_id: null })}
                    title="Клик по ячейке: добавить смену"
                  >
                    {list.length === 0 ? (
                      <div className="text-xs opacity-40 mt-7 select-none">—</div>
                    ) : (
                      <div className="grid gap-2">
                        {list.map((s) => {
                          const branch = branchNameById?.get?.(Number(s.branch_id)) || `Филиал #${s.branch_id}`;
                          return (
                            <button
                              key={s.id}
                              className="text-left rounded-xl bg-white/10 hover:bg-white/20 px-2 py-2"
                              onClick={(ev) => {
                                ev.stopPropagation();
                                onShiftClick?.(s);
                              }}
                            >
                              <div className="text-sm font-semibold">
                                {s.start_time}–{s.end_time}
                              </div>
                              <div className="text-[11px] opacity-70 mt-1">{branch}</div>
                              {s.notes ? (
                                <div className="text-[11px] opacity-70 mt-1 line-clamp-2">
                                  {s.notes}
                                </div>
                              ) : null}
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
}