import ScheduleDayGrid from "./ScheduleDayGrid";
import ScheduleWeekGrid from "./ScheduleWeekGrid";
import ScheduleMonthGrid from "./ScheduleMonthGrid";

export default function ScheduleGrid({
  mode,
  anchorDate,
  employees,
  shifts,
  selectedEmployeeId,

  branches = [],
  selectedBranchId = null,

  onPickDate,
  onEditShift,
  onCreateShift,
}) {
  if (mode === "month") {
    return (
      <ScheduleMonthGrid
        anchorDate={anchorDate}
        employees={employees}
        shifts={shifts}
        selectedEmployeeId={selectedEmployeeId}
        branches={branches}
        selectedBranchId={selectedBranchId}
        onPickDate={onPickDate}
        onEditShift={onEditShift}
        onCreateShift={onCreateShift}
      />
    );
  }

  if (mode === "week") {
    return (
      <ScheduleWeekGrid
        anchorDate={anchorDate}
        employees={employees}
        shifts={shifts}
        selectedEmployeeId={selectedEmployeeId}
        branches={branches}
        selectedBranchId={selectedBranchId}
        onEditShift={onEditShift}
        onCreateShift={onCreateShift}
      />
    );
  }

  return (
    <ScheduleDayGrid
      anchorDate={anchorDate}
      employees={employees}
      shifts={shifts}
      selectedEmployeeId={selectedEmployeeId}
      branches={branches}
      selectedBranchId={selectedBranchId}
      onEditShift={onEditShift}
      onCreateShift={onCreateShift}
    />
  );
}

