import React, { useMemo } from "react";
import { toYmd, addDaysYmd, ruWeekdayShortMon, todayYmd } from "./scheduleDate.js";

function parseMinutes(hhmm) {
  const [h, m] = String(hhmm || "0:0").split(":").map(Number);
  return (h || 0) * 60 + (m || 0);
}
function durHours(start, end) {
  const a = parseMinutes(start);
  const b = parseMinutes(end);
  const diff = Math.max(0, b - a);
  return diff / 60;
}

function monthGridStart(anchorYmd) {
  const [y, m, d] = String(anchorYmd).slice(0, 10).split("-").map(Number);
  const first = new Date(y, m - 1, 1);
  const dow = first.getDay(); // 0 Sun
  const diff = (dow === 0 ? -6 : 1 - dow); // к понедельнику
  first.setDate(first.getDate() + diff);
  return toYmd(first);
}

export default function ScheduleMonthGrid({
  anchorDate, // YYYY-MM-DD
  shifts,
  onPickDate, // (ymd) => void

  // новые пропсы (не обязательные)
  branchId = "all",
  branchNameById, // Map<number,string> или объект { [id]: name }
}) {
  const start = useMemo(() => monthGridStart(anchorDate), [anchorDate]);
  const days = useMemo(
    () => Array.from({ length: 42 }, (_, i) => addDaysYmd(start, i)),
    [start]
  );

  const today = useMemo(() => todayYmd(), []);
  const [ay, am] = String(anchorDate).slice(0, 10).split("-").map(Number);

  const getBranchName = (bid) => {
    const n = Number(bid);
    if (!Number.isFinite(n)) return "Филиал";
    if (branchNameById instanceof Map) return branchNameById.get(n) || `Филиал #${n}`;
    if (branchNameById && typeof branchNameById === "object") return branchNameById[n] || `Филиал #${n}`;
    return `Филиал #${n}`;
  };

  const statsByDay = useMemo(() => {
    // ymd -> { totalCount, totalHours, byBranch: Map(branchId -> {count,hours}) }
    const m = new Map();

    for (const s of shifts || []) {
      const d = String(s.date).slice(0, 10);
      const bid = Number(s.branch_id);
      const h = durHours(s.start_time, s.end_time);

      if (!m.has(d)) m.set(d, { totalCount: 0, totalHours: 0, byBranch: new Map() });
      const t = m.get(d);

      t.totalCount += 1;
      t.totalHours += h;

      const bb = t.byBranch.get(bid) || { count: 0, hours: 0 };
      bb.count += 1;
      bb.hours += h;
      t.byBranch.set(bid, bb);

      m.set(d, t);
    }

    return m;
  }, [shifts]);

  const showBranchBreakdown = String(branchId) === "all";

  return (
    <div className="p-4">
      <div className="text-lg font-semibold mb-3">Месяц</div>

      <div className="grid grid-cols-7 gap-2 mb-2">
        {ruWeekdayShortMon.map((w) => (
          <div key={w} className="text-xs opacity-70 px-2">
            {w}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-7 gap-2">
        {days.map((d) => {
          const [y, m, dayNum] = d.split("-").map(Number);
          const inMonth = y === ay && m === am;
          const isToday = d === today;

          const st = statsByDay.get(d) || { totalCount: 0, totalHours: 0, byBranch: new Map() };

          const branchPairs = showBranchBreakdown
            ? Array.from(st.byBranch.entries())
                .map(([bid, v]) => ({ bid, ...v }))
                .sort((a, b) => b.count - a.count)
            : [];

          const top = branchPairs.slice(0, 2);
          const rest = branchPairs.length - top.length;

          return (
            <button
              key={d}
              className={[
                "text-left rounded-2xl border border-white/10 p-3 bg-white/5 hover:bg-white/10 transition",
                inMonth ? "" : "opacity-50",
                isToday ? "ring-2 ring-cyan-400/60 bg-cyan-400/10" : "",
              ].join(" ")}
              onClick={() => onPickDate?.(d)}
              title={isToday ? "Сегодня" : ""}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2">
                  <div className="font-semibold">{dayNum}</div>
                  {isToday && <div className="w-2 h-2 rounded-full bg-cyan-300" />}
                </div>

                <div className="text-xs opacity-70">
                  {st.totalCount > 0 ? `${st.totalCount} смен` : "—"}
                </div>
              </div>

              {st.totalCount > 0 ? (
                <>
                  <div className="text-xs opacity-70 mt-2">{st.totalHours.toFixed(1)} ч</div>

                  {showBranchBreakdown && branchPairs.length > 0 && (
                    <div className="mt-2 space-y-1 text-xs text-white/70">
                      {top.map((b) => (
                        <div key={b.bid} className="flex items-start justify-between gap-2">
                          <span className="truncate">{getBranchName(b.bid)}</span>
                          <span className="shrink-0 text-white/80 text-right">
                            {b.count} · {b.hours.toFixed(1)}ч
                          </span>
                        </div>
                      ))}
                      {rest > 0 && <div className="text-white/50">+ ещё {rest}</div>}
                    </div>
                  )}
                </>
              ) : (
                <div className="text-xs opacity-40 mt-2">нет смен</div>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}