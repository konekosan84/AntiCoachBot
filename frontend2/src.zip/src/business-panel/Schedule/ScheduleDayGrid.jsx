import React, { useMemo } from "react";

function parseMinutes(hhmm) {
  const [h, m] = String(hhmm || "0:0").split(":").map(Number);
  return (h || 0) * 60 + (m || 0);
}
function durHours(start, end) {
  const a = parseMinutes(start);
  const b = parseMinutes(end);
  const diff = Math.max(0, b - a);
  return diff / 60;
}

export default function ScheduleDayGrid({
  date,                 // YYYY-MM-DD
  employees,
  shifts,
  branchNameById,       // Map(branch_id -> name)
  onAddShift,           // ({date, employee_id, branch_id})
  onShiftClick,
}) {
  const byEmp = useMemo(() => {
    const m = new Map();
    for (const e of employees) m.set(Number(e.id), []);
    for (const s of shifts || []) {
      const d = String(s.date).slice(0, 10);
      if (d !== date) continue;
      const k = Number(s.employee_id);
      if (!m.has(k)) m.set(k, []);
      m.get(k).push(s);
    }
    for (const [k, arr] of m.entries()) {
      arr.sort((a, b) => String(a.start_time).localeCompare(String(b.start_time)));
      m.set(k, arr);
    }
    return m;
  }, [employees, shifts, date]);

  return (
    <div className="p-4">
      <div className="text-lg font-semibold mb-3">День: {date}</div>

      <div className="grid gap-3">
        {employees.map((e) => {
          const list = byEmp.get(Number(e.id)) || [];
          const totalHours = list.reduce((sum, s) => sum + durHours(s.start_time, s.end_time), 0);
          return (
            <div key={e.id} className="rounded-2xl border border-white/10 bg-white/5 p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="font-semibold">{e.name}</div>
                  <div className="text-xs opacity-70 mt-1">
                    Смен: {list.length} • Часов: {totalHours.toFixed(1)}
                  </div>
                </div>

                <button
                  className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-sm"
                  onClick={() => onAddShift?.({ date, employee_id: e.id, branch_id: null })}
                >
                  + смена
                </button>
              </div>

              {list.length === 0 ? (
                <div className="text-sm opacity-60 mt-3">Смен нет</div>
              ) : (
                <div className="mt-3 grid gap-2">
                  {list.map((s) => {
                    const branch = branchNameById?.get?.(Number(s.branch_id)) || `Филиал #${s.branch_id}`;
                    return (
                      <button
                        key={s.id}
                        className="text-left rounded-xl bg-white/10 hover:bg-white/20 px-3 py-3"
                        onClick={() => onShiftClick?.(s)}
                      >
                        <div className="font-semibold">
                          {s.start_time}–{s.end_time}
                        </div>
                        <div className="text-xs opacity-70 mt-1">{branch}</div>
                        {s.notes ? (
                          <div className="text-xs opacity-70 mt-1 line-clamp-2">
                            {s.notes}
                          </div>
                        ) : null}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}