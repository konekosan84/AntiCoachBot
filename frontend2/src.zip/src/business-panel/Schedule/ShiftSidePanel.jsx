import React, { useEffect, useMemo, useState } from "react";
import { createShift, updateShift, deleteShift } from "../../api/schedule.js";
import { isYmd, todayYmd } from "./scheduleDate.js";

function branchLabel(branches, id) {
  const bid = Number(id);
  const b = (branches || []).find((x) => Number(x.id) === bid);
  return b?.name || `Филиал #${bid}`;
}

export default function ShiftSidePanel({
  open,
  mode, // 'create' | 'edit'
  initial, // { id?, date, employee_id, branch_id, start_time, end_time, notes }
  branches = [],
  employees = [],
  onClose,
  onSaved, // () => void
}) {
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState("");

  const [form, setForm] = useState({
    id: null,
    date: todayYmd(),
    branch_id: "",
    employee_id: "",
    start_time: "10:00",
    end_time: "19:00",
    notes: "",
  });

  useEffect(() => {
    if (!open) return;
    const src = initial || {};
    setErr("");
    setForm({
      id: src.id ?? null,
      date: isYmd(src.date) ? src.date : (src.date ? String(src.date).slice(0, 10) : todayYmd()),
      branch_id: src.branch_id ?? "",
      employee_id: src.employee_id ?? "",
      start_time: src.start_time ?? "10:00",
      end_time: src.end_time ?? "19:00",
      notes: src.notes ?? "",
    });
  }, [open, initial]);

  const title = useMemo(() => (mode === "edit" ? "Редактировать смену" : "Новая смена"), [mode]);

  if (!open) return null;

  async function onSave() {
    setErr("");

    if (!isYmd(form.date)) return setErr("Дата должна быть YYYY-MM-DD.");
    if (!form.branch_id) return setErr("Выбери филиал.");
    if (!form.employee_id) return setErr("Выбери сотрудника.");
    if (!form.start_time || !form.end_time) return setErr("Укажи время.");
    if (String(form.end_time) <= String(form.start_time)) return setErr("Конец должен быть позже начала.");

    const payload = {
      date: form.date, // СТРОКА. Без Date. Без ISO. Без цирка.
      branch_id: Number(form.branch_id),
      employee_id: Number(form.employee_id),
      start_time: String(form.start_time),
      end_time: String(form.end_time),
      notes: form.notes ? String(form.notes) : null,
    };

    setSaving(true);
    try {
      if (mode === "edit" && form.id) {
        await updateShift(form.id, payload);
      } else {
        await createShift(payload);
      }
      onSaved?.();
      onClose?.();
    } catch (e) {
      // Красиво обрабатываем конфликт пересечения смен
      if (e?.status === 409 && e?.payload?.error === "SHIFT_OVERLAP") {
        const o = e.payload.overlap;
        const bName = o?.branch_id != null ? branchLabel(branches, o.branch_id) : "";
        const msg = [
          "Пересечение со сменой.",
          o ? `Смена #${o.id}: ${o.start_time}–${o.end_time}` : "",
          bName ? `Филиал: ${bName}` : "",
          o?.notes ? `Комментарий: ${o.notes}` : "",
        ].filter(Boolean).join("\n");
        setErr(msg);
      } else {
        setErr(e?.message || "Ошибка сохранения");
      }
    } finally {
      setSaving(false);
    }
  }

  async function onRemove() {
    if (!form.id) return;
    setErr("");
    setSaving(true);
    try {
      await deleteShift(form.id);
      onSaved?.();
      onClose?.();
    } catch (e) {
      setErr(e?.message || "Ошибка удаления");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="fixed right-0 top-0 h-full w-[420px] bg-black/60 backdrop-blur-xl border-l border-white/10 p-4 z-50">
      <div className="flex items-center justify-between mb-3">
        <div className="text-lg font-semibold">{title}</div>
        <button className="px-3 py-1 rounded-lg bg-white/10 hover:bg-white/20" onClick={onClose}>
          Закрыть
        </button>
      </div>

      {err && (
        <div className="mb-3 p-3 rounded-xl bg-red-500/20 border border-red-500/30 text-sm whitespace-pre-line">
          {err}
        </div>
      )}

      <div className="grid gap-3">
        <label className="grid gap-1">
          <div className="text-sm opacity-70">Дата</div>
          <input
            type="date"
            className="px-3 py-2 rounded-xl bg-white/10 border border-white/10"
            value={form.date}
            onChange={(e) => setForm((p) => ({ ...p, date: e.target.value }))}
          />
        </label>

        <label className="grid gap-1">
          <div className="text-sm opacity-70">Филиал</div>
          <select
            className="px-3 py-2 rounded-xl bg-white/10 border border-white/10"
            value={form.branch_id}
            onChange={(e) => setForm((p) => ({ ...p, branch_id: e.target.value }))}
          >
            <option value="">Выбрать…</option>
            {branches.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name || `Филиал #${b.id}`}
              </option>
            ))}
          </select>
        </label>

        <label className="grid gap-1">
          <div className="text-sm opacity-70">Сотрудник</div>
          <select
            className="px-3 py-2 rounded-xl bg-white/10 border border-white/10"
            value={form.employee_id}
            onChange={(e) => setForm((p) => ({ ...p, employee_id: e.target.value }))}
          >
            <option value="">Выбрать…</option>
            {employees.map((emp) => (
              <option key={emp.id} value={emp.id}>
                {emp.name || `Сотрудник #${emp.id}`}
              </option>
            ))}
          </select>
        </label>

        <div className="grid grid-cols-2 gap-3">
          <label className="grid gap-1">
            <div className="text-sm opacity-70">Начало</div>
            <input
              type="time"
              className="px-3 py-2 rounded-xl bg-white/10 border border-white/10"
              value={form.start_time}
              onChange={(e) => setForm((p) => ({ ...p, start_time: e.target.value }))}
            />
          </label>

          <label className="grid gap-1">
            <div className="text-sm opacity-70">Конец</div>
            <input
              type="time"
              className="px-3 py-2 rounded-xl bg-white/10 border border-white/10"
              value={form.end_time}
              onChange={(e) => setForm((p) => ({ ...p, end_time: e.target.value }))}
            />
          </label>
        </div>

        <label className="grid gap-1">
          <div className="text-sm opacity-70">Комментарий</div>
          <textarea
            rows={4}
            className="px-3 py-2 rounded-xl bg-white/10 border border-white/10"
            value={form.notes}
            onChange={(e) => setForm((p) => ({ ...p, notes: e.target.value }))}
          />
        </label>

        <div className="flex gap-2">
          <button
            className="flex-1 px-3 py-2 rounded-xl bg-white/15 hover:bg-white/25 disabled:opacity-50"
            disabled={saving}
            onClick={onSave}
          >
            {saving ? "Сохраняю…" : "Сохранить"}
          </button>

          {mode === "edit" && form.id && (
            <button
              className="px-3 py-2 rounded-xl bg-red-500/20 hover:bg-red-500/30 border border-red-500/30 disabled:opacity-50"
              disabled={saving}
              onClick={onRemove}
            >
              Удалить
            </button>
          )}
        </div>
      </div>
    </div>
  );
}