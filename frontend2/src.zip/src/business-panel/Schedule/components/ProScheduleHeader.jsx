import React from "react";

export default function ProScheduleHeader({
  branches,
  selectedBranch,
  setSelectedBranch,

  employees,
  selectedEmployee,
  setSelectedEmployee,

  rooms,
  selectedRoom,
  setSelectedRoom,

  weekStart,
  setWeekStart,
}) {

  const moveWeek = (dir) => {
    const newDate = new Date(weekStart);
    newDate.setDate(newDate.getDate() + dir * 7);
    setWeekStart(newDate);
  };

  return (
    <div className="pro-header">

      <div className="left">
        <h2>Smart Schedule PRO</h2>

        <div className="filter">
          <label>Филиал</label>
          <select
            value={selectedBranch}
            onChange={(e) => setSelectedBranch(e.target.value)}
          >
            {branches.map((b) => (
              <option key={b.id} value={b.id}>{b.name}</option>
            ))}
          </select>
        </div>

        <div className="filter">
          <label>Сотрудник</label>
          <select
            value={selectedEmployee}
            onChange={(e) => setSelectedEmployee(e.target.value)}
          >
            <option value="all">Все</option>
            {employees.map((e) => (
              <option key={e.id} value={e.id}>{e.name}</option>
            ))}
          </select>
        </div>

        <div className="filter">
          <label>Помещение</label>
          <select
            value={selectedRoom}
            onChange={(e) => setSelectedRoom(e.target.value)}
          >
            <option value="all">Все</option>
            {rooms.map((r) => (
              <option key={r.id} value={r.id}>{r.name}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="right">
        <button onClick={() => moveWeek(-1)}>← Неделя</button>
        <div className="current-week">
          {weekStart.toLocaleDateString()}
        </div>
        <button onClick={() => moveWeek(1)}>Неделя →</button>
      </div>

    </div>
  );
}
