import React, { useState, useEffect } from "react";
import "./ShiftModalPRO.css";

export default function ShiftModalPRO({
  open,
  onClose,
  onSaved,
  editing,
  branches,
  employees,
  rooms
}) {
  if (!open) return null;

  // ==============================
  // INITIAL VALUES (CREATE / EDIT)
  // ==============================
  const [branchId, setBranchId] = useState(editing?.branch_id || "");
  const [employeeId, setEmployeeId] = useState(editing?.employee_id || "");
  const [roomId, setRoomId] = useState(editing?.room_id || "");

  const [date, setDate] = useState(editing?.date || "");
  const [start, setStart] = useState(editing?.start_time || "09:00");
  const [end, setEnd] = useState(editing?.end_time || "18:00");

  // ==============================
  // VALIDATION
  // ==============================
  const canSave =
    branchId && employeeId && roomId && date && start && end;

  const save = () => {
    if (!canSave) return;

    const payload = {
      branch_id: branchId,
      employee_id: employeeId,
      room_id: roomId,
      date,
      start_time: start,
      end_time: end,
    };

    onSaved(payload, editing?.id || null);
  };

  return (
    <div className="shift-modal-overlay">
      <div className="shift-modal-window glass-neo">

        <h2>{editing ? "Редактировать смену" : "Создать смену"}</h2>

        {/* BRANCH */}
        <label>Филиал</label>
        <select
          value={branchId}
          onChange={(e) => setBranchId(e.target.value)}
        >
          <option value="">Выберите…</option>
          {branches.map((b) => (
            <option key={b.id} value={b.id}>
              {b.name}
            </option>
          ))}
        </select>

        {/* EMPLOYEE */}
        <label>Сотрудник</label>
        <select
          value={employeeId}
          onChange={(e) => setEmployeeId(e.target.value)}
        >
          <option value="">Выберите…</option>
          {employees
            .filter((e) => !branchId || e.branches?.some((b) => b.id == branchId))
            .map((e) => (
              <option key={e.id} value={e.id}>
                {e.name}
              </option>
            ))}
        </select>

        {/* ROOM */}
        <label>Помещение</label>
        <select
          value={roomId}
          onChange={(e) => setRoomId(e.target.value)}
        >
          <option value="">Выберите…</option>
          {rooms
            .filter((r) => !branchId || r.branches?.includes(branchId))
            .map((r) => (
              <option key={r.id} value={r.id}>
                {r.name}
              </option>
            ))}
        </select>

        {/* DATE */}
        <label>Дата</label>
        <input
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
        />

        {/* TIME START */}
        <label>Начало</label>
        <input
          type="time"
          value={start}
          onChange={(e) => setStart(e.target.value)}
        />

        {/* TIME END */}
        <label>Конец</label>
        <input
          type="time"
          value={end}
          onChange={(e) => setEnd(e.target.value)}
        />

        <div className="shift-modal-actions">
          <button className="neo-btn cancel" onClick={onClose}>
            Отмена
          </button>

          <button
            className={`neo-btn save ${!canSave ? "disabled" : ""}`}
            onClick={save}
          >
            Сохранить
          </button>
        </div>
      </div>
    </div>
  );
}

