import React from "react";

export default function ProWeekTimeline({
  weekStart,
  shifts,
  employees,
  rooms,
  filterEmployee,
  filterRoom,
}) {
  const days = [...Array(7)].map((_, i) => {
    const d = new Date(weekStart);
    d.setDate(d.getDate() + i);
    return d;
  });

  const hours = [...Array(24)].map((_, i) => i);

  const filtered = shifts.filter((s) => {
    if (filterEmployee !== "all" && s.employee_id != filterEmployee) return false;
    if (filterRoom !== "all" && s.room_id != filterRoom) return false;
    return true;
  });

  const getPosition = (shift) => {
    const start = new Date(shift.start_time);
    const end = new Date(shift.end_time);

    const dayIndex =
      Math.floor((start - weekStart) / (1000 * 60 * 60 * 24));

    const top = start.getHours() * 50 + (start.getMinutes() / 60) * 50;
    const height =
      (end - start) / 1000 / 60 / 60 * 50;

    return { dayIndex, top, height };
  };

  return (
    <div className="timeline-grid">

      {/* DAYS HEADER */}
      <div className="days-row">
        <div className="time-col-header"></div>
        {days.map((d, i) => (
          <div key={i} className="day-col-header">
            {d.toLocaleDateString("ru-RU", { weekday: "short", day: "numeric" })}
          </div>
        ))}
      </div>

      {/* MAIN GRID */}
      <div className="timeline-body">
        <div className="time-col">
          {hours.map((h) => (
            <div key={h} className="time-slot">
              {h}:00
            </div>
          ))}
        </div>

        {days.map((day, dIndex) => (
          <div key={dIndex} className="day-col">
            {/* Смена — рендерим в колонке */}
            {filtered
              .filter((s) => {
                const start = new Date(s.start_time);
                return start.getDay() === day.getDay();
              })
              .map((shift) => {
                const pos = getPosition(shift);
                return (
                  <div
                    key={shift.id}
                    className="shift-block"
                    style={{
                      top: pos.top,
                      height: pos.height,
                    }}
                  >
                    <div className="shift-title">
                      {shift.employee_name}
                    </div>
                    <div className="shift-room">
                      {shift.room_name}
                    </div>
                  </div>
                );
              })}
          </div>
        ))}
      </div>
    </div>
  );
}
