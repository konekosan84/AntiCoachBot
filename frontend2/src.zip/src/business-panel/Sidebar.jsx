import React from "react";
import { NavLink } from "react-router-dom";
import "./styles/sidebar.css";

export default function Sidebar() {
  return (
    <div className="slotiq-sidebar">
      {/* LOGO BLOCK */}
      <div className="sidebar-logo">
        <div className="logo-icon">▦</div>
        <div className="logo-text">SLOTIQ PRO</div>
      </div>

      {/* NAVIGATION */}
      <nav className="sidebar-nav">
        <NavItem to="/dashboard" label="Главная" icon="🏠" />
        <NavItem to="/branches" label="Филиалы" icon="🏢" />
        <NavItem to="/employees" label="Сотрудники" icon="👤" />
        <NavItem to="/services" label="Услуги" icon="⭐" />
        <NavItem to="/rooms" label="Помещения" icon="🚪" />
        <NavItem to="/schedule" label="Расписание" icon="📅" />
        <NavItem to="/matrix" label="Матрица" icon="🔢" />
        <NavItem to="/clients" label="Клиенты" icon="🧩" />
        <NavItem to="/analytics" label="Аналитика" icon="📊" />
      </nav>

      {/* FOOTER */}
      <div className="sidebar-footer">
        <NavItem to="/settings" label="Настройки" icon="⚙️" />
        <NavItem to="/logout" label="Выйти" icon="⏻" />
      </div>
    </div>
  );
}

function NavItem({ to, label, icon }) {
  return (
    <NavLink
      to={to}
      className={({ isActive }) =>
        "sidebar-item" + (isActive ? " active" : "")
      }
    >
      <span className="sidebar-icon">{icon}</span>
      <span className="sidebar-label">{label}</span>
    </NavLink>
  );
}


