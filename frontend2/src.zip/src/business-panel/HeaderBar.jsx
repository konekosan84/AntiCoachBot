import React from "react";
import { useAuth } from "../helpers/AuthContext";
import { LogOut } from "lucide-react";

export default function HeaderBar() {
  const { auth, logout } = useAuth();

  return (
    <header
      className="
        h-16 flex items-center justify-between px-6
        bg-slate-900/60 backdrop-blur-xl
        border-b border-white/10
        shadow-lg shadow-black/30
      "
    >
      {/* ЛЕВАЯ ЧАСТЬ — НАЗВАНИЕ РАЗДЕЛА */}
      <div className="flex items-center gap-3">
        <h2 className="text-xl font-bold text-slate-100 tracking-tight drop-shadow">
          Панель управления
        </h2>
      </div>

      {/* ПРАВАЯ ЧАСТЬ — ПОЛЬЗОВАТЕЛЬ + ВЫХОД */}
      <div className="flex items-center gap-4">
        {/* EMAIL */}
        <div className="text-sm text-slate-300 bg-slate-800/40 px-3 py-1 rounded-lg border border-white/10">
          {auth?.user?.email}
        </div>

        {/* ВЫХОД */}
        <button
          onClick={logout}
          className="
            flex items-center gap-2 px-4 py-2 rounded-lg
            bg-red-600/80 border border-red-400/40
            text-white font-medium
            hover:bg-red-600 transition-all
            shadow-md hover:shadow-red-900/50
          "
        >
          <LogOut size={16} />
          Выйти
        </button>
      </div>
    </header>
  );
}
