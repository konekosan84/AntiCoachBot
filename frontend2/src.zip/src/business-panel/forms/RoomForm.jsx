// src/business-panel/forms/RoomForm.jsx

import React, { useState, useEffect } from "react";
import { createRoom, updateRoom } from "../../api/rooms";
import { getBranches } from "../../api/businesses";

const RoomForm = ({ room, onSaved }) => {
  const [branches, setBranches] = useState([]);

  const [form, setForm] = useState({
    name: "",
    branch_id: "",
    capacity: "",
    is_active: true,
  });

  useEffect(() => {
    loadBranches();
    if (room) {
      setForm({
        name: room.name || "",
        branch_id: room.branch_id || "",
        capacity: room.capacity || "",
        is_active: room.is_active ?? true,
      });
    }
  }, [room]);

  const loadBranches = async () => {
    const res = await getBranches();
    setBranches(res);
  };

  const updateField = (f, v) => setForm((p) => ({ ...p, [f]: v }));

  const handleSave = async () => {
    if (!form.name.trim()) return alert("Введите название помещения");

    let res;
    if (room) res = await updateRoom(room.id, form);
    else res = await createRoom(form);

    if (onSaved) onSaved(res);
  };

  return (
    <div className="neo-form">
      <div className="neo-form-group">
        <label>Название помещения</label>
        <input
          className="neo-input"
          value={form.name}
          onChange={(e) => updateField("name", e.target.value)}
          placeholder="Кабинет №1"
        />
      </div>

      <div className="neo-form-group">
        <label>Филиал</label>
        <select
          className="neo-select"
          value={form.branch_id}
          onChange={(e) => updateField("branch_id", e.target.value)}
        >
          <option value="">Выберите филиал</option>
          {branches.map((b) => (
            <option key={b.id} value={b.id}>
              {b.name}
            </option>
          ))}
        </select>
      </div>

      <div className="neo-form-group">
        <label>Вместимость</label>
        <input
          className="neo-input"
          type="number"
          value={form.capacity}
          onChange={(e) => updateField("capacity", e.target.value)}
          placeholder="12"
        />
      </div>

      <div className="neo-form-group">
        <label>Статус</label>
        <select
          className="neo-select"
          value={form.is_active ? "1" : "0"}
          onChange={(e) => updateField("is_active", e.target.value === "1")}
        >
          <option value="1">Активно</option>
          <option value="0">Не активно</option>
        </select>
      </div>

      <button className="neo-btn neo-btn-primary w-full mt-4" onClick={handleSave}>
        {room ? "Сохранить" : "Добавить помещение"}
      </button>
    </div>
  );
};

export default RoomForm;
