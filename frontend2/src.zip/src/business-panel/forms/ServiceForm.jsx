// src/business-panel/forms/ServiceForm.jsx

import React, { useState, useEffect } from "react";
import { createService, updateService } from "../../api/services";

const ServiceForm = ({ service, onSaved }) => {
  const [form, setForm] = useState({
    name: "",
    price: "",
    duration: "",
    description: "",
    is_active: true,
  });

  useEffect(() => {
    if (service) {
      setForm({
        name: service.name || "",
        price: service.price || "",
        duration: service.duration || "",
        description: service.description || "",
        is_active: service.is_active ?? true,
      });
    }
  }, [service]);

  const updateField = (f, val) => setForm((p) => ({ ...p, [f]: val }));

  const handleSave = async () => {
    if (!form.name.trim()) return alert("Название услуги обязательно");

    let res;
    if (service) res = await updateService(service.id, form);
    else res = await createService(form);

    if (onSaved) onSaved(res);
  };

  return (
    <div className="neo-form">
      <div className="neo-form-group">
        <label>Название услуги</label>
        <input
          className="neo-input"
          value={form.name}
          onChange={(e) => updateField("name", e.target.value)}
          placeholder="Английский, Китайский, Нейропсихология…"
        />
      </div>

      <div className="neo-form-group">
        <label>Цена</label>
        <input
          className="neo-input"
          type="number"
          value={form.price}
          onChange={(e) => updateField("price", e.target.value)}
          placeholder="1200"
        />
      </div>

      <div className="neo-form-group">
        <label>Длительность (минуты)</label>
        <input
          className="neo-input"
          type="number"
          value={form.duration}
          onChange={(e) => updateField("duration", e.target.value)}
          placeholder="60"
        />
      </div>

      <div className="neo-form-group">
        <label>Описание</label>
        <textarea
          className="neo-input min-h-[100px]"
          value={form.description}
          onChange={(e) => updateField("description", e.target.value)}
          placeholder="Подробное описание услуги…"
        ></textarea>
      </div>

      <div className="neo-form-group">
        <label>Статус</label>
        <select
          className="neo-select"
          value={form.is_active ? "1" : "0"}
          onChange={(e) => updateField("is_active", e.target.value === "1")}
        >
          <option value="1">Активна</option>
          <option value="0">Не активна</option>
        </select>
      </div>

      <button className="neo-btn neo-btn-primary w-full mt-4" onClick={handleSave}>
        {service ? "Сохранить" : "Создать услугу"}
      </button>
    </div>
  );
};

export default ServiceForm;
