// src/business-panel/forms/BranchForm.jsx

import React, { useState, useEffect } from "react";
import { createBranch, updateBranch } from "../../api/businesses";

const BranchForm = ({ branch, onSaved }) => {
  const [form, setForm] = useState({
    name: "",
    address: "",
    phone: "",
    is_active: true,
  });

  useEffect(() => {
    if (branch) {
      setForm({
        name: branch.name || "",
        address: branch.address || "",
        phone: branch.phone || "",
        is_active: branch.is_active ?? true,
      });
    }
  }, [branch]);

  const updateField = (field, value) => {
    setForm((p) => ({ ...p, [field]: value }));
  };

  const handleSave = async () => {
    if (!form.name.trim()) return alert("Введите название филиала");

    let res;
    if (branch) {
      res = await updateBranch(branch.id, form);
    } else {
      res = await createBranch(form);
    }

    if (onSaved) onSaved(res);
  };

  return (
    <div className="neo-form">
      <div className="neo-form-group">
        <label>Название филиала</label>
        <input
          className="neo-input"
          value={form.name}
          onChange={(e) => updateField("name", e.target.value)}
          placeholder="УФорест / Академгородок"
        />
      </div>

      <div className="neo-form-group">
        <label>Адрес</label>
        <input
          className="neo-input"
          value={form.address}
          onChange={(e) => updateField("address", e.target.value)}
          placeholder="г. Новосибирск, ул. ..."
        />
      </div>

      <div className="neo-form-group">
        <label>Телефон</label>
        <input
          className="neo-input"
          value={form.phone}
          onChange={(e) => updateField("phone", e.target.value)}
          placeholder="+7 ..."
        />
      </div>

      <div className="neo-form-group">
        <label>Статус</label>
        <select
          className="neo-select"
          value={form.is_active ? "1" : "0"}
          onChange={(e) => updateField("is_active", e.target.value === "1")}
        >
          <option value="1">Активен</option>
          <option value="0">Не активен</option>
        </select>
      </div>

      <button className="neo-btn neo-btn-primary w-full mt-4" onClick={handleSave}>
        {branch ? "Сохранить изменения" : "Создать филиал"}
      </button>
    </div>
  );
};

export default BranchForm;
