// src/business-panel/forms/EmployeeForm.jsx

import React, { useState, useEffect } from "react";
import { createEmployee, updateEmployee } from "../../api/employees";

const EmployeeForm = ({ employee, onSaved }) => {
  const [form, setForm] = useState({
    name: "",
    role: "",
    phone: "",
    email: "",
    photo_url: "",
    is_active: true,
  });

  useEffect(() => {
    if (employee) {
      setForm({
        name: employee.name || "",
        role: employee.role || "",
        phone: employee.phone || "",
        email: employee.email || "",
        photo_url: employee.photo_url || "",
        is_active: employee.is_active ?? true,
      });
    }
  }, [employee]);

  const updateField = (field, value) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleSave = async () => {
    if (!form.name.trim()) {
      alert("Введите имя сотрудника");
      return;
    }

    let res;
    if (employee) {
      res = await updateEmployee(employee.id, form);
    } else {
      res = await createEmployee(form);
    }

    if (onSaved) onSaved(res);
  };

  return (
    <div className="neo-form">

      {/* Имя */}
      <div className="neo-form-group">
        <label>Имя сотрудника</label>
        <input
          className="neo-input"
          value={form.name}
          onChange={(e) => updateField("name", e.target.value)}
          placeholder="Введите имя"
        />
      </div>

      {/* Роль */}
      <div className="neo-form-group">
        <label>Должность</label>
        <input
          className="neo-input"
          value={form.role}
          onChange={(e) => updateField("role", e.target.value)}
          placeholder="Учитель / администратор"
        />
      </div>

      {/* Телефон */}
      <div className="neo-form-group">
        <label>Телефон</label>
        <input
          className="neo-input"
          value={form.phone}
          onChange={(e) => updateField("phone", e.target.value)}
          placeholder="+7 ..."
        />
      </div>

      {/* Email */}
      <div className="neo-form-group">
        <label>Email</label>
        <input
          className="neo-input"
          value={form.email}
          onChange={(e) => updateField("email", e.target.value)}
          placeholder="example@mail.ru"
        />
      </div>

      {/* Фото */}
      <div className="neo-form-group">
        <label>Фото (URL)</label>
        <input
          className="neo-input"
          value={form.photo_url}
          onChange={(e) => updateField("photo_url", e.target.value)}
          placeholder="https://example.com/photo.jpg"
        />
      </div>

      {/* Статус */}
      <div className="neo-form-group">
        <label>Статус</label>
        <select
          className="neo-select"
          value={form.is_active ? "1" : "0"}
          onChange={(e) => updateField("is_active", e.target.value === "1")}
        >
          <option value="1">Активен</option>
          <option value="0">Не активен</option>
        </select>
      </div>

      {/* Кнопка */}
      <button className="neo-btn neo-btn-primary w-full mt-4" onClick={handleSave}>
        {employee ? "Сохранить изменения" : "Добавить сотрудника"}
      </button>
    </div>
  );
};

export default EmployeeForm;
