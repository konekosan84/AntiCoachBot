import React, { useState, useEffect } from "react";
import NeoModal from "../../ui/components/NeoModal";
import NeoInput from "../../ui/components/NeoInput";
import { createRoom, updateRoom } from "../../api/rooms";

export default function RoomModal({ room, onClose }) {
  const isEdit = Boolean(room);

  const [form, setForm] = useState({
    name: "",
    capacity: "",
    branch_id: "",
  });

  const [loading, setLoading] = useState(false);

  // При редактировании — подставляем данные
  useEffect(() => {
    if (room) {
      setForm({
        name: room.name || "",
        capacity: room.capacity || "",
        branch_id: room.branch_id || "",
      });
    }
  }, [room]);

  const updateField = (key, value) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  async function handleSave() {
    setLoading(true);
    try {
      if (isEdit) {
        await updateRoom(room.id, form);
      } else {
        await createRoom(form);
      }
      onClose();
    } catch (err) {
      console.error("Ошибка сохранения помещения:", err);
    } finally {
      setLoading(false);
    }
  }

  return (
    <NeoModal
      title={isEdit ? "Редактировать помещение" : "Добавить помещение"}
      onClose={onClose}
      onSave={handleSave}
      loading={loading}
    >
      <div className="space-y-4">

        <NeoInput
          label="Название"
          value={form.name}
          onChange={(v) => updateField("name", v)}
          placeholder="Например: Кабинет 1"
        />

        <NeoInput
          label="Вместимость"
          value={form.capacity}
          onChange={(v) => updateField("capacity", v)}
          placeholder="Например: 12"
        />

        <NeoInput
          label="ID филиала"
          value={form.branch_id}
          onChange={(v) => updateField("branch_id", v)}
          placeholder="Например: 3"
        />

      </div>
    </NeoModal>
  );
}
