import React, { useState, useEffect } from "react";
import NeoModal from "../../ui/components/NeoModal";
import { createBranch, updateBranch, deleteBranch } from "../../api/branches";

export default function BranchModal({ open, onClose, branch, onSaved }) {
  const [form, setForm] = useState({ name: "", address: "", phone: "" });

  useEffect(() => {
    if (branch) setForm(branch);
  }, [branch]);

  const save = async () => {
    if (branch) await updateBranch(branch.id, form);
    else await createBranch(form);
    onSaved();
    onClose();
  };

  const remove = async () => {
    await deleteBranch(branch.id);
    onSaved();
    onClose();
  };

  return (
    <NeoModal
      isOpen={open}
      onClose={onClose}
      title={branch ? "Редактировать филиал" : "Создать филиал"}
    >
      <input
        className="neo-input"
        placeholder="Название"
        value={form.name}
        onChange={(e) => setForm({ ...form, name: e.target.value })}
      />
      <input
        className="neo-input"
        placeholder="Адрес"
        value={form.address}
        onChange={(e) => setForm({ ...form, address: e.target.value })}
      />
      <input
        className="neo-input"
        placeholder="Телефон"
        value={form.phone}
        onChange={(e) => setForm({ ...form, phone: e.target.value })}
      />

      <button className="neo-btn-primary" onClick={save}>
        Сохранить
      </button>

      {branch && (
        <button className="neo-btn-danger" onClick={remove}>
          Удалить
        </button>
      )}
    </NeoModal>
  );
}
