import React, { useState, useEffect } from "react";
import NeoModal from "../../ui/components/NeoModal";
import {
  createService,
  updateService,
  deleteService,
} from "../../api/services";

export default function ServiceModal({ open, onClose, service, onSaved }) {
  const [form, setForm] = useState({
    name: "",
    price: "",
    duration: "",
    description: "",
  });

  useEffect(() => {
    if (service) setForm(service);
  }, [service]);

  const save = async () => {
    if (service) await updateService(service.id, form);
    else await createService(form);
    onSaved();
    onClose();
  };

  const remove = async () => {
    await deleteService(service.id);
    onSaved();
    onClose();
  };

  return (
    <NeoModal isOpen={open} onClose={onClose} title="Услуга">
      <input
        className="neo-input"
        placeholder="Название"
        value={form.name}
        onChange={(e) => setForm({ ...form, name: e.target.value })}
      />

      <input
        className="neo-input"
        placeholder="Цена"
        value={form.price}
        onChange={(e) => setForm({ ...form, price: e.target.value })}
      />

      <input
        className="neo-input"
        placeholder="Длительность (мин)"
        value={form.duration}
        onChange={(e) => setForm({ ...form, duration: e.target.value })}
      />

      <textarea
        className="neo-input"
        placeholder="Описание"
        value={form.description}
        onChange={(e) => setForm({ ...form, description: e.target.value })}
      />

      <button className="neo-btn-primary" onClick={save}>
        Сохранить
      </button>

      {service && (
        <button className="neo-btn-danger" onClick={remove}>
          Удалить
        </button>
      )}
    </NeoModal>
  );
}
