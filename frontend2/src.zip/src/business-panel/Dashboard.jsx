import { useEffect, useMemo, useState } from "react";
import { getDirectorDashboard } from "../api/dashboard";
import { getBranches } from "../api/branches";

function formatPhone(phone) {
  const digits = String(phone || "").replace(/\D/g, "");
  if (!digits) return "—";

  const core =
    digits.length === 11 && digits.startsWith("7")
      ? digits.slice(1)
      : digits.slice(-10);

  const p1 = core.slice(0, 3);
  const p2 = core.slice(3, 6);
  const p3 = core.slice(6, 8);
  const p4 = core.slice(8, 10);

  return `+7 (${p1}) ${p2}-${p3}-${p4}`;
}

function formatDateTime(value) {
  if (!value) return "—";
  try {
    return new Date(value).toLocaleString("ru-RU");
  } catch {
    return String(value);
  }
}

function todayYmd() {
  const d = new Date();
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

function daysAgoYmd(days) {
  const d = new Date();
  d.setDate(d.getDate() - days);
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

function extractBranchId(branch) {
  return branch?.id ?? branch?.branch_id ?? branch?.value ?? "";
}

function extractBranchName(branch) {
  return (
    branch?.name ??
    branch?.title ??
    branch?.branch_name ??
    branch?.label ??
    `Филиал ${extractBranchId(branch)}`
  );
}

export default function Dashboard() {
  const [branches, setBranches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dashboard, setDashboard] = useState(null);

  const [from, setFrom] = useState(daysAgoYmd(30));
  const [to, setTo] = useState(todayYmd());
  const [branchId, setBranchId] = useState("");

  useEffect(() => {
    loadBranches();
    loadDashboard();
  }, []);

  async function loadBranches() {
    try {
      const data = await getBranches();
      setBranches(Array.isArray(data) ? data : []);
    } catch (e) {
      console.error("Ошибка загрузки филиалов:", e);
      setBranches([]);
    }
  }

  async function loadDashboard(params = {}) {
    try {
      setLoading(true);
      const data = await getDirectorDashboard({
        from: params.from ?? from,
        to: params.to ?? to,
        branch_id: params.branch_id ?? branchId,
      });
      setDashboard(data);
    } catch (e) {
      console.error("Ошибка загрузки дашборда:", e);
      setDashboard(null);
    } finally {
      setLoading(false);
    }
  }

  async function handleSubmit(e) {
    e.preventDefault();
    await loadDashboard({ from, to, branch_id: branchId });
  }

  const branchOptions = useMemo(() => {
    const items = branches
      .map((b) => ({
        value: String(extractBranchId(b)),
        label: extractBranchName(b),
      }))
      .filter((x) => x.value);

    return [{ value: "", label: "Все филиалы" }, ...items];
  }, [branches]);

  const kpi = dashboard?.kpi || {};
  const branchBookings = dashboard?.branch_bookings || [];
  const branchClients = dashboard?.branch_clients || [];
  const sources = dashboard?.sources || [];
  const recentClients = dashboard?.recent_clients || [];
  const recentBookings = dashboard?.recent_bookings || [];

  return (
    <div className="page visionos-container">
      <div className="visionos-card" style={{ padding: 16, marginBottom: 18 }}>
        <form
          onSubmit={handleSubmit}
          style={{
            display: "grid",
            gridTemplateColumns: "180px 180px 240px auto",
            gap: 10,
          }}
        >
          <input
            type="date"
            className="neo-input"
            value={from}
            onChange={(e) => setFrom(e.target.value)}
          />
          <input
            type="date"
            className="neo-input"
            value={to}
            onChange={(e) => setTo(e.target.value)}
          />
          <select
            className="neo-input"
            value={branchId}
            onChange={(e) => setBranchId(e.target.value)}
          >
            {branchOptions.map((item) => (
              <option key={item.value || "all"} value={item.value}>
                {item.label}
              </option>
            ))}
          </select>
          <button className="neo-btn" type="submit">
            Обновить
          </button>
        </form>
      </div>

      {loading ? (
        <div style={{ opacity: 0.75 }}>Загрузка...</div>
      ) : !dashboard ? (
        <div style={{ opacity: 0.75 }}>Нет данных для дашборда</div>
      ) : (
        <>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
              gap: 14,
              marginBottom: 18,
            }}
          >
            <KpiCard title="Всего клиентов" value={kpi.total_clients || 0} />
            <KpiCard title="Новых клиентов" value={kpi.new_clients || 0} />
            <KpiCard title="Активных клиентов" value={kpi.active_clients || 0} />
            <KpiCard title="Всего записей" value={kpi.total_bookings || 0} />
            <KpiCard title="Записей сегодня" value={kpi.today_bookings || 0} />
            <KpiCard title="Повторных клиентов" value={kpi.repeat_clients || 0} />
          </div>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "1fr 1fr",
              gap: 16,
              marginBottom: 18,
            }}
          >
            <SimpleListCard
              title="Записи по филиалам"
              items={branchBookings.map((x) => ({
                label: x.branch_name,
                value: x.bookings_count,
              }))}
            />
            <SimpleListCard
              title="Новые клиенты по филиалам"
              items={branchClients.map((x) => ({
                label: x.branch_name,
                value: x.clients_count,
              }))}
            />
          </div>

          <div style={{ marginBottom: 18 }}>
            <SimpleListCard
              title="Источники клиентов"
              items={sources.map((x) => ({
                label: x.source,
                value: x.clients_count,
              }))}
            />
          </div>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "1fr 1fr",
              gap: 16,
            }}
          >
            <div className="visionos-card" style={{ padding: 16 }}>
              <h3 style={{ marginTop: 0 }}>Последние клиенты</h3>
              {recentClients.length === 0 ? (
                <div style={{ opacity: 0.7 }}>Нет данных</div>
              ) : (
                <div style={{ display: "grid", gap: 10 }}>
                  {recentClients.map((client) => (
                    <div
                      key={client.id}
                      style={{
                        padding: 12,
                        borderRadius: 14,
                        background: "rgba(255,255,255,0.04)",
                        border: "1px solid rgba(255,255,255,0.06)",
                      }}
                    >
                      <div style={{ fontWeight: 700 }}>{client.full_name}</div>
                      <div style={{ opacity: 0.8, marginTop: 4 }}>
                        {formatPhone(client.phone)}
                      </div>
                      <div style={{ opacity: 0.68, fontSize: 14, marginTop: 4 }}>
                        {client.branch_name} • {client.source || "unknown"}
                      </div>
                      <div style={{ opacity: 0.6, fontSize: 13, marginTop: 4 }}>
                        {formatDateTime(client.created_at)}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="visionos-card" style={{ padding: 16 }}>
              <h3 style={{ marginTop: 0 }}>Последние записи</h3>
              {recentBookings.length === 0 ? (
                <div style={{ opacity: 0.7 }}>Нет данных</div>
              ) : (
                <div style={{ display: "grid", gap: 10 }}>
                  {recentBookings.map((booking) => (
                    <div
                      key={booking.id}
                      style={{
                        padding: 12,
                        borderRadius: 14,
                        background: "rgba(255,255,255,0.04)",
                        border: "1px solid rgba(255,255,255,0.06)",
                      }}
                    >
                      <div style={{ fontWeight: 700 }}>
                        {booking.client_name || "Без клиента"}
                      </div>
                      <div style={{ opacity: 0.8, marginTop: 4 }}>
                        {booking.date} {booking.start_time ? `• ${booking.start_time}` : ""}
                      </div>
                      <div style={{ opacity: 0.68, fontSize: 14, marginTop: 4 }}>
                        {booking.branch_name} • {booking.status || "booked"}
                      </div>
                      <div style={{ opacity: 0.6, fontSize: 13, marginTop: 4 }}>
                        Цена: {booking.price ?? 0}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function KpiCard({ title, value }) {
  return (
    <div className="visionos-card" style={{ padding: 18 }}>
      <div style={{ fontSize: 14, opacity: 0.72, marginBottom: 10 }}>{title}</div>
      <div style={{ fontSize: 34, fontWeight: 800 }}>{value}</div>
    </div>
  );
}

function SimpleListCard({ title, items }) {
  return (
    <div className="visionos-card" style={{ padding: 16 }}>
      <h3 style={{ marginTop: 0 }}>{title}</h3>
      {items.length === 0 ? (
        <div style={{ opacity: 0.7 }}>Нет данных</div>
      ) : (
        <div style={{ display: "grid", gap: 10 }}>
          {items.map((item, index) => (
            <div
              key={`${item.label}-${index}`}
              style={{
                display: "flex",
                justifyContent: "space-between",
                gap: 10,
                padding: 10,
                borderRadius: 12,
                background: "rgba(255,255,255,0.04)",
                border: "1px solid rgba(255,255,255,0.05)",
              }}
            >
              <span>{item.label}</span>
              <b>{item.value}</b>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}