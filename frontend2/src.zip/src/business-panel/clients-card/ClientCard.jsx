import React, { useEffect, useState } from "react";
import api from "../../api/api";
import ClientHeader from "./ClientHeader";
import ClientTabs from "./ClientTabs";
import ClientHistory from "./ClientHistory";
import ClientStats from "./ClientStats";
import ClientComments from "./ClientComments";
import ClientTags from "./ClientTags";

export default function ClientCard({ clientId }) {
  const [client, setClient] = useState(null);
  const [tab, setTab] = useState("history");

  async function load() {
    const data = await api.get(`/clients/${clientId}`);
    setClient(data);
  }

  useEffect(() => {
    load();
  }, [clientId]);

  if (!client) return <div className="p-4">Загрузка...</div>;

  return (
    <div className="p-6 space-y-6">
      <ClientHeader client={client} />
      <ClientTags client={client} refresh={load} />

      <ClientTabs tab={tab} setTab={setTab} />

      {tab === "history" && <ClientHistory clientId={clientId} />}
      {tab === "stats" && <ClientStats clientId={clientId} />}
      {tab === "comments" && <ClientComments clientId={clientId} />}
    </div>
  );
}
