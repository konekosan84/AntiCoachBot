import React from "react";

export default function ClientHeader({ client }) {
  return (
    <div className="bg-white rounded-xl shadow p-6 flex items-center space-x-6">
      <div className="w-20 h-20 rounded-full bg-indigo-200 flex items-center justify-center text-3xl font-bold">
        {client.name[0]}
      </div>

      <div>
        <h2 className="text-2xl font-bold">{client.name}</h2>
        <p className="text-gray-600">{client.phone}</p>
        <p className="text-gray-600">{client.email}</p>
      </div>
    </div>
  );
}
