import React, { useState } from "react";
import api from "../../api/api";

const TAGS = ["VIP", "Проблемный", "Новый", "Холодный", "Активный"];

export default function ClientTags({ client, refresh }) {
  const [selected, setSelected] = useState(client.tags || []);

  async function toggle(tag) {
    let res = [...selected];

    if (res.includes(tag)) {
      res = res.filter((t) => t !== tag);
    } else {
      res.push(tag);
    }

    setSelected(res);

    await api.put(`/clients/${client.id}/tags`, { tags: res });

    refresh();
  }

  return (
    <div className="bg-white shadow rounded-xl p-4 flex space-x-3">
      {TAGS.map((t) => (
        <button
          key={t}
          onClick={() => toggle(t)}
          className={`px-3 py-1 rounded border ${
            selected.includes(t)
              ? "bg-indigo-600 text-white"
              : "bg-gray-100 text-gray-600"
          }`}
        >
          {t}
        </button>
      ))}
    </div>
  );
}
