export default function ClientTabs({ tab, setTab }) {
  const tabs = [
    { id: "history", label: "История" },
    { id: "stats", label: "Статистика" },
    { id: "comments", label: "Комментарии" },
  ];

  return (
    <div className="flex space-x-4 border-b pb-1">
      {tabs.map((t) => (
        <button
          key={t.id}
          onClick={() => setTab(t.id)}
          className={`pb-2 ${
            tab === t.id ? "text-indigo-600 border-b-2 border-indigo-600" : "text-gray-500"
          }`}
        >
          {t.label}
        </button>
      ))}
    </div>
  );
}
