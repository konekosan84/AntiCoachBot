import React, { useEffect, useState } from "react";
import api from "../../api/api";

export default function ClientStats({ clientId }) {
  const [stats, setStats] = useState(null);

  async function load() {
    const data = await api.get(`/clients/${clientId}/stats`);
    setStats(data);
  }

  useEffect(() => {
    load();
  }, [clientId]);

  if (!stats) return <div>Загрузка...</div>;

  return (
    <div className="bg-white p-6 rounded-xl shadow space-y-4">
      <h3 className="text-xl font-bold">Статистика клиента</h3>

      <div className="grid grid-cols-2 gap-4">
        <div className="p-4 bg-gray-50 rounded shadow">
          <div className="text-gray-500">Посещений</div>
          <div className="text-2xl font-bold">{stats.visits}</div>
        </div>

        <div className="p-4 bg-gray-50 rounded shadow">
          <div className="text-gray-500">Выручка</div>
          <div className="text-2xl font-bold">{stats.revenue} ₽</div>
        </div>

        <div className="p-4 bg-gray-50 rounded shadow">
          <div className="text-gray-500">Средний чек</div>
          <div className="text-2xl font-bold">{stats.avg_check} ₽</div>
        </div>

        <div className="p-4 bg-gray-50 rounded shadow">
          <div className="text-gray-500">Любимая услуга</div>
          <div className="text-xl">{stats.favorite_service || "—"}</div>
        </div>
      </div>
    </div>
  );
}
