import React, { useEffect, useState } from "react";
import api from "../../api/api";

export default function ClientHistory({ clientId }) {
  const [rows, setRows] = useState([]);

  async function load() {
    const data = await api.get(`/clients/${clientId}/history`);
    setRows(data);
  }

  useEffect(() => {
    load();
  }, [clientId]);

  return (
    <div className="bg-white p-6 rounded-xl shadow">
      <h3 className="text-xl font-bold mb-4">История посещений</h3>

      <table className="w-full">
        <thead>
          <tr className="bg-gray-100">
            <th className="p-2">Дата</th>
            <th className="p-2">Услуга</th>
            <th className="p-2">Мастер</th>
            <th className="p-2">Филиал</th>
            <th className="p-2">Цена</th>
            <th className="p-2">Статус</th>
          </tr>
        </thead>

        <tbody>
          {rows.map((row) => (
            <tr key={row.id} className="border-t">
              <td className="p-2">{row.date}</td>
              <td className="p-2">{row.service_name}</td>
              <td className="p-2">{row.employee_name}</td>
              <td className="p-2">{row.branch_name}</td>
              <td className="p-2">{row.price} ₽</td>
              <td className="p-2">{row.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
