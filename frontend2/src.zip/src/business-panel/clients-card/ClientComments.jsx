import React, { useEffect, useState } from "react";
import api from "../../api/api";

export default function ClientComments({ clientId }) {
  const [comments, setComments] = useState([]);
  const [text, setText] = useState("");

  async function load() {
    const rows = await api.get(`/clients/${clientId}/comments`);
    setComments(rows);
  }

  useEffect(() => {
    load();
  }, [clientId]);

  async function send() {
    if (!text.trim()) return;

    await api.post(`/clients/${clientId}/comments`, { comment: text });
    setText("");
    load();
  }

  return (
    <div className="bg-white rounded-xl shadow p-6">
      <h3 className="text-xl font-bold mb-4">Комментарии менеджеров</h3>

      <div className="space-y-4 mb-4">
        {comments.map((c) => (
          <div key={c.id} className="p-3 bg-gray-50 rounded shadow">
            <div className="text-sm text-gray-500">{c.author}</div>
            <div>{c.comment}</div>
            <div className="text-xs text-gray-400">{c.created_at}</div>
          </div>
        ))}
      </div>

      <textarea
        className="w-full p-3 border rounded mb-3"
        placeholder="Оставить комментарий…"
        value={text}
        onChange={(e) => setText(e.target.value)}
      />

      <button
        onClick={send}
        className="px-4 py-2 bg-indigo-600 text-white rounded"
      >
        Добавить комментарий
      </button>
    </div>
  );
}
