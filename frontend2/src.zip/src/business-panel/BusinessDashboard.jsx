import React, { useEffect, useState } from "react";

/*
  ВНИМАНИЕ:
  Эта версия отключает проблемные запросы к analytics API,
  чтобы админка полностью работала (Branches, Employees, Rooms и т.д.).
*/

export default function BusinessDashboard() {
  // Наполняем моки (временные данные, чтобы UI не был пустой)
  const [overview, setOverview] = useState(null);

  useEffect(() => {
    // Здесь мы НЕ вызываем analytics API, потому что его нет на backend.
    // Просто заполняем безопасные данные.
    setOverview({
      total_clients: 0,
      today_bookings: 0,
      today_revenue: 0,
      new_clients: 0,
    });
  }, []);

  if (!overview)
    return <p className="text-slate-300">Загрузка...</p>;

  return (
    <div className="space-y-10">

      <header>
        <h1 className="text-3xl font-bold text-slate-50 drop-shadow">
          Главная панель
        </h1>
        <p className="text-slate-400 mt-1 text-sm">
          Здесь появится аналитика, когда мы её включим.
        </p>
      </header>

      {/* ======= СТАТИСТИКА ======= */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">

        <StatCard
          title="Всего клиентов"
          value={overview.total_clients}
          color="from-cyan-400 to-blue-500"
        />

        <StatCard
          title="Записей сегодня"
          value={overview.today_bookings}
          color="from-emerald-400 to-teal-500"
        />

        <StatCard
          title="Выручка сегодня"
          value={`${overview.today_revenue} ₽`}
          color="from-violet-400 to-fuchsia-500"
        />

        <StatCard
          title="Новые клиенты"
          value={overview.new_clients}
          color="from-amber-400 to-orange-500"
        />
      </div>

      {/* ВРЕМЕННО БЕЗ ГРАФИКОВ */}
      <p className="text-slate-400 text-sm">
        Графики будут подключены позже, когда реализуем API аналитики.
      </p>
    </div>
  );
}

/* ===== ВСПОМОГАТЕЛЬНЫЕ КОМПОНЕНТЫ ===== */

function StatCard({ title, value, color }) {
  return (
    <div className="p-5 rounded-2xl bg-slate-900/70 border border-slate-700/60 shadow-lg">
      <div className="text-xs text-slate-400 tracking-wide mb-1">
        {title}
      </div>

      <div
        className={`
          text-3xl font-bold bg-gradient-to-r ${color}
          bg-clip-text text-transparent drop-shadow
        `}
      >
        {value}
      </div>
    </div>
  );
}
