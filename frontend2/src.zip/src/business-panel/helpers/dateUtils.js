/* ============================================================
   DATE UTILITIES
============================================================ */

/** Format JS Date → "YYYY-MM-DD" */
export function formatDate(d) {
  return d.toISOString().substring(0, 10);
}

/** Convert "2025-11-17" → Date */
export function toDate(dateStr) {
  return new Date(dateStr + "T00:00:00");
}

/** Add N days to date string */
export function addDays(dateStr, days) {
  const d = toDate(dateStr);
  d.setDate(d.getDate() + days);
  return formatDate(d);
}

/* ============================================================
   WEEK DAYS GENERATOR
============================================================ */
export function getWeekDays() {
  const today = new Date();

  // Monday as start
  const monday = new Date(today);
  const wd = monday.getDay();
  const diff = (wd === 0 ? -6 : 1) - wd;
  monday.setDate(monday.getDate() + diff);

  const week = [];

  const names = ["Понедельник","Вторник","Среда","Четверг","Пятница","Суббота","Воскресенье"];
  const short = ["ПН","ВТ","СР","ЧТ","ПТ","СБ","ВС"];

  for (let i = 0; i < 7; i++) {
    const d = new Date(monday);
    d.setDate(monday.getDate() + i);

    const iso = formatDate(d);

    week.push({
      iso,             // 2025-11-18
      date: iso,
      name: names[i],
      short: short[i],
      day: iso.substring(8,10)
    });
  }

  return week;
}

/* ============================================================
   MONTH MATRIX (6 rows × 7 cols)
============================================================ */
export function getMonthMatrix() {
  const now = new Date();
  const Y = now.getFullYear();
  const M = now.getMonth();

  const first = new Date(Y, M, 1);
  const firstWeekDay = (first.getDay() + 6) % 7; // Monday=0

  const daysInMonth = new Date(Y, M + 1, 0).getDate();

  let current = 1 - firstWeekDay;
  const matrix = [];

  for (let i = 0; i < 6; i++) {
    const row = [];

    for (let j = 0; j < 7; j++) {
      const d = new Date(Y, M, current);
      const iso = formatDate(d);

      row.push({
        date: iso,
        inCurrentMonth: d.getMonth() === M
      });

      current++;
    }
    matrix.push(row);
  }

  return matrix;
}

/* ============================================================
   SHIFTS FILTER
============================================================ */
export function shiftsByDate(shifts, date) {
  return (shifts || []).filter(s => s.start_time.startsWith(date));
}
