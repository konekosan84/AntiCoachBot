import dayjs from "dayjs";

/**
 * Цвет смены помещения
 */
export function getRoomShiftColor(sh) {
  // ночная смена
  if (sh.time_to < sh.time_from) return "bg-purple-200 border-purple-500";

  // длинная смена (больше 10 часов)
  const dur = diffHours(sh.time_from, sh.time_to);
  if (dur >= 10) return "bg-indigo-200 border-indigo-500";

  return "bg-teal-200 border-teal-500"; // обычная смена
}

/**
 * Цвет смены сотрудника в помещении
 */
export function getEmployeeShiftColor(sh, roomRanges) {
  const s = sh.time_from;
  const e = sh.time_to;

  // Проверка попадания в диапазоны комнаты
  const insideAny = roomRanges.some((r) => {
    if (e < s) return false; // ночная — за пределами комнаты
    return s >= r.start && e <= r.end;
  });

  // вне режима помещения
  if (!insideAny) return "bg-red-200 border-red-500";

  // ночная смена
  if (e < s) return "bg-purple-200 border-purple-500";

  const dur = diffHours(s, e);

  // длинная смена
  if (dur >= 8) return "bg-indigo-200 border-indigo-500";

  return "bg-blue-200 border-blue-500";
}

/**
 * Разница между временем в часах
 */
export function diffHours(from, to) {
  const start = dayjs(from, "HH:mm");
  const end = dayjs(to, "HH:mm");
  return end.diff(start, "hour", true);
}
