import { useEffect, useState } from "react";
import api from "../../api/api";

export function useBusinessData() {
  const [data, setData] = useState({
    branches: [],
    rooms: [],
    employees: [],
    services: [],
    shifts: []
  });

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  // ============================
  // 🔥 LOAD ALL BUSINESS DATA
  // ============================
  async function loadAll() {
    try {
      setLoading(true);

      const [
        branchesRes,
        roomsRes,
        employeesRes,
        servicesRes,
        shiftsRes
      ] = await Promise.all([
        api.get("/branches"),
        api.get("/rooms"),
        api.get("/employees"),
        api.get("/services"),
        api.get("/schedule") // LOAD SHIFTS
      ]);

      setData({
        branches: branchesRes.data,
        rooms: roomsRes.data,
        employees: employeesRes.data,
        services: servicesRes.data,
        shifts: shiftsRes.data
      });

      setError(false);
    } catch (e) {
      console.error("Ошибка загрузки бизнеса:", e);
      setError(true);
    } finally {
      setLoading(false);
    }
  }

  // ============================
  // 🔥 SHIFT API
  // ============================
  async function fetchShifts() {
    try {
      const res = await api.get("/schedule");
      setData((prev) => ({ ...prev, shifts: res.data }));
    } catch (e) {
      console.error("Ошибка загрузки смен:", e);
    }
  }

  async function createShift(payload) {
    const res = await api.post("/schedule", payload);
    await fetchShifts();
    return res.data;
  }

  async function updateShift(id, payload) {
    const res = await api.put(`/schedule/${id}`, payload);
    await fetchShifts();
    return res.data;
  }

  async function deleteShift(id) {
    await api.delete(`/schedule/${id}`);
    await fetchShifts();
  }

  // ============================
  // 🔥 INIT
  // ============================
  useEffect(() => {
    loadAll();
  }, []);

  return {
    ...data,
    loading,
    error,
    refreshAll: loadAll,
    fetchShifts,
    createShift,
    updateShift,
    deleteShift
  };
}

