import { useEffect, useMemo, useState } from 'react';
import { getBookingsDetails } from '../api/analytics';

function formatMoney(value) {
  return `${Number(value || 0).toLocaleString('ru-RU')} ₽`;
}

function formatDateLong(value) {
  if (!value) return '—';
  const d = new Date(`${value}T00:00:00`);
  return d.toLocaleDateString('ru-RU', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });
}

function getStatusModeLabel(statusMode) {
  if (statusMode === 'completed') return 'Завершенные записи';
  if (statusMode === 'cancelled') return 'Отмененные записи';
  return 'Все записи';
}

function getMetricLabel(metricKey) {
  if (metricKey === 'revenue') return 'Выручка';
  if (metricKey === 'total') return 'Все записи';
  if (metricKey === 'completed') return 'Завершено';
  if (metricKey === 'cancelled') return 'Отменено';
  if (metricKey === 'lostRevenue') return 'Потеряно выручки';
  return 'Детализация';
}

function GroupButton({ active, children, onClick }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-xl px-3 py-2 text-xs font-semibold transition ${
        active
          ? 'bg-gradient-to-r from-cyan-400 to-violet-500 text-white'
          : 'border border-white/10 bg-white/[0.04] text-white/70 hover:bg-white/[0.08]'
      }`}
    >
      {children}
    </button>
  );
}

function getStatusBadge(status) {
  const value = String(status || '').toLowerCase();

  if (['completed', 'done', 'finished', 'confirmed'].includes(value)) {
    return 'border-emerald-400/30 bg-emerald-500/15 text-emerald-200';
  }

  if (['cancelled', 'canceled', 'no_show'].includes(value)) {
    return 'border-red-400/30 bg-red-500/15 text-red-200';
  }

  if (['booked', 'new', 'pending'].includes(value)) {
    return 'border-cyan-400/30 bg-cyan-500/15 text-cyan-200';
  }

  return 'border-white/10 bg-white/[0.06] text-white/70';
}

function exportRowsToCsv(rows, mode, groupBy) {
  if (!rows?.length) return;

  let headers = [];
  let data = [];

  if (mode === 'group') {
    headers = ['Группа', 'Записей', 'Сумма'];
    data = rows.map((row) => [
      row.label ?? '',
      row.total_bookings ?? 0,
      row.total_amount ?? 0,
    ]);
  } else {
    headers = [
      'ID',
      'Дата',
      'Время начала',
      'Время конца',
      'Статус',
      'Клиент',
      'Филиал',
      'Сотрудник',
      'Услуга',
      'Сумма',
    ];
    data = rows.map((row) => [
      row.booking_id ?? row.id ?? '',
      row.date ?? '',
      row.start_time ?? '',
      row.end_time ?? '',
      row.status ?? '',
      row.client_name ?? '',
      row.branch_name ?? '',
      row.employee_name ?? '',
      row.service_name ?? '',
      row.price ?? 0,
    ]);
  }

  const escapeCell = (value) => {
    const s = String(value ?? '');
    return `"${s.replace(/"/g, '""')}"`;
  };

  const csv = [headers, ...data].map((row) => row.map(escapeCell).join(';')).join('\n');
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);

  const a = document.createElement('a');
  a.href = url;
  a.download = `analytics_${mode}_${groupBy}_${Date.now()}.csv`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function StatBox({ label, value }) {
  return (
    <div className="rounded-2xl bg-white/[0.04] p-3">
      <div className="text-[11px] uppercase tracking-wide text-white/35">{label}</div>
      <div className="mt-1 text-lg font-bold text-white">{value}</div>
    </div>
  );
}

export default function AnalyticsDetailPanel({
  open,
  onClose,
  queryParams,
  metricKey,
  onOpenBooking,
}) {
  const [groupBy, setGroupBy] = useState('none');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [data, setData] = useState({ mode: 'list', rows: [] });
  const [selectedBookingId, setSelectedBookingId] = useState(null);

  const statusMode = useMemo(() => {
    if (metricKey === 'completed' || metricKey === 'revenue') return 'completed';
    if (metricKey === 'cancelled' || metricKey === 'lostRevenue') return 'cancelled';
    return 'all';
  }, [metricKey]);

  const totalAmount = useMemo(() => {
    return (data?.rows || []).reduce((sum, row) => {
      if (data?.mode === 'group') return sum + Number(row.total_amount || 0);
      return sum + Number(row.price || 0);
    }, 0);
  }, [data]);

  const totalRows = useMemo(() => (data?.rows || []).length, [data]);

  useEffect(() => {
    if (!open) return;
    loadDetails();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, groupBy, metricKey, JSON.stringify(queryParams)]);

  async function loadDetails() {
    setLoading(true);
    setError('');
    setSelectedBookingId(null);

    try {
      const result = await getBookingsDetails({
        ...queryParams,
        status_mode: statusMode,
        group_by: groupBy,
      });
      setData(result || { mode: 'list', rows: [] });
    } catch (err) {
      console.error('analytics detail error', err);
      setError(err?.message || 'Ошибка загрузки детализации');
      setData({ mode: 'list', rows: [] });
    } finally {
      setLoading(false);
    }
  }

  if (!open) return null;

  return (
    <>
      <div
        className="fixed inset-0 z-40 bg-black/45 backdrop-blur-[2px]"
        onClick={onClose}
      />
      <div className="fixed right-0 top-0 z-50 h-screen w-full max-w-[720px] border-l border-white/10 bg-[#0b1325] shadow-[-20px_0_60px_rgba(0,0,0,0.45)]">
        <div className="flex h-full flex-col">
          <div className="border-b border-white/10 px-5 py-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="text-[20px] font-bold text-white">
                  {getMetricLabel(metricKey)}
                </div>
                <div className="mt-1 text-sm text-white/60">
                  {getStatusModeLabel(statusMode)}
                </div>
                <div className="mt-2 text-xs text-white/45">
                  Период: {queryParams?.date_from || '—'} — {queryParams?.date_to || '—'}
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() =>
                    exportRowsToCsv(data?.rows || [], data?.mode, data?.group_by || groupBy)
                  }
                  className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-xs font-semibold text-white/80 hover:bg-white/[0.08]"
                >
                  Экспорт CSV
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-xs font-semibold text-white/80 hover:bg-white/[0.08]"
                >
                  Закрыть
                </button>
              </div>
            </div>

            <div className="mt-3 grid grid-cols-2 gap-2 md:grid-cols-4">
              <StatBox label="Строк" value={totalRows} />
              <StatBox label="Сумма" value={formatMoney(totalAmount)} />
              <StatBox label="Филиал" value={queryParams?.branch_id || 'Все'} />
              <StatBox label="Сотрудник" value={queryParams?.employee_id || 'Все'} />
            </div>

            <div className="mt-3 flex flex-wrap gap-2">
              <GroupButton active={groupBy === 'none'} onClick={() => setGroupBy('none')}>
                Список
              </GroupButton>
              <GroupButton active={groupBy === 'employee'} onClick={() => setGroupBy('employee')}>
                Сотрудники
              </GroupButton>
              <GroupButton active={groupBy === 'branch'} onClick={() => setGroupBy('branch')}>
                Филиалы
              </GroupButton>
              <GroupButton active={groupBy === 'service'} onClick={() => setGroupBy('service')}>
                Услуги
              </GroupButton>
              <GroupButton active={groupBy === 'day'} onClick={() => setGroupBy('day')}>
                Дни
              </GroupButton>
            </div>
          </div>

          <div className="flex-1 overflow-auto px-5 py-4">
            {loading ? <div className="text-sm text-white/60">Загрузка...</div> : null}

            {error ? (
              <div className="rounded-2xl border border-red-400/30 bg-red-500/10 px-4 py-3 text-sm text-red-200">
                {error}
              </div>
            ) : null}

            {!loading && !error && data?.rows?.length === 0 ? (
              <div className="text-sm text-white/50">Нет данных по выбранным фильтрам</div>
            ) : null}

            {!loading && !error && data?.mode === 'group' ? (
              <div className="space-y-3">
                {data.rows.map((row, idx) => (
                  <div
                    key={row.id ?? `${row.label}-${idx}`}
                    className="rounded-[20px] border border-white/10 bg-white/[0.05] p-4"
                  >
                    <div className="text-base font-bold text-white">
                      {data.group_by === 'day' ? formatDateLong(row.label) : row.label}
                    </div>
                    <div className="mt-3 grid grid-cols-2 gap-4">
                      <div>
                        <div className="text-[11px] uppercase tracking-wide text-white/35">
                          Записей
                        </div>
                        <div className="mt-1 text-lg font-bold text-white">
                          {row.total_bookings}
                        </div>
                      </div>
                      <div>
                        <div className="text-[11px] uppercase tracking-wide text-white/35">
                          Сумма
                        </div>
                        <div className="mt-1 text-lg font-bold text-white">
                          {formatMoney(row.total_amount)}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : null}

            {!loading && !error && data?.mode === 'list' ? (
              <div className="space-y-3">
                {data.rows.map((row) => {
                  const selected = selectedBookingId === row.booking_id;

                  return (
                    <div
                      key={row.booking_id}
                      className={`w-full rounded-[20px] border p-4 transition ${
                        selected
                          ? 'border-cyan-400/40 bg-cyan-500/10'
                          : 'border-white/10 bg-white/[0.05]'
                      }`}
                    >
                      <button
                        type="button"
                        onClick={() => setSelectedBookingId(row.booking_id)}
                        className="w-full text-left"
                      >
                        <div className="flex flex-wrap items-center justify-between gap-3">
                          <div>
                            <div className="text-base font-bold text-white">
                              {row.client_name}
                            </div>
                            <div className="mt-1 text-xs text-white/40">
                              Запись #{row.booking_id}
                            </div>
                          </div>

                          <div
                            className={`rounded-xl border px-3 py-1 text-[11px] font-semibold uppercase ${getStatusBadge(
                              row.status
                            )}`}
                          >
                            {row.status || '—'}
                          </div>
                        </div>

                        <div className="mt-3 grid grid-cols-1 gap-2.5 text-sm text-white/75 md:grid-cols-2">
                          <div>
                            <span className="text-white/45">Дата:</span>{' '}
                            {formatDateLong(row.date)}
                          </div>
                          <div>
                            <span className="text-white/45">Время:</span>{' '}
                            {row.start_time || '—'}
                            {row.end_time ? `–${row.end_time}` : ''}
                          </div>
                          <div>
                            <span className="text-white/45">Филиал:</span>{' '}
                            {row.branch_name}
                          </div>
                          <div>
                            <span className="text-white/45">Сотрудник:</span>{' '}
                            {row.employee_name}
                          </div>
                          <div>
                            <span className="text-white/45">Услуга:</span>{' '}
                            {row.service_name}
                          </div>
                          <div>
                            <span className="text-white/45">Сумма:</span>{' '}
                            {formatMoney(row.price)}
                          </div>
                        </div>
                      </button>

                      {selected ? (
                        <div className="mt-3 rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-3">
                          <div className="text-sm text-white/65">
                            Выбрана запись #{row.booking_id}. Можно открыть ее прямо в модуле
                            «Записи».
                          </div>

                          <div className="mt-3 flex flex-wrap gap-2">
                            <button
                              type="button"
                              onClick={() => onOpenBooking?.(row)}
                              className="rounded-xl bg-gradient-to-r from-cyan-400 to-violet-500 px-4 py-2 text-xs font-bold text-white shadow-[0_8px_20px_rgba(79,70,229,0.25)]"
                            >
                              Открыть запись
                            </button>

                            <button
                              type="button"
                              onClick={() => setSelectedBookingId(null)}
                              className="rounded-xl border border-white/10 bg-white/[0.04] px-4 py-2 text-xs font-semibold text-white/75 hover:bg-white/[0.08]"
                            >
                              Снять выбор
                            </button>
                          </div>
                        </div>
                      ) : null}
                    </div>
                  );
                })}
              </div>
            ) : null}
          </div>
        </div>
      </div>
    </>
  );
}