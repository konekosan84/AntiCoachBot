export default function EmployeesHeader({ viewMode, setViewMode, onAdd }) {
  return (
    <div className="flex items-center justify-between mb-4 gap-4">
      <div className="flex gap-2">
        <button
          onClick={() => setViewMode("cards")}
          className={`px-3 py-1 rounded-lg ${
            viewMode === "cards"
              ? "bg-cyan-500 text-black"
              : "bg-white/10 text-white"
          }`}
        >
          Карточки
        </button>

        <button
          onClick={() => setViewMode("table")}
          className={`px-3 py-1 rounded-lg ${
            viewMode === "table"
              ? "bg-cyan-500 text-black"
              : "bg-white/10 text-white"
          }`}
        >
          Таблица
        </button>
      </div>

      <button
        onClick={onAdd}
        className="
          px-4 py-2 rounded-xl
          bg-gradient-to-r from-cyan-400 to-blue-500
          text-black font-semibold
          hover:opacity-90
        "
      >
        + Добавить сотрудника
      </button>
    </div>
  );
}
