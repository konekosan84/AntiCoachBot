import React from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";

import { AuthProvider } from "./helpers/AuthContext";

import AppLayout from "./business-panel/AppLayout";

import Dashboard from "./business-panel/Dashboard";
import Branches from "./business-panel/Branches";
import Employees from "./business-panel/Employees";
import Services from "./business-panel/Services";
import Rooms from "./business-panel/Rooms";
import Schedule from "./business-panel/Schedule";
import Bookings from "./business-panel/Bookings";
import Clients from "./business-panel/Clients";
import Analytics from "./business-panel/Analytics";
import SmartBookingTestPage from './client-widget/SmartBooking/SmartBookingTestPage';

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route element={<AppLayout />}>
            <Route index element={<Navigate to="/dashboard" replace />} />

            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/branches" element={<Branches />} />
            <Route path="/employees" element={<Employees />} />
            <Route path="/services" element={<Services />} />
            <Route path="/rooms" element={<Rooms />} />
            <Route path="/schedule" element={<Schedule />} />
            <Route path="/bookings" element={<Bookings />} />
            <Route path="/clients" element={<Clients />} />
            <Route path="/analytics" element={<Analytics />} />
            <Route path="/widget-test" element={<SmartBookingTestPage />} />
          </Route>

          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}