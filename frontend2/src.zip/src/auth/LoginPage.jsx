import { useState } from "react";
import { useAuth } from "../context/AuthContext.jsx";
import { useNavigate } from "react-router-dom";

export default function LoginPage() {
  const { login, error } = useAuth();
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();

    console.log("SUBMIT:", email, password);

    const success = await login(email, password);

    if (success) {
      console.log("REDIRECTING TO DASHBOARD...");
      navigate("/");   // ← тут твой фактический dashboard-роут
    }
  };

  return (
    <div style={{ width: "300px", margin: "80px auto", textAlign: "center" }}>
      <h1>Вход в SLOTIQ PRO</h1>

      <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "10px" }}>

        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => {
            console.log("EMAIL INPUT:", e.target.value);
            setEmail(e.target.value);
          }}
        />

        <input
          type="password"
          placeholder="Пароль"
          value={password}
          onChange={(e) => {
            console.log("PASSWORD INPUT:", e.target.value);
            setPassword(e.target.value);
          }}
        />

        <button type="submit">Войти</button>
      </form>

      {error && (
        <p style={{ color: "red", marginTop: "10px" }}>{error}</p>
      )}
    </div>
  );
}
