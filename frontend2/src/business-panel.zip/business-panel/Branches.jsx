import { useEffect, useState } from "react";
import { getBranches } from "../api/branches";
import NeoBranchCard from "../ui/components/NeoBranchCard";
import NeoBranchTable from "../ui/components/NeoBranchTable";
import ViewToggle from "../ui/components/ViewToggle";
import "../ui/styles/neo/neo-layout.css";

export default function Branches() {
  const [branches, setBranches] = useState([]);
  const [view, setView] = useState("table"); // 'table' | 'cards'
  const [search, setSearch] = useState("");

  useEffect(() => {
    load();
  }, []);

  const load = async () => {
    try {
      const resp = await getBranches();
      console.log("🚀 Branches data:", resp);
      setBranches(Array.isArray(resp) ? resp : []);
    } catch (err) {
      console.error("Ошибка загрузки филиалов:", err);
      setBranches([]);
    }
  };

  const filtered = branches?.filter((b) =>
    (b?.name || "").toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="neo-page">
      <div className="neo-page-header">
        <h1>Филиалы</h1>

        <div className="neo-actions">
          <input
            placeholder="Поиск…"
            className="neo-input"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />

          <ViewToggle value={view} onChange={setView} />
          <button className="neo-button primary">+ Добавить</button>
        </div>
      </div>

      {/* TABLE VIEW */}
      {view === "table" && (
        <NeoBranchTable branches={filtered} />
      )}

      {/* CARD VIEW */}
      {view === "cards" && (
        <div className="neo-card-grid">
          {filtered?.map((branch) => (
            <NeoBranchCard key={branch.id} branch={branch} />
          ))}
          {filtered?.length === 0 && <p>Нет данных</p>}
        </div>
      )}
    </div>
  );
}
