import { useEffect, useState } from "react";
import { getScheduleMatrix } from "../api/schedule";

export default function ScheduleMatrix() {
  const [matrix, setMatrix] = useState([]);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    try {
      const data = await getScheduleMatrix();
      setMatrix(data);
    } catch (err) {
      console.error("❌ MATRIX LOAD ERROR", err);
    }
  }

  return (
    <div className="panel">
      <h2>Матрица расписания</h2>

      <table className="matrix-table">
        <thead>
          <tr>
            <th>Филиал</th>
            <th>День</th>
            <th>С</th>
            <th>До</th>
            <th>Статус</th>
          </tr>
        </thead>

        <tbody>
          {matrix.map((row) => (
            <tr key={row.id}>
              <td>{row.branch_name}</td>
              <td>{row.day_index}</td>
              <td>{row.open_time}</td>
              <td>{row.close_time}</td>
              <td>{row.closed ? "Выходной" : "Работает"}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
