import { useEffect, useState } from "react";
import { getBranches } from "../api/businesses";
import { getSchedule } from "../api/schedule";
import NeoButton from "../ui/components/NeoButton";


const DAYS = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"];

export default function Schedule() {
  const [branches, setBranches] = useState([]);
  const [branchId, setBranchId] = useState(null);
  const [schedule, setSchedule] = useState([]);

  useEffect(() => {
    loadBranches();
  }, []);

  async function loadBranches() {
    const data = await getBranches();
    setBranches(data);
    if (data.length > 0) setBranchId(data[0].id);
  }

  useEffect(() => {
    if (branchId) loadSchedule(branchId);
  }, [branchId]);

  async function loadSchedule(id) {
    const data = await getSchedule(id);
    setSchedule(data);
  }

  return (
    <div className="panel">
      <h2>Расписание (неделя)</h2>

      <select
        className="neo-select"
        value={branchId || ""}
        onChange={(e) => setBranchId(e.target.value)}
      >
        {branches.map((b) => (
          <option key={b.id} value={b.id}>{b.name}</option>
        ))}
      </select>

      <div className="week-grid">
        {DAYS.map((day, i) => {
          const shift = schedule.find((s) => s.day_index === i);

          return (
            <div key={i} className="day-column">
              <div className="day-header">{day}</div>

              {shift ? (
                <div className="shift-box">
                  <div>Открыто: {shift.open_time}</div>
                  <div>Закрыто: {shift.close_time}</div>
                  {shift.closed ? <div>ЗАКРЫТО</div> : null}
                </div>
              ) : (
                <NeoButton glow>+</NeoButton>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

