import React, { useEffect, useState } from "react";

import {
  getAnalyticsOverview,
  getTopServices,
  getBookingsByDay,
  getEmployeeLoad,
  getClientsBreakdown,
  getIssues,
} from "../api/analytics";

export default function Analytics() {
  const [overview, setOverview] = useState(null);
  const [topServices, setTopServices] = useState([]);
  const [bookingStats, setBookingStats] = useState([]);
  const [employeeLoad, setEmployeeLoad] = useState([]);
  const [clientsBreakdown, setClientsBreakdown] = useState([]);
  const [issues, setIssues] = useState([]);

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAll();
  }, []);

  async function loadAll() {
    try {
      setLoading(true);

      const [
        overviewRes,
        topServicesRes,
        bookingsRes,
        employeeLoadRes,
        clientsBreakdownRes,
        issuesRes,
      ] = await Promise.all([
        getAnalyticsOverview(),
        getTopServices(5),
        getBookingsByDay(30),
        getEmployeeLoad(),
        getClientsBreakdown(),
        getIssues(30),
      ]);

      setOverview(overviewRes);
      setTopServices(topServicesRes);
      setBookingStats(bookingsRes);
      setEmployeeLoad(employeeLoadRes);
      setClientsBreakdown(clientsBreakdownRes);
      setIssues(issuesRes);
    } catch (e) {
      console.error("Analytics load error:", e);
    } finally {
      setLoading(false);
    }
  }

  if (loading) return <div className="p-6">Загрузка...</div>;

  return (
    <div className="p-6">
      <h1 className="text-xl font-bold">Аналитика</h1>

      <pre>{JSON.stringify(overview, null, 2)}</pre>
    </div>
  );
}

