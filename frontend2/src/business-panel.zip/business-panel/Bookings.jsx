import { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext";
import { getBookings, createBooking } from "../api/bookings";
import { getClients } from "../api/clients";
import { getEmployees } from "../api/employees";
import { getServices } from "../api/services";
import { getBranches } from "../api/branches";

export default function Bookings() {
  const { user } = useAuth();
  const businessId = user?.business_id;

  const [bookings, setBookings] = useState([]);

  const [clients, setClients] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [branches, setBranches] = useState([]);
  const [services, setServices] = useState([]);

  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);

  const [form, setForm] = useState({
    client_id: "",
    employee_id: "",
    service_id: "",
    branch_id: "",
    date: "",
    time: "",
  });

  useEffect(() => {
    if (!businessId) return;

    Promise.all([
      getBookings(businessId),
      getClients(businessId),
      getEmployees(businessId),
      getBranches(businessId),
      getServices(businessId),
    ])
      .then(([bList, cList, eList, brList, sList]) => {
        setBookings(bList || []);
        setClients(cList || []);
        setEmployees(eList || []);
        setBranches(brList || []);
        setServices(sList || []);

        setForm((f) => ({
          ...f,
          client_id: cList[0]?.id || "",
          employee_id: eList[0]?.id || "",
          branch_id: brList[0]?.id || "",
          service_id: sList[0]?.id || "",
        }));
      })
      .finally(() => setLoading(false));
  }, [businessId]);

  const openAddModal = () => {
    setModalOpen(true);
  };

  const handleSave = async () => {
    const newBooking = await createBooking({
      ...form,
      business_id: businessId,
    });

    setBookings((prev) => [...prev, newBooking]);
    setModalOpen(false);
  };

  if (loading) return <>Загрузка...</>;

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-semibold">Записи</h1>

        <button
          onClick={openAddModal}
          className="px-4 py-2 bg-indigo-600 text-white rounded-lg"
        >
          Добавить запись
        </button>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {bookings.map((b) => (
          <div key={b.id} className="bg-white shadow rounded-lg p-4">
            <div className="font-semibold">
              Клиент: {clients.find((c) => c.id === b.client_id)?.name}
            </div>
            <div className="text-gray-600">
              Сотрудник: {employees.find((e) => e.id === b.employee_id)?.name}
            </div>
            <div className="text-gray-600">
              Услуга: {services.find((s) => s.id === b.service_id)?.name}
            </div>
            <div className="text-gray-600">
              Филиал: {branches.find((br) => br.id === b.branch_id)?.name}
            </div>

            <div className="text-gray-600">
              Дата: {b.date}
            </div>

            <div className="text-gray-600">
              Время: {b.time}
            </div>
          </div>
        ))}
      </div>

      {/* MODAL */}
      {modalOpen && (
        <div className="fixed inset-0 bg-black/40 flex justify-center items-center">
          <div className="bg-white p-6 rounded-lg w-96 shadow-lg">

            <h2 className="text-xl font-semibold mb-4">Добавить запись</h2>

            <select
              className="w-full border p-2 rounded mb-2"
              value={form.client_id}
              onChange={(e) => setForm({ ...form, client_id: e.target.value })}
            >
              {clients.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>

            <select
              className="w-full border p-2 rounded mb-2"
              value={form.employee_id}
              onChange={(e) => setForm({ ...form, employee_id: e.target.value })}
            >
              {employees.map((e) => (
                <option key={e.id} value={e.id}>{e.name}</option>
              ))}
            </select>

            <select
              className="w-full border p-2 rounded mb-2"
              value={form.service_id}
              onChange={(e) => setForm({ ...form, service_id: e.target.value })}
            >
              {services.map((s) => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>

            <select
              className="w-full border p-2 rounded mb-2"
              value={form.branch_id}
              onChange={(e) => setForm({ ...form, branch_id: e.target.value })}
            >
              {branches.map((b) => (
                <option key={b.id} value={b.id}>{b.name}</option>
              ))}
            </select>

            <input
              type="date"
              className="w-full border p-2 rounded mb-2"
              value={form.date}
              onChange={(e) => setForm({ ...form, date: e.target.value })}
            />

            <input
              type="time"
              className="w-full border p-2 rounded mb-2"
              value={form.time}
              onChange={(e) => setForm({ ...form, time: e.target.value })}
            />

            <div className="flex justify-end mt-4 space-x-2">
              <button
                onClick={() => setModalOpen(false)}
                className="px-3 py-2 bg-gray-300 rounded"
              >
                Отмена
              </button>

              <button
                onClick={handleSave}
                className="px-3 py-2 bg-indigo-600 text-white rounded"
              >
                Сохранить
              </button>
            </div>

          </div>
        </div>
      )}
    </div>
  );
}
