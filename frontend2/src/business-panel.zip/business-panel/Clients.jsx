import { useEffect, useState } from "react";
import { useAuth } from "../helpers/AuthContext";
import {
  getClients,
  createClient,
  updateClient,
  deleteClient,
} from "../api/clients";

export default function Clients() {
  const { auth } = useAuth();

  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(true);

  // ---- Загрузка клиентов ----
  useEffect(() => {
    loadClients();
  }, []);

  async function loadClients() {
    try {
      const data = await getClients();
      setClients(data);
    } catch (err) {
      console.error("Ошибка загрузки клиентов:", err);
    } finally {
      setLoading(false);
    }
  }

  // ---- Создание клиента ----
  async function handleCreate() {
    const name = prompt("Имя клиента:");
    if (!name) return;

    try {
      const newClient = await createClient({ name });
      setClients((prev) => [...prev, newClient]);
    } catch (err) {
      console.error("Ошибка создания клиента:", err);
    }
  }

  // ---- Редактирование клиента ----
  async function handleEdit(client) {
    const name = prompt("Новое имя клиента:", client.name);
    if (!name) return;

    try {
      const updated = await updateClient(client.id, { name });
      setClients((prev) =>
        prev.map((c) => (c.id === client.id ? updated : c))
      );
    } catch (err) {
      console.error("Ошибка обновления клиента:", err);
    }
  }

  // ---- Удаление клиента ----
  async function handleDelete(client) {
    if (!confirm(`Удалить клиента "${client.name}"?`)) return;

    try {
      await deleteClient(client.id);
      setClients((prev) => prev.filter((c) => c.id !== client.id));
    } catch (err) {
      console.error("Ошибка удаления клиента:", err);
    }
  }

  // ---- UI ----
  return (
    <div className="page visionos-container">
      <h1 className="page-title">Клиенты</h1>

      <button className="neo-btn" onClick={handleCreate}>
        + Новый клиент
      </button>

      <div className="visionos-card-list">
        {loading ? (
          <p>Загрузка...</p>
        ) : clients.length === 0 ? (
          <p className="empty">Пока нет клиентов</p>
        ) : (
          clients.map((client) => (
            <div className="visionos-card" key={client.id}>
              <div className="visionos-card-title">{client.name}</div>

              <div className="visionos-card-actions">
                <button
                  className="neo-btn small"
                  onClick={() => handleEdit(client)}
                >
                  ✏️
                </button>
                <button
                  className="neo-btn small danger"
                  onClick={() => handleDelete(client)}
                >
                  🗑
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
