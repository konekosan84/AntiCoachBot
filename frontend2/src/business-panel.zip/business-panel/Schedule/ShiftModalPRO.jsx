import { useState } from "react";
import { createShift } from "../../api/schedule";
import { format } from "date-fns";

export default function ShiftModalPRO({
  onClose,
  branches,
  employees,
  businessId,
  onSaved,
}) {
  const today = format(new Date(), "yyyy-MM-dd");

  const [form, setForm] = useState({
    branch_id: branches[0]?.id || "",
    employee_id: employees[0]?.id || "",
    date: today,
    start_time: "09:00",
    end_time: "18:00",
  });

  const handleChange = (field, value) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleSave = async () => {
    // ПРОВЕРКА: конец должен быть позже начала
    if (form.end_time <= form.start_time) {
      alert("Время окончания должно быть позже времени начала");
      return;
    }

    const payload = {
      ...form,
      business_id: businessId,
    };

    const newShift = await createShift(payload);
    onSaved(newShift);
  };

  return (
    <div className="fixed inset-0 bg-black/40 flex justify-center items-center p-4">
      <div className="bg-white w-full max-w-md rounded-lg shadow-lg p-6">
        <h2 className="text-xl font-semibold mb-4">Добавить смену</h2>

        {/* BRANCH */}
        <label className="text-sm text-gray-600">Филиал</label>
        <select
          className="w-full border p-2 rounded mb-3"
          value={form.branch_id}
          onChange={(e) => handleChange("branch_id", e.target.value)}
        >
          {branches.map((b) => (
            <option key={b.id} value={b.id}>
              {b.name}
            </option>
          ))}
        </select>

        {/* EMPLOYEE */}
        <label className="text-sm text-gray-600">Сотрудник</label>
        <select
          className="w-full border p-2 rounded mb-3"
          value={form.employee_id}
          onChange={(e) => handleChange("employee_id", e.target.value)}
        >
          {employees.map((e) => (
            <option key={e.id} value={e.id}>
              {e.name}
            </option>
          ))}
        </select>

        {/* DATE */}
        <label className="text-sm text-gray-600">Дата</label>
        <input
          type="date"
          className="w-full border p-2 rounded mb-3"
          value={form.date}
          onChange={(e) => handleChange("date", e.target.value)}
        />

        {/* TIME RANGE */}
        <div className="flex gap-3">
          <div className="flex-1">
            <label className="text-sm text-gray-600">Начало</label>
            <input
              type="time"
              className="w-full border p-2 rounded"
              value={form.start_time}
              onChange={(e) => handleChange("start_time", e.target.value)}
            />
          </div>

          <div className="flex-1">
            <label className="text-sm text-gray-600">Конец</label>
            <input
              type="time"
              className="w-full border p-2 rounded"
              value={form.end_time}
              onChange={(e) => handleChange("end_time", e.target.value)}
            />
          </div>
        </div>

        {/* BUTTONS */}
        <div className="flex justify-end mt-6 gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-gray-300 rounded-lg"
          >
            Отмена
          </button>

          <button
            onClick={handleSave}
            className="px-4 py-2 bg-indigo-600 text-white rounded-lg"
          >
            Сохранить
          </button>
        </div>
      </div>
    </div>
  );
}
