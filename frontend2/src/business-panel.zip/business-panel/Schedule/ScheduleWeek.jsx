import { startOfWeek, addDays, format } from "date-fns";
import { ru } from "date-fns/locale";
import { groupShiftsByDay } from "../../utils/shiftUtils";

export default function ScheduleWeek({
  schedule,
  employees,
  branches,
  selectedBranch,
  selectedEmployee,
}) {
  // Начало недели (понедельник)
  const weekStart = startOfWeek(new Date(), { weekStartsOn: 1 });
  const weekDays = [...Array(7)].map((_, i) => addDays(weekStart, i));

  // Фильтрация по филиалу
  const filteredByBranch = schedule.filter(
    (s) => s.branch_id === Number(selectedBranch)
  );

  // Фильтрация по сотруднику
  const filtered = selectedEmployee
    ? filteredByBranch.filter((s) => s.employee_id === Number(selectedEmployee))
    : filteredByBranch;

  // Группировка смен по дням
  const grouped = groupShiftsByDay(filtered);

  const getDayKey = (date) => format(date, "yyyy-MM-dd");

  return (
    <div className="overflow-x-auto">

      {/* HEADER — дни недели */}
      <div className="grid grid-cols-8 bg-gray-100 rounded-t-lg shadow-sm">
        <div className="p-3 font-semibold text-gray-700 border-r"></div>

        {weekDays.map((day) => (
          <div
            key={day}
            className="p-3 text-center font-semibold text-gray-700 border-r"
          >
            <div>{format(day, "EEEE", { locale: ru })}</div>
            <div className="text-sm text-gray-500">
              {format(day, "dd MMM", { locale: ru })}
            </div>
          </div>
        ))}
      </div>

      {/* BODY — сотрудники × дни */}
      {employees.map((emp) => (
        <div key={emp.id} className="grid grid-cols-8 border-b bg-white">
          <div className="p-3 border-r font-medium text-gray-800 bg-gray-50">
            {emp.name}
          </div>

          {weekDays.map((day) => {
            const dayKey = getDayKey(day);
            const shifts = grouped[dayKey]?.filter(
              (s) => s.employee_id === emp.id
            );

            return (
              <div
                key={dayKey}
                className="p-2 border-r min-h-[80px] relative"
              >
                {/* Если смен нет */}
                {!shifts || shifts.length === 0 ? (
                  <div className="text-gray-300 text-sm text-center mt-6">
                    —
                  </div>
                ) : (
                  <div className="space-y-2">
                    {shifts.map((shift) => {
                      const branch = branches.find(
                        (b) => b.id === shift.branch_id
                      );

                      return (
                        <div
                          key={shift.id}
                          className="p-2 bg-indigo-50 border border-indigo-200 rounded-lg shadow text-xs"
                        >
                          <div className="text-indigo-700 font-medium">
                            {shift.start_time} — {shift.end_time}
                          </div>

                          <div className="text-gray-600">
                            {branch?.name}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
}
