import {
  startOfMonth,
  endOfMonth,
  startOfWeek,
  endOfWeek,
  addDays,
  format,
  isSameMonth,
} from "date-fns";
import { ru } from "date-fns/locale";
import { groupShiftsByDay } from "../../utils/shiftUtils";

export default function ScheduleMonth({
  schedule,
  employees,
  branches,
  selectedBranch,
  selectedEmployee,
}) {
  const today = new Date();

  const monthStart = startOfMonth(today);
  const monthEnd = endOfMonth(monthStart);

  const calendarStart = startOfWeek(monthStart, { weekStartsOn: 1 });
  const calendarEnd = endOfWeek(monthEnd, { weekStartsOn: 1 });

  // Фильтрация по филиалу
  const filteredByBranch = schedule.filter(
    (s) => s.branch_id === Number(selectedBranch)
  );

  // Фильтрация по сотруднику
  const filtered = selectedEmployee
    ? filteredByBranch.filter((s) => s.employee_id === Number(selectedEmployee))
    : filteredByBranch;

  // Сгруппировать смены по дням
  const grouped = groupShiftsByDay(filtered);

  const getDayKey = (d) => format(d, "yyyy-MM-dd");

  // Сетка на 6 недель
  const days = [];
  let day = calendarStart;

  while (day <= calendarEnd) {
    days.push(day);
    day = addDays(day, 1);
  }

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">
        {format(monthStart, "LLLL yyyy", { locale: ru })}
      </h2>

      <div className="grid grid-cols-7 text-center font-medium text-gray-600 mb-2">
        <div>Пн</div>
        <div>Вт</div>
        <div>Ср</div>
        <div>Чт</div>
        <div>Пт</div>
        <div>Сб</div>
        <div>Вс</div>
      </div>

      <div className="grid grid-cols-7 gap-2">
        {days.map((date) => {
          const isCurrentMonth = isSameMonth(date, monthStart);
          const dayKey = getDayKey(date);
          const shifts = grouped[dayKey] || [];

          return (
            <div
              key={date}
              className={`p-2 min-h-[120px] rounded-lg border shadow-sm flex flex-col ${
                isCurrentMonth
                  ? "bg-white"
                  : "bg-gray-100 text-gray-400 opacity-70"
              }`}
            >
              {/* Дата */}
              <div className="text-sm font-semibold mb-2">
                {format(date, "d", { locale: ru })}
              </div>

              {/* Смены за день */}
              <div className="flex flex-col gap-1 flex-1 overflow-hidden">
                {shifts.length === 0 && (
                  <div className="text-gray-300 text-sm text-center mt-4">—</div>
                )}

                {shifts.slice(0, 3).map((shift) => {
                  const emp = employees.find((e) => e.id === shift.employee_id);
                  const br = branches.find((b) => b.id === shift.branch_id);

                  return (
                    <div
                      key={shift.id}
                      className="p-1 text-xs bg-indigo-50 border border-indigo-200 rounded"
                      title={`${emp?.name}\n${shift.start_time} — ${shift.end_time}\n${br?.name}`}
                    >
                      <div className="font-medium text-indigo-700 truncate">
                        {emp?.name || "Сотрудник"}
                      </div>

                      <div className="text-gray-600 truncate">
                        {shift.start_time}–{shift.end_time}
                      </div>
                    </div>
                  );
                })}

                {/* Если смен больше 3 */}
                {shifts.length > 3 && (
                  <div className="text-xs text-gray-500 mt-1">
                    + {shifts.length - 3} ещё
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
