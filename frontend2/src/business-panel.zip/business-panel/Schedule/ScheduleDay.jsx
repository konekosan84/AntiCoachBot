import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { groupShiftsByTime } from "../../utils/shiftUtils";

export default function ScheduleDay({
  schedule,
  employees,
  branches,
  selectedBranch,
  selectedEmployee,
}) {
  // Фильтрация по филиалу
  const filteredByBranch = schedule.filter(
    (s) => s.branch_id === Number(selectedBranch)
  );

  // Фильтрация по сотруднику (если выбран)
  const filtered = selectedEmployee
    ? filteredByBranch.filter((s) => s.employee_id === Number(selectedEmployee))
    : filteredByBranch;

  // Группировка смен по времени
  const grouped = groupShiftsByTime(filtered);

  // Текущая дата
  const today = new Date();

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">
        {format(today, "d MMMM yyyy (EEEE)", { locale: ru })}
      </h2>

      {/* Нет смен */}
      {filtered.length === 0 && (
        <div className="text-gray-500 text-lg mt-6">
          Нет смен на сегодня
        </div>
      )}

      {/* Таблица смен */}
      <div className="space-y-4">
        {Object.entries(grouped).map(([time, shifts]) => (
          <div
            key={time}
            className="border rounded-lg p-4 bg-gray-50 shadow-sm"
          >
            <div className="font-semibold text-lg mb-3">{time}</div>

            <div className="space-y-2">
              {shifts.map((shift) => {
                const employee = employees.find(
                  (e) => e.id === shift.employee_id
                );
                const branch = branches.find(
                  (b) => b.id === shift.branch_id
                );

                return (
                  <div
                    key={shift.id}
                    className="p-3 bg-white rounded-lg shadow flex justify-between items-center"
                  >
                    <div>
                      <div className="text-gray-800 font-medium">
                        {employee?.name || "Сотрудник"}
                      </div>

                      <div className="text-gray-500 text-sm">
                        {branch?.name}
                      </div>
                    </div>

                    <div className="text-gray-600">
                      {shift.start_time} — {shift.end_time}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
