import React, { useEffect, useState } from "react";
import { getRooms } from "../api/rooms";
import ViewToggle from "../ui/components/ViewToggle";
import RoomSidePanel from "../ui/modals/RoomSidePanel";
import NeoRoomTable from "../ui/components/NeoRoomTable";
import NeoRoomCard from "../ui/components/NeoRoomCard";

export default function Rooms() {
  const [rooms, setRooms] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [search, setSearch] = useState("");
  const [view, setView] = useState("table");
  const [selected, setSelected] = useState(null);
  const [panelOpen, setPanelOpen] = useState(false);

  async function load() {
    try {
      const data = await getRooms();
      setRooms(data);
      setFiltered(data);
    } catch (e) {
      console.error("Ошибка загрузки помещений:", e);
    }
  }

  useEffect(() => {
    load();
  }, []);

  useEffect(() => {
    const s = search.toLowerCase();
    setFiltered(
      rooms.filter((r) =>
        (r.name || "").toLowerCase().includes(s)
      )
    );
  }, [search, rooms]);

  function openEdit(room) {
    setSelected(room);
    setPanelOpen(true);
  }

  function openCreate() {
    setSelected(null);
    setPanelOpen(true);
  }

  function onSaved() {
    setPanelOpen(false);
    load();
  }

  return (
    <div className="page">
      <h1>Помещения</h1>

      <div className="toolbar">
        <input placeholder="Поиск..." value={search} onChange={(e) => setSearch(e.target.value)} />
        <ViewToggle view={view} setView={setView} />
        <button className="add-btn" onClick={openCreate}>+ Добавить</button>
      </div>

      {view === "table" && (
        <NeoRoomTable data={filtered} onEdit={openEdit} />
      )}

      {view === "cards" && (
        <div className="cards-grid">
          {filtered.map((room) => (
            <NeoRoomCard key={room.id} room={room} onEdit={() => openEdit(room)} />
          ))}
        </div>
      )}

      {panelOpen && (
        <RoomSidePanel
          room={selected}
          onClose={() => setPanelOpen(false)}
          onSaved={onSaved}
        />
      )}
    </div>
  );
}
