import React, { useEffect, useState } from "react";
import { getServices } from "../api/services";
import ViewToggle from "../ui/components/ViewToggle";
import ServiceSidePanel from "../ui/modals/ServiceSidePanel";
import NeoServiceTable from "../ui/components/NeoServiceTable";
import NeoServiceCard from "../ui/components/NeoServiceCard";

export default function Services() {
  const [services, setServices] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [search, setSearch] = useState("");
  const [view, setView] = useState("table");
  const [selected, setSelected] = useState(null);
  const [panelOpen, setPanelOpen] = useState(false);

  async function load() {
    try {
      const data = await getServices();
      setServices(data);
      setFiltered(data);
    } catch (e) {
      console.error("Ошибка загрузки услуг:", e);
    }
  }

  useEffect(() => {
    load();
  }, []);

  useEffect(() => {
    const s = search.toLowerCase();
    setFiltered(
      services.filter((srv) =>
        (srv.name || "").toLowerCase().includes(s)
      )
    );
  }, [search, services]);

  function openEdit(service) {
    setSelected(service);
    setPanelOpen(true);
  }

  function openCreate() {
    setSelected(null);
    setPanelOpen(true);
  }

  function onSaved() {
    setPanelOpen(false);
    load();
  }

  return (
    <div className="page">
      <h1>Услуги</h1>

      <div className="toolbar">
        <input placeholder="Поиск..." value={search} onChange={(e) => setSearch(e.target.value)} />
        <ViewToggle view={view} setView={setView} />
        <button className="add-btn" onClick={openCreate}>+ Добавить</button>
      </div>

      {view === "table" && (
        <NeoServiceTable data={filtered} onEdit={openEdit} />
      )}

      {view === "cards" && (
        <div className="cards-grid">
          {filtered.map((srv) => (
            <NeoServiceCard key={srv.id} service={srv} onEdit={() => openEdit(srv)} />
          ))}
        </div>
      )}

      {panelOpen && (
        <ServiceSidePanel
          service={selected}
          onClose={() => setPanelOpen(false)}
          onSaved={onSaved}
        />
      )}
    </div>
  );
}
