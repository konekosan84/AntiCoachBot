// frontend2/src/business-panel/Employees.jsx
import { useEffect, useMemo, useState } from "react";
import {
  getEmployees,
  createEmployee,
  updateEmployee,
  deleteEmployee,
} from "../api/employees";

import NeoEmployeeCard from "../ui/components/NeoEmployeeCard";
import NeoEmployeeTable from "../ui/components/NeoEmployeeTable";
import EmployeeSidePanel from "../ui/modals/EmployeeSidePanel";

import "../ui/styles/neo/neo-card.css";
import "../ui/styles/neo/neo-sidepanel.css";

export default function Employees() {
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(false);
  const [loadError, setLoadError] = useState(null);

  const [viewMode, setViewMode] = useState("cards"); // "cards" | "table"
  const [search, setSearch] = useState("");

  const [isPanelOpen, setIsPanelOpen] = useState(false);
  const [panelMode, setPanelMode] = useState("create"); // "create" | "edit"
  const [selectedEmployee, setSelectedEmployee] = useState(null);

  // --- загрузка сотрудников ---
  const loadEmployees = async () => {
    try {
      setLoading(true);
      setLoadError(null);
      const data = await getEmployees();
      if (Array.isArray(data)) {
        setEmployees(data);
      } else {
        console.warn("API вернул не массив:", data);
        setEmployees([]);
      }
    } catch (err) {
      console.error("Ошибка загрузки сотрудников", err);
      setLoadError("Не удалось загрузить сотрудников");
      setEmployees([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadEmployees();
  }, []);

  // --- фильтрация по поиску ---
  const filteredEmployees = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return employees;

    return employees.filter((emp) => {
      const name = (emp.full_name || "").toLowerCase();
      const position = (emp.position || "").toLowerCase();
      const role = (emp.role || "").toLowerCase();
      return (
        name.includes(q) || position.includes(q) || role.includes(q)
      );
    });
  }, [employees, search]);

  // --- обработчики ---

  const handleAddClick = () => {
    setPanelMode("create");
    setSelectedEmployee(null);
    setIsPanelOpen(true);
  };

  const handleSelectEmployee = (employee) => {
    if (!employee) return;
    setSelectedEmployee(employee);
    setPanelMode("edit");
    setIsPanelOpen(true);
  };

  const handleClosePanel = () => {
    setIsPanelOpen(false);
  };

  const handleSaveEmployee = async (formValues) => {
    try {
      if (panelMode === "create") {
        await createEmployee(formValues);
      } else if (panelMode === "edit" && selectedEmployee) {
        await updateEmployee(selectedEmployee.id, formValues);
      }
      await loadEmployees();
      setIsPanelOpen(false);
    } catch (err) {
      console.error("Ошибка сохранения сотрудника", err);
      alert("Не удалось сохранить сотрудника. Проверь консоль.");
    }
  };

  const handleDeleteEmployee = async () => {
    if (!selectedEmployee) return;
    if (!window.confirm("Удалить этого сотрудника?")) return;

    try {
      await deleteEmployee(selectedEmployee.id);
      await loadEmployees();
      setIsPanelOpen(false);
    } catch (err) {
      console.error("Ошибка удаления сотрудника", err);
      alert("Не удалось удалить сотрудника. Проверь консоль.");
    }
  };

  // --- рендер ---

  return (
    <div className="employees-page">
      <div className="employees-header">
        <h1 className="employees-title">Сотрудники</h1>

        <div className="employees-header-controls">
          <input
            type="text"
            placeholder="Поиск сотрудников..."
            className="neo-input neo-input--search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />

          <div className="neo-toggle-group">
            <button
              type="button"
              className={
                "neo-toggle-button" +
                (viewMode === "cards" ? " neo-toggle-button--active" : "")
              }
              onClick={() => setViewMode("cards")}
            >
              Карточки
            </button>
            <button
              type="button"
              className={
                "neo-toggle-button" +
                (viewMode === "table" ? " neo-toggle-button--active" : "")
              }
              onClick={() => setViewMode("table")}
            >
              Таблица
            </button>
          </div>

          <button
            type="button"
            className="neo-button neo-button--primary"
            onClick={handleAddClick}
          >
            + Добавить сотрудника
          </button>
        </div>
      </div>

      <div className="employees-content">
        {loading && <div className="neo-hint">Загружаем сотрудников...</div>}
        {loadError && (
          <div className="neo-error">
            {loadError}
          </div>
        )}

        {!loading && !loadError && filteredEmployees.length === 0 && (
          <div className="neo-hint">Сотрудников пока нет…</div>
        )}

        {!loading && !loadError && filteredEmployees.length > 0 && (
          <>
            {viewMode === "cards" ? (
              <div className="employees-cards-grid">
                {filteredEmployees.map((emp) => (
                  <NeoEmployeeCard
                    key={emp.id}
                    employee={emp}
                    onSelect={handleSelectEmployee}
                  />
                ))}
              </div>
            ) : (
              <NeoEmployeeTable
                employees={filteredEmployees}
                onSelect={handleSelectEmployee}
              />
            )}
          </>
        )}
      </div>

      <EmployeeSidePanel
        isOpen={isPanelOpen}
        mode={panelMode}
        employee={selectedEmployee}
        onClose={handleClosePanel}
        onSave={handleSaveEmployee}
        onDelete={handleDeleteEmployee}
      />
    </div>
  );
}
